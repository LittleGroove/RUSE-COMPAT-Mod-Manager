"""
RUSE Mod Manager — Build Pipeline
==================================
Packages mod_manager.py + ruse_mod_engine into a single Windows exe using
PyInstaller, then drops the versioned output into FINAL_output/v<ver>/.

Usage:
    python build.py               -- build current version, then bump patch
    python build.py --bump minor  -- bump minor before building (resets patch)
    python build.py --bump major  -- bump major before building (resets minor+patch)
    python build.py --no-bump     -- build without incrementing the version

After a successful build FINAL_output/ will look like:
    FINAL_output/
        v1.0.1/
            RUSE_ModManager_v1.0.1.exe
            mods/                   <- ship this empty folder alongside the exe
        v1.0.2/
            ...
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT        = Path(__file__).parent.resolve()
CONFIG_FILE = ROOT / "build_config.json"
FINAL_OUT   = ROOT / "FINAL_output"
BUILD_WORK  = ROOT / "_build_work"   # temp PyInstaller scratch space
ICON_PATH   = ROOT / "icon.ico"      # icon.ico must live next to build.py
ENTRY_POINT = ROOT / "mod_manager.py"


def find_pyinstaller() -> list:
    """Return a command prefix that runs PyInstaller.

    Tries (in order):
      1. pyinstaller.exe on PATH
      2. pyinstaller.exe inside Windows-store Python user packages
      3. pyinstaller.exe inside standard Python installs under LOCALAPPDATA
      4. Fall back to 'python -m PyInstaller' with the current interpreter
    """
    # 1. In PATH
    pi = shutil.which("pyinstaller")
    if pi:
        return [pi]

    # 2 & 3. Search common Windows Python script dirs
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    search_roots = [
        local / "Packages",                        # Windows Store Python
        local / "Programs" / "Python",             # standard installer
    ]
    for root in search_roots:
        if not root.exists():
            continue
        for exe in root.rglob("pyinstaller.exe"):
            return [str(exe)]

    # 4. Last resort: module invocation with current interpreter
    return [sys.executable, "-m", "PyInstaller"]


# ── Version helpers ───────────────────────────────────────────────────────────

def load_version() -> dict:
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {"major": 1, "minor": 0, "patch": 0}


def save_version(v: dict):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(v, f, indent=2)
    print(f"  build_config.json updated -> {fmt(v)}")


def fmt(v: dict) -> str:
    return f"{v['major']}.{v['minor']}.{v['patch']}"


def bump(v: dict, part: str) -> dict:
    v = dict(v)
    if part == "major":
        v["major"] += 1
        v["minor"]  = 0
        v["patch"]  = 0
    elif part == "minor":
        v["minor"] += 1
        v["patch"]  = 0
    else:
        v["patch"] += 1
    return v


# ── Spec file ─────────────────────────────────────────────────────────────────

def write_spec(exe_name: str, spec_path: Path) -> Path:
    """Write a .spec file with absolute paths so nothing gets mis-resolved."""
    icon_line = f"    icon=[r'{ICON_PATH}']," if ICON_PATH.exists() else ""
    spec = f"""\
# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = []
binaries = []
hiddenimports = [
    'ruse_mod_engine',
    'ruse_mod_engine.applier',
    'ruse_mod_engine.converter',
    'ruse_mod_engine.edata',
    'ruse_mod_engine.ndfbin',
    'ruse_mod_engine.mod_format',
]
tmp_ret = collect_all('ruse_mod_engine')
datas    += tmp_ret[0]
binaries += tmp_ret[1]
hiddenimports += tmp_ret[2]

a = Analysis(
    [r'{ENTRY_POINT}'],
    pathex=[r'{ROOT}'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={{}},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='{exe_name}',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
{icon_line}
)
"""
    out = spec_path / f"{exe_name}.spec"
    out.write_text(spec, encoding="utf-8")
    return out


# ── Build ─────────────────────────────────────────────────────────────────────

def run_build(ver_str: str) -> Path:
    exe_name = f"RUSE_ModManager_v{ver_str}"
    out_dir  = FINAL_OUT / f"v{ver_str}"
    out_dir.mkdir(parents=True, exist_ok=True)
    BUILD_WORK.mkdir(exist_ok=True)

    if ICON_PATH.exists():
        print(f"  Using icon: {ICON_PATH.name}")
    else:
        print("  (icon.ico not found — building without icon)")

    spec_file = write_spec(exe_name, BUILD_WORK)
    pi_cmd = find_pyinstaller()
    print(f"  Spec    : {spec_file}")
    print(f"  Builder : {pi_cmd[0]}")

    cmd = pi_cmd + [
        "--distpath", str(out_dir),
        "--workpath", str(BUILD_WORK / "work"),
        str(spec_file),
    ]

    print(f"\n  Running PyInstaller for v{ver_str}...\n")
    result = subprocess.run(cmd, cwd=str(ROOT))
    if result.returncode != 0:
        return None

    # Confirm the exe is actually on disk (antivirus can silently delete it)
    exe_path = out_dir / f"{exe_name}.exe"
    if not exe_path.exists():
        print("\n  ERROR: PyInstaller reported success but the exe is missing.")
        print("  This usually means Windows Defender quarantined it.")
        print("  Add an exclusion for the FINAL_output\\ folder in Windows Security and retry.")
        return None

    return exe_path


SRC_MODS = ROOT / "mods"


def post_build(out_dir: Path):
    """Populate the mods/ folder that ships alongside the exe."""
    mods = out_dir / "mods"
    mods.mkdir(exist_ok=True)

    src = SRC_MODS
    if src.exists():
        copied = 0
        for f in src.iterdir():
            if f.is_file():
                shutil.copy2(str(f), str(mods / f.name))
                copied += 1
        if copied:
            print(f"  mods/  : copied {copied} rmod file(s) from source mods/")
        else:
            print(f"  mods/  : source mods/ is empty, folder created")
    else:
        print(f"  mods/  : no source mods/ folder found, created empty")


def cleanup_work():
    if BUILD_WORK.exists():
        shutil.rmtree(BUILD_WORK)
        print(f"  Cleaned temp build folder.")


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Build RUSE Mod Manager exe")
    parser.add_argument("--bump", choices=["major", "minor", "patch"],
                        default="patch",
                        help="Version part to increment after a successful build "
                             "(default: patch)")
    parser.add_argument("--no-bump", action="store_true",
                        help="Skip version increment after build")
    args = parser.parse_args()

    ver     = load_version()
    ver_str = fmt(ver)

    print("=" * 60)
    print(f"  RUSE Mod Manager — Build Pipeline")
    print(f"  Building version : v{ver_str}")
    print(f"  Output folder    : FINAL_output/v{ver_str}/")
    print("=" * 60)

    # Verify PyInstaller is reachable
    pi_cmd = find_pyinstaller()
    chk = subprocess.run(pi_cmd + ["--version"], capture_output=True)
    if chk.returncode != 0:
        print("\nERROR: PyInstaller not found.")
        print("  Run:  pip install pyinstaller")
        print(f"  (Searched PATH + LOCALAPPDATA; current Python: {sys.executable})")
        sys.exit(1)
    print(f"  PyInstaller : {chk.stdout.decode().strip()}")

    exe_path = run_build(ver_str)
    if exe_path is None:
        print("\nBuild FAILED — exe not produced.")
        cleanup_work()
        sys.exit(1)

    post_build(exe_path.parent)
    cleanup_work()

    print("\n" + "=" * 60)
    print(f"  Build SUCCESS")
    print(f"  Exe  : {exe_path}")
    print(f"  Dist : {exe_path.parent}")
    print("=" * 60)

    if not args.no_bump:
        next_ver = bump(ver, args.bump)
        save_version(next_ver)
        print(f"\n  Next build will be v{fmt(next_ver)}")
    else:
        print("\n  --no-bump: version unchanged.")


if __name__ == "__main__":
    main()
