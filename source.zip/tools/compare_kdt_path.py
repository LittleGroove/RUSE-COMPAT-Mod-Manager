"""Compare the KDT path from original vs from rmod."""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from ruse_mod_engine import edata as edata_mod

ROOT  = Path(__file__).parent.parent
ORIG  = ROOT / "Claude/sources/RUSE-game/Data/PC/1360/DataMap_Win.dat"
orig_edat = edata_mod.open_dat(str(ORIG))

# Original path
orig_kdt_1115 = next(e for e in orig_edat.list() if len(e) == 1115 and e.endswith(".kdt"))
print("Original path (len=%d):" % len(orig_kdt_1115))
print(repr(orig_kdt_1115))
print()

# RMOD path
with open(ROOT / "mods/pinnacle_map_pack.rmod") as f:
    rmod = json.load(f)
for fg in rmod.get("file_patches", []):
    for fp in fg["files"]:
        if len(fp["path"]) == 1115:
            rmod_path = fp["path"]
            print("RMOD path (len=%d):" % len(rmod_path))
            print(repr(rmod_path))
            print()
            # Compare character by character
            orig_fwd = orig_kdt_1115.replace("\\", "/")
            orig_lower = orig_fwd.lower()
            rmod_lower = rmod_path.lower()
            print("Orig fwd:", repr(orig_lower[:80]))
            print("RMOD    :", repr(rmod_lower[:80]))
            print()
            if orig_lower == rmod_lower:
                print("PATHS MATCH")
            else:
                for i, (a, b) in enumerate(zip(orig_lower, rmod_lower)):
                    if a != b:
                        print("First diff at pos %d: orig=%r, rmod=%r" % (i, a, b))
                        print("Context: orig=...%r..." % orig_lower[max(0,i-10):i+20])
                        print("Context: rmod=...%r..." % rmod_lower[max(0,i-10):i+20])
                        break
            break
