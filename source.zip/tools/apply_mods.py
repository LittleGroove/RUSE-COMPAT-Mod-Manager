"""
apply_mods.py — apply one or more .rmod files to the RUSE game data directory.

Usage:
  # Apply a single mod
  python tools/apply_mods.py mods/my_mod.rmod --game-dir "C:/Steam/.../R.U.S.E/Data"

  # Apply multiple mods in order
  python tools/apply_mods.py mods/balance.rmod mods/cheat.rmod --game-dir "..."

  # Check for conflicts without changing anything
  python tools/apply_mods.py mods/*.rmod --game-dir "..." --check-conflicts

  # Dry run (parse + match without writing)
  python tools/apply_mods.py mods/my_mod.rmod --game-dir "..." --dry-run

  # Restore from backup
  python tools/apply_mods.py --restore "C:/Steam/.../R.U.S.E/Data/PC/99/ZZ_GladPatchableWin.dat"

The game-dir is the Data/ folder inside the RUSE installation, e.g.:
  C:\\Program Files (x86)\\Steam\\steamapps\\common\\R.U.S.E\\Data
"""

import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import applier, mod_format


def main():
    parser = argparse.ArgumentParser(
        description="Apply .rmod patch files to RUSE game data",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("mods", nargs="*", help="Path(s) to .rmod files")
    parser.add_argument("--game-dir", "-g", required=False,
                        help="Path to the RUSE Data/ directory")
    parser.add_argument("--no-backup", action="store_true",
                        help="Skip creating .dat.bak backups (not recommended)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Parse and match without writing any files")
    parser.add_argument("--check-conflicts", action="store_true",
                        help="Show property conflicts between mods then exit")
    parser.add_argument("--restore", help="Restore a .dat from its .bak backup")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Verbose logging (DEBUG level)")
    args = parser.parse_args()

    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=level, format="%(levelname)-8s %(message)s")

    if args.restore:
        ok = applier.restore_backup(args.restore)
        sys.exit(0 if ok else 1)

    if not args.mods:
        parser.print_help()
        sys.exit(0)

    if not args.game_dir:
        print("ERROR: --game-dir is required", file=sys.stderr)
        sys.exit(1)

    game_dir = args.game_dir
    if not Path(game_dir).exists():
        print(f"ERROR: Game directory not found: {game_dir}", file=sys.stderr)
        sys.exit(1)

    mod_paths = []
    for pattern in args.mods:
        p = Path(pattern)
        if "*" in str(p) or "?" in str(p):
            mod_paths.extend(sorted(Path(".").glob(str(p))))
        else:
            mod_paths.append(p)

    mod_paths = [str(p) for p in mod_paths if str(p).endswith(".rmod")]
    if not mod_paths:
        print("ERROR: No .rmod files found", file=sys.stderr)
        sys.exit(1)

    print(f"Mods to apply ({len(mod_paths)}):")
    for p in mod_paths:
        try:
            m = mod_format.load(p)
            print(f"  {p}  →  {m.summary()}")
        except mod_format.ModFormatError as e:
            print(f"  {p}  →  PARSE ERROR: {e}", file=sys.stderr)
            sys.exit(1)
    print()

    if args.check_conflicts:
        print("Checking for conflicts…")
        conflicts = applier.check_conflicts(mod_paths, game_dir)
        if conflicts:
            print(f"\n{len(conflicts)} conflict(s) found:")
            for c in conflicts:
                print(f"  ⚠  {c}")
            print("\nLater mods override earlier mods for the same property.")
        else:
            print("No conflicts found — all mods patch different properties.")
        return

    if args.dry_run:
        print("DRY RUN — no files will be written.\n")

    results = applier.apply_mods(
        mod_paths=mod_paths,
        game_data_dir=game_dir,
        backup=not args.no_backup,
        dry_run=args.dry_run,
    )

    print()
    print("=" * 60)
    all_ok = True
    for r in results:
        icon = "✓" if r.ok() else "✗"
        print(f"  {icon}  {r.summary()}")
        if r.warnings:
            for w in r.warnings:
                print(f"       ⚠  {w}")
        if r.errors:
            for e in r.errors:
                print(f"       ✗  {e}")
            all_ok = False
    print("=" * 60)

    if all_ok:
        if args.dry_run:
            print("\nDry run complete — no changes written.")
        else:
            print("\nAll mods applied successfully.")
    else:
        print("\nSome mods had errors. Check output above.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
