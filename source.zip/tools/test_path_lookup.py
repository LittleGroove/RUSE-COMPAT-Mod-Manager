"""Test path lookup in DataMap_Win.dat."""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from ruse_mod_engine import edata as edata_mod

ROOT  = Path(__file__).parent.parent
ORIG  = ROOT / "Claude/sources/RUSE-game/Data/PC/1360/DataMap_Win.dat"
orig_edat = edata_mod.open_dat(str(ORIG))

entries = orig_edat.list()
# Find a changed file
test_path = next(e for e in entries if e.endswith("leveldesign.scenario"))
print("Test path:", repr(test_path))
print("Path length:", len(test_path))

result = orig_edat.get(test_path)
print("get(bs path):", "OK %d bytes" % len(result) if result else "NONE")

fwd = test_path.replace("\\", "/")
result2 = orig_edat.get(fwd)
print("get(fwd path):", "OK %d bytes" % len(result2) if result2 else "NONE")

# Check rmod paths
with open(ROOT / "mods/pinnacle_map_pack.rmod") as f:
    rmod = json.load(f)

for fg in rmod.get("file_patches", []):
    print()
    print("file_patches dat:", fg["dat"])
    for fp in fg["files"]:
        p = fp["path"]
        r1 = orig_edat.get(p)
        r2 = orig_edat.get(p.replace("/", "\\"))
        status = "OK" if (r1 or r2) else "NONE"
        print("  [%s] len=%d  ...%s" % (status, len(p), p[-60:]))
    break
