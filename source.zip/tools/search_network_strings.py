import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata
import ruse_mod_engine.ndfbin as ndfbin

DAT = 'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat'
arc = edata.open_dat(DAT)

TERMS = ['ranked', 'network', 'online', 'multiplayer', 'lobby', 'match', 'effetmap']

for e in arc._entries:
    if not e.path.lower().endswith('.gladndfbin'):
        continue
    raw = arc.get(e.path)
    try:
        ndf = ndfbin.read(raw)
    except Exception:
        continue
    hits = []
    for s in ndf.strings:
        for term in TERMS:
            if term.lower() in s.lower():
                hits.append(s)
                break
    if hits:
        print(f'\n{e.path}')
        for h in hits:
            print(f'  {repr(h)}')
