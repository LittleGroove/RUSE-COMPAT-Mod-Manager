import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata
import ruse_mod_engine.ndfbin as ndfbin

TERMS = ['multiplayer', 'network', 'ranked', 'lobby', 'online', 'matchmaking']
DATS = [
    'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladNotPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/1360/ZZ_GladPatchableWin.dat',
]

for dat_path in DATS:
    arc = edata.open_dat(dat_path)
    for e in arc._entries:
        if not e.path.lower().endswith('.gladndfbin'):
            continue
        raw = arc.get(e.path)
        try:
            ndf = ndfbin.read(raw)
        except Exception:
            continue
        for c in ndf.classes:
            for term in TERMS:
                if term.lower() in c.name.lower():
                    print(f'{dat_path}')
                    print(f'  {e.path}')
                    print(f'  CLASS: {c.name}')
                    break
