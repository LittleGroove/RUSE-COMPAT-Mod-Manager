"""
RUSE Mod Test GUI
=================
Loads .rmod files and applies them to a copy of the game data written to
an output directory — the original game files are never touched.

Usage:
    python tools/test_gui.py
"""

import json
import logging
import os
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, font, messagebox, scrolledtext, ttk

_STATE_FILE = Path(__file__).parent / ".test_gui_state.json"

# Allow running from repo root
sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import applier, mod_format

# ── Logging bridge ────────────────────────────────────────────────────────────

class _TextHandler(logging.Handler):
    """Redirect log records into the GUI log widget."""

    def __init__(self, widget: scrolledtext.ScrolledText):
        super().__init__()
        self._widget = widget

    def emit(self, record: logging.LogRecord):
        msg = self.format(record) + "\n"
        level = record.levelname
        self._widget.after(0, self._append, msg, level)

    def _append(self, msg: str, level: str):
        tag = {"WARNING": "warn", "ERROR": "err"}.get(level, "info")
        self._widget.configure(state="normal")
        self._widget.insert(tk.END, msg, tag)
        self._widget.see(tk.END)
        self._widget.configure(state="disabled")


# ── Main application ──────────────────────────────────────────────────────────

class ModTestApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("RUSE Mod Test GUI")
        self.resizable(True, True)
        self.minsize(780, 560)

        self._mod_vars: list[tuple[tk.BooleanVar, str]] = []  # (enabled, path)
        self._running = False

        self._build_ui()
        self._wire_logging()
        self._set_defaults()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── UI construction ────────────────────────────────────────────────────────

    def _build_ui(self):
        pad = {"padx": 6, "pady": 4}

        # ── Paths frame ───────────────────────────────────────────────────────
        paths = ttk.LabelFrame(self, text="Directories")
        paths.pack(fill="x", **pad)
        paths.columnconfigure(1, weight=1)

        ttk.Label(paths, text="Game Data:").grid(row=0, column=0, sticky="e", **pad)
        self._data_var = tk.StringVar()
        ttk.Entry(paths, textvariable=self._data_var).grid(
            row=0, column=1, sticky="ew", **pad)
        ttk.Button(paths, text="Browse…", command=self._browse_data).grid(
            row=0, column=2, **pad)

        ttk.Label(paths, text="Output Dir:").grid(row=1, column=0, sticky="e", **pad)
        self._out_var = tk.StringVar()
        ttk.Entry(paths, textvariable=self._out_var).grid(
            row=1, column=1, sticky="ew", **pad)
        ttk.Button(paths, text="Browse…", command=self._browse_out).grid(
            row=1, column=2, **pad)

        # ── Mods frame ────────────────────────────────────────────────────────
        mods_outer = ttk.LabelFrame(self, text="Mods  (checked = active)")
        mods_outer.pack(fill="both", expand=False, **pad)

        btn_bar = ttk.Frame(mods_outer)
        btn_bar.pack(fill="x", pady=(2, 0))
        ttk.Button(btn_bar, text="Add .rmod…", command=self._add_mods).pack(
            side="left", padx=4)
        ttk.Button(btn_bar, text="Remove selected", command=self._remove_selected).pack(
            side="left", padx=4)
        ttk.Button(btn_bar, text="Clear all", command=self._clear_mods).pack(
            side="left", padx=4)

        list_frame = ttk.Frame(mods_outer)
        list_frame.pack(fill="both", expand=True)

        # Up/Down order buttons — pack right-to-left so they reserve space first
        ord_btns = ttk.Frame(list_frame)
        ord_btns.pack(side="right", fill="y", padx=(2, 4), pady=4)
        ttk.Button(ord_btns, text="▲", width=3, command=self._move_up).pack(fill="x")
        ttk.Button(ord_btns, text="▼", width=3, command=self._move_down).pack(
            fill="x", pady=(2, 0))

        self._mod_listbox = tk.Listbox(list_frame, height=5, selectmode="extended",
                                       activestyle="dotbox")
        sb = ttk.Scrollbar(list_frame, orient="vertical",
                           command=self._mod_listbox.yview)
        self._mod_listbox.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", pady=4)
        self._mod_listbox.pack(side="left", fill="both", expand=True, padx=(4, 0), pady=4)
        self._mod_listbox.bind("<ButtonRelease-1>", self._on_listbox_click)
        self._mod_listbox.bind("<space>", self._toggle_selected)

        # ── Action buttons ────────────────────────────────────────────────────
        actions = ttk.Frame(self)
        actions.pack(fill="x", **pad)

        self._dry_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(actions, text="Dry run (no files written)",
                        variable=self._dry_var).pack(side="left", padx=4)

        ttk.Button(actions, text="Clear Log", command=self._clear_log).pack(
            side="right", padx=4)
        self._apply_btn = ttk.Button(actions, text="▶  Apply Mods",
                                     command=self._apply)
        self._apply_btn.pack(side="right", padx=4)

        # ── Log ───────────────────────────────────────────────────────────────
        log_frame = ttk.LabelFrame(self, text="Log")
        log_frame.pack(fill="both", expand=True, **pad)

        mono = font.Font(family="Consolas", size=9)
        self._log = scrolledtext.ScrolledText(log_frame, state="disabled",
                                              font=mono, wrap="none",
                                              height=18)
        self._log.pack(fill="both", expand=True, padx=4, pady=4)

        self._log.tag_configure("info",  foreground="#d4d4d4")
        self._log.tag_configure("warn",  foreground="#dcdcaa")
        self._log.tag_configure("err",   foreground="#f44747")
        self._log.tag_configure("ok",    foreground="#4ec9b0")
        self._log.tag_configure("head",  foreground="#9cdcfe", font=("Consolas", 9, "bold"))
        self._log.configure(background="#1e1e1e", insertbackground="white")

        # ── Status bar ────────────────────────────────────────────────────────
        self._status = tk.StringVar(value="Ready.")
        ttk.Label(self, textvariable=self._status, anchor="w").pack(
            fill="x", padx=6, pady=(0, 4))

    def _wire_logging(self):
        handler = _TextHandler(self._log)
        handler.setFormatter(logging.Formatter("%(levelname)s  %(message)s"))
        root_log = logging.getLogger()
        root_log.addHandler(handler)
        root_log.setLevel(logging.DEBUG)

    def _set_defaults(self):
        default_out = Path(__file__).parent.parent / "test_output"
        self._out_var.set(str(default_out))

        # Restore last session; fall back to scanning mods/ folder
        if not self._load_state():
            mods_dir = Path(__file__).parent.parent / "mods"
            if mods_dir.exists():
                for f in sorted(mods_dir.glob("*.rmod")):
                    self._add_mod_path(str(f))

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def _browse_data(self):
        d = filedialog.askdirectory(title="Select game Data/ directory")
        if d:
            self._data_var.set(d)

    def _browse_out(self):
        d = filedialog.askdirectory(title="Select output directory")
        if d:
            self._out_var.set(d)

    def _add_mods(self):
        paths = filedialog.askopenfilenames(
            title="Select .rmod files",
            filetypes=[("RUSE Mod files", "*.rmod"), ("All files", "*.*")],
        )
        for p in paths:
            self._add_mod_path(p)

    def _add_mod_path(self, path: str):
        for _, existing in self._mod_vars:
            if existing == path:
                return
        var = tk.BooleanVar(value=True)
        self._mod_vars.append((var, path))
        self._mod_listbox.insert(tk.END, self._mod_label(var, path))

    def _mod_label(self, var: tk.BooleanVar, path: str) -> str:
        check = "☑" if var.get() else "☐"
        return f"{check}  {Path(path).name}"

    def _refresh_listbox_item(self, idx: int):
        var, path = self._mod_vars[idx]
        self._mod_listbox.delete(idx)
        self._mod_listbox.insert(idx, self._mod_label(var, path))
        self._mod_listbox.selection_set(idx)

    def _on_listbox_click(self, event):
        """Toggle enabled only when the click lands on the ☑/☐ prefix."""
        idx = self._mod_listbox.nearest(event.y)
        if not (0 <= idx < len(self._mod_vars)):
            return
        bbox = self._mod_listbox.bbox(idx)
        if bbox is None:
            return
        lbfont = font.Font(font=self._mod_listbox.cget("font"))
        checkbox_width = lbfont.measure("☑  ")
        if event.x <= bbox[0] + checkbox_width:
            var, _ = self._mod_vars[idx]
            var.set(not var.get())
            self._refresh_listbox_item(idx)

    def _toggle_selected(self, _event=None):
        """Space-key toggle: flip enabled state of all selected items."""
        for idx in self._mod_listbox.curselection():
            var, _ = self._mod_vars[idx]
            var.set(not var.get())
            self._refresh_listbox_item(idx)

    def _move_up(self):
        sel = self._mod_listbox.curselection()
        if len(sel) != 1 or sel[0] == 0:
            return
        idx = sel[0]
        self._mod_vars[idx - 1], self._mod_vars[idx] = self._mod_vars[idx], self._mod_vars[idx - 1]
        self._rebuild_listbox(select_idx=idx - 1)

    def _move_down(self):
        sel = self._mod_listbox.curselection()
        if len(sel) != 1 or sel[0] >= len(self._mod_vars) - 1:
            return
        idx = sel[0]
        self._mod_vars[idx], self._mod_vars[idx + 1] = self._mod_vars[idx + 1], self._mod_vars[idx]
        self._rebuild_listbox(select_idx=idx + 1)

    def _rebuild_listbox(self, select_idx: int = -1):
        self._mod_listbox.delete(0, tk.END)
        for var, path in self._mod_vars:
            self._mod_listbox.insert(tk.END, self._mod_label(var, path))
        if 0 <= select_idx < len(self._mod_vars):
            self._mod_listbox.selection_set(select_idx)
            self._mod_listbox.see(select_idx)

    def _remove_selected(self):
        indices = list(self._mod_listbox.curselection())
        for i in reversed(indices):
            self._mod_listbox.delete(i)
            self._mod_vars.pop(i)

    def _clear_mods(self):
        self._mod_listbox.delete(0, tk.END)
        self._mod_vars.clear()

    def _clear_log(self):
        self._log.configure(state="normal")
        self._log.delete("1.0", tk.END)
        self._log.configure(state="disabled")

    # ── State persistence ─────────────────────────────────────────────────────

    def _on_close(self):
        self._save_state()
        self.destroy()

    def _save_state(self):
        state = {"mods": [{"path": path, "enabled": var.get()}
                          for var, path in self._mod_vars]}
        try:
            with open(_STATE_FILE, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception:
            pass

    def _load_state(self) -> bool:
        if not _STATE_FILE.exists():
            return False
        try:
            with open(_STATE_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)
            loaded = 0
            for entry in state.get("mods", []):
                path = entry.get("path", "")
                if Path(path).exists():
                    var = tk.BooleanVar(value=bool(entry.get("enabled", True)))
                    self._mod_vars.append((var, path))
                    self._mod_listbox.insert(tk.END, self._mod_label(var, path))
                    loaded += 1
            return loaded > 0
        except Exception:
            return False

    # ── Apply logic ───────────────────────────────────────────────────────────

    def _apply(self):
        if self._running:
            return

        data_dir = self._data_var.get().strip()
        out_dir = self._out_var.get().strip()
        dry = self._dry_var.get()

        active_mods = [path for var, path in self._mod_vars if var.get()]

        if not data_dir:
            messagebox.showerror("Missing input", "Please set the Game Data directory.")
            return
        if not Path(data_dir).exists():
            messagebox.showerror("Not found", f"Data directory not found:\n{data_dir}")
            return
        if not active_mods:
            messagebox.showinfo("No mods", "No mods are loaded or checked.")
            return
        if not out_dir and not dry:
            messagebox.showerror("Missing output",
                                 "Please set an output directory (or enable Dry Run).")
            return

        self._running = True
        self._apply_btn.configure(state="disabled")
        self._status.set("Applying mods…")

        t = threading.Thread(target=self._run_apply,
                             args=(data_dir, out_dir or None, dry, active_mods),
                             daemon=True)
        t.start()

    def _run_apply(self, data_dir: str, out_dir, dry: bool, mod_paths: list):
        try:
            self._log_head(f"{'[DRY RUN] ' if dry else ''}Applying {len(mod_paths)} mod(s)")
            self._log_head(f"  Data : {data_dir}")
            if out_dir:
                self._log_head(f"  Output: {out_dir}")
            self._log_head("")

            # Delete stale output dats so the first mod always starts from clean
            # game data; subsequent mods then chain onto each previous mod's output.
            if out_dir and not dry:
                applier.clear_output_dats(mod_paths, out_dir)

            all_results = []
            for mod_path in mod_paths:
                self._log_head(f"── {Path(mod_path).name} ──")
                try:
                    result = applier.apply_mod(
                        mod_path=mod_path,
                        game_data_dir=data_dir,
                        backup=False,
                        dry_run=dry,
                        output_dir=out_dir,
                    )
                    all_results.append(result)
                    self._log_summary(result)
                except Exception as e:
                    logging.getLogger().error("Unhandled error applying %s: %s",
                                             Path(mod_path).name, e)

            total_changes = sum(r.changes_applied for r in all_results)
            total_warns   = sum(len(r.warnings) for r in all_results)
            total_errors  = sum(len(r.errors) for r in all_results)

            self._log_head("")
            self._log_head(
                f"Done — {total_changes} change(s), "
                f"{total_warns} warning(s), {total_errors} error(s)"
            )
            if out_dir and not dry:
                self._log_head(f"Output written to: {out_dir}")

            status = (f"Done: {total_changes} changes applied" +
                      (f", {total_errors} error(s)" if total_errors else ""))
            self.after(0, lambda: self._status.set(status))
        finally:
            self.after(0, self._apply_done)

    def _apply_done(self):
        self._running = False
        self._apply_btn.configure(state="normal")

    # ── Log helpers ───────────────────────────────────────────────────────────

    def _log_head(self, msg: str):
        self._log.after(0, self._append_log, msg + "\n", "head")

    def _log_summary(self, result: applier.ApplyResult):
        def _do():
            self._log.configure(state="normal")
            # Per-change records
            for rec in result.change_log:
                line = (f"  {rec.table}[{rec.instance_id}]"
                        f".{rec.prop}:  {rec.old_val}  →  {rec.new_val}\n")
                self._log.insert(tk.END, line, "ok")
            # Warnings
            for w in result.warnings:
                self._log.insert(tk.END, f"  WARN  {w}\n", "warn")
            # Errors
            for e in result.errors:
                self._log.insert(tk.END, f"  ERROR {e}\n", "err")
            # Summary line
            self._log.insert(tk.END, f"  {result.summary()}\n", "info")
            self._log.see(tk.END)
            self._log.configure(state="disabled")
        self._log.after(0, _do)

    def _append_log(self, msg: str, tag: str):
        self._log.configure(state="normal")
        self._log.insert(tk.END, msg, tag)
        self._log.see(tk.END)
        self._log.configure(state="disabled")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = ModTestApp()
    app.mainloop()
