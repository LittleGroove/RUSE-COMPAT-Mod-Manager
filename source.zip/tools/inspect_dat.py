"""
inspect_dat.py — list and inspect the contents of a RUSE .dat archive.

Usage:
  python tools/inspect_dat.py <path/to/file.dat>
  python tools/inspect_dat.py <path/to/file.dat> --filter ndfbin
  python tools/inspect_dat.py <path/to/file.dat> --extract <internal/path> --out out.bin
"""

import argparse
import sys
from pathlib import Path

# Allow running from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import edata as edata_mod


def main():
    parser = argparse.ArgumentParser(
        description="List and extract files from a RUSE .dat archive",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("dat", help="Path to the .dat file")
    parser.add_argument("--filter", "-f", help="Only show entries whose path contains this string")
    parser.add_argument("--extract", "-e", help="Extract this specific internal path to stdout or --out")
    parser.add_argument("--out", "-o", help="Write extracted file to this path (default: stdout)")
    parser.add_argument("--extract-all", "-a", help="Extract ALL files to this directory")
    args = parser.parse_args()

    dat_path = args.dat
    if not Path(dat_path).exists():
        print(f"ERROR: File not found: {dat_path}", file=sys.stderr)
        sys.exit(1)

    try:
        edat = edata_mod.open_dat(dat_path)
    except Exception as e:
        print(f"ERROR: Could not open {dat_path}: {e}", file=sys.stderr)
        sys.exit(1)

    if args.extract_all:
        out_dir = args.extract_all
        print(f"Extracting all files to: {out_dir}")
        edat.extract_all(out_dir)
        print(f"Done — {len(edat.list())} files extracted.")
        return

    if args.extract:
        data = edat.get(args.extract)
        if data is None:
            print(f"ERROR: Internal path not found: {args.extract}", file=sys.stderr)
            print("Available files:")
            for p in edat.list():
                print(f"  {p}")
            sys.exit(1)
        if args.out:
            Path(args.out).write_bytes(data)
            print(f"Wrote {len(data):,} bytes → {args.out}")
        else:
            sys.stdout.buffer.write(data)
        return

    # List mode
    entries = edat.list()
    if args.filter:
        f = args.filter.lower()
        entries = [p for p in entries if f in p.lower()]

    hdr = edat._header
    print(f"Archive:  {dat_path}")
    print(f"Version:  v{hdr.version}")
    print(f"Files:    {len(edat._entries)} total, {len(entries)} shown")
    print()

    max_len = max((len(p) for p in entries), default=10)
    for entry_path in entries:
        entry = edat._entry_map.get(entry_path.replace("\\", "/").lower())
        if entry:
            size_str = f"{entry.size:>12,} bytes"
            cs_str = entry.checksum.hex()[:8] if entry.checksum else "--------"
            print(f"  {entry_path:<{max_len}}  {size_str}  {cs_str}")
        else:
            print(f"  {entry_path}")


if __name__ == "__main__":
    main()
