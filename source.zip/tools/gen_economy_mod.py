"""
Generate example_cheat_economy.rmod with actual cheat values.

Reads original prices from the NDF, applies offsets/overrides, writes the mod.

Usage:
    python tools/gen_economy_mod.py [--mode plus5 | flat10 | flat1]
"""
import sys
import json
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

# ── Config ─────────────────────────────────────────────────────────────────────

DAT = r"Claude\sources\RUSE-game\Data\PC\99\ZZ_GladPatchableWin.dat"
NDF_EVERYTHING = r"genglad\patchable\clustergfx\everything.cpp.gladndfbin"
NDF_CONSTANTE  = r"genglad\patchable\clustergfx\everythinggdconstanteoriginal.cpp.gladndfbin"

UNIT_CLASSES = [
    "TUniteAuSolDescriptor",
    "TInfanterieDescriptor",
    "TAvionDescriptor",
    "TTruckDescriptor",
]
BUILDING_CLASS = "TBatimentDescriptor"

CONSTANTE_OVERRIDES = {
    "QteDeviseInitiale":            9999,
    "QuantiteGenAutoDevises":       99,
    "QteDeviseParCamion":           99,
    "NbCamionParConvoi":            4,
    "TempsENtreDeuxConvois":        30,
    "StockDeviseSupplementaireFacile": 9999,
}


AIRCRAFT_CLASSES = {"TAvionDescriptor"}


def compute_price(original: list[int], mode: str, keep_last: bool = False) -> list[int]:
    """keep_last: preserve original element[4] (aircraft cheat-mod convention)."""
    if mode == "plus5":
        result = [v + 5 for v in original]
    elif mode == "flat10":
        result = [10] * len(original)
    elif mode == "flat1":
        result = [1] * len(original)
    else:
        raise ValueError(f"Unknown mode: {mode}")
    if keep_last and len(original) >= 5:
        result[-1] = original[-1]
    return result


def build_unit_changes(ndf, mode: str, skip_upgrade: bool = False) -> list[dict]:
    changes = []
    for cls_name in UNIT_CLASSES:
        cls = ndf.class_by_name(cls_name)
        if cls is None:
            print(f"  WARNING: class {cls_name!r} not found — skipping")
            continue
        prod_prop  = ndf.prop_by_name_and_class("ProductionPrice", cls.index)
        time_prop  = ndf.prop_by_name_and_class("ProductionTime", cls.index)
        debug_prop = ndf.prop_by_name_and_class("ClassNameForDebug", cls.index)
        upg_prop   = ndf.prop_by_name_and_class("UpgradePrice", cls.index)
        is_aircraft = cls_name in AIRCRAFT_CLASSES

        inst_count = 0
        for inst in ndf.instances:
            if inst.class_index != cls.index:
                continue
            if prod_prop is None:
                continue
            pp_v = inst.get(prod_prop.index)
            if pp_v is None:
                continue

            original = ndf.resolve_value(pp_v)
            if not isinstance(original, list):
                continue

            # Aircraft: keep last element at original (cheat-mod convention)
            new_price = compute_price(original, mode, keep_last=is_aircraft)
            name_v = inst.get(debug_prop.index) if debug_prop else None
            name = str(ndf.resolve_value(name_v)) if name_v else None
            if name is None:
                continue

            change: dict = {
                "action": "patch",
                "table": cls_name,
                "match": {"ClassNameForDebug": name},
                "set": {
                    "ProductionPrice": {
                        "type": "List<Int32>",
                        "value": new_price,
                    }
                },
            }

            # Always change ProductionTime alongside price (mirrors working cheat mod)
            if time_prop:
                tv = inst.get(time_prop.index)
                if tv is not None:
                    change["set"]["ProductionTime"] = {"type": "Int32", "value": 1}

            # Also patch UpgradePrice if present and > 0
            if upg_prop and not skip_upgrade:
                upg_v = inst.get(upg_prop.index)
                if upg_v is not None:
                    orig_upg = ndf.resolve_value(upg_v)
                    if isinstance(orig_upg, int) and orig_upg > 0:
                        new_upg = max(1, orig_upg + 5) if mode == "plus5" else (10 if mode == "flat10" else 1)
                        change["set"]["UpgradePrice"] = {"type": "Int32", "value": new_upg}

            changes.append(change)
            inst_count += 1

        print(f"  {cls_name}: {inst_count} unit(s)")
    return changes


def build_building_changes(ndf, mode: str) -> list[dict]:
    changes = []
    cls = ndf.class_by_name(BUILDING_CLASS)
    if cls is None:
        print(f"  WARNING: class {BUILDING_CLASS!r} not found")
        return changes
    prod_prop  = ndf.prop_by_name_and_class("ProductionPrice", cls.index)
    debug_prop = ndf.prop_by_name_and_class("ClassNameForDebug", cls.index)
    if prod_prop is None:
        print(f"  WARNING: ProductionPrice not found on {BUILDING_CLASS}")
        return changes

    count = 0
    for inst in ndf.instances:
        if inst.class_index != cls.index:
            continue
        pp_v = inst.get(prod_prop.index)
        if pp_v is None:
            continue
        original = ndf.resolve_value(pp_v)
        if not isinstance(original, list):
            continue
        name_v = inst.get(debug_prop.index) if debug_prop else None
        name = str(ndf.resolve_value(name_v)) if name_v else None
        if name is None:
            continue
        changes.append({
            "action": "patch",
            "table": BUILDING_CLASS,
            "match": {"ClassNameForDebug": name},
            "set": {
                "ProductionPrice": {
                    "type": "List<Int32>",
                    "value": compute_price(original, mode),
                }
            },
        })
        count += 1
    print(f"  {BUILDING_CLASS}: {count} building(s)")
    return changes


def build_constante_changes(ndf) -> list[dict]:
    changes = []
    for const_name, new_val in CONSTANTE_OVERRIDES.items():
        prop = ndf.prop_by_name(const_name)
        if prop is None:
            print(f"  WARNING: {const_name!r} not found in constante NDF")
            continue
        # Detect type
        for inst in ndf.instances:
            v = inst.get(prop.index)
            if v is not None:
                type_map = {
                    ndfbin_mod.T.Int32: "Int32",
                    ndfbin_mod.T.UInt32: "UInt32",
                    ndfbin_mod.T.Float32: "Float32",
                    ndfbin_mod.T.Float64: "Float64",
                }
                type_name = type_map.get(v.type_id, "Int32")
                changes.append({
                    "action": "patch",
                    "table": "TTunableConstante",
                    "match": {},
                    "set": {
                        const_name: {"type": type_name, "value": new_val},
                    },
                })
                break
    return changes


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["plus5", "flat10", "flat1"], default="plus5")
    parser.add_argument("--no-units",    action="store_true", help="Skip ground/air/infantry unit prices")
    parser.add_argument("--no-buildings", action="store_true", help="Skip building prices")
    parser.add_argument("--no-constants", action="store_true", help="Skip TTunableConstante changes")
    parser.add_argument("--no-upgrade",   action="store_true", help="Skip UpgradePrice changes")
    parser.add_argument("--classes",      nargs="*",           help="Only include these classes (e.g. TUniteAuSolDescriptor)")
    args = parser.parse_args()
    mode = args.mode

    root = Path(__file__).parent.parent
    dat_path = root / DAT

    print(f"Opening {dat_path.name}…")
    edat = edata_mod.open_dat(str(dat_path))

    ndf_bytes = edat.get(NDF_EVERYTHING.replace("/", "\\"))
    if ndf_bytes is None:
        ndf_bytes = edat.get(NDF_EVERYTHING)
    print("Parsing everything NDF…")
    ndf = ndfbin_mod.read(ndf_bytes)

    ndf_const_bytes = edat.get(NDF_CONSTANTE.replace("/", "\\"))
    if ndf_const_bytes is None:
        ndf_const_bytes = edat.get(NDF_CONSTANTE)
    print("Parsing constante NDF…")
    ndf_const = ndfbin_mod.read(ndf_const_bytes)

    # Filter unit classes if --classes is specified
    global UNIT_CLASSES
    if args.classes:
        UNIT_CLASSES = [c for c in UNIT_CLASSES if c in args.classes]
        building_cls_included = BUILDING_CLASS in args.classes
    else:
        building_cls_included = True

    print(f"\nBuilding unit changes (mode={mode})…")
    unit_changes = [] if args.no_units else build_unit_changes(ndf, mode, skip_upgrade=args.no_upgrade)

    print(f"\nBuilding building changes (mode={mode})…")
    building_changes = [] if (args.no_buildings or (args.classes and not building_cls_included)) else build_building_changes(ndf, mode)

    print(f"\nBuilding TTunableConstante changes…")
    constante_changes = [] if args.no_constants else build_constante_changes(ndf_const)

    all_everything_changes = unit_changes + building_changes

    mode_desc = {
        "plus5":  "all prices + $5 above original values",
        "flat10": "all prices set to $10",
        "flat1":  "all prices set to $1",
    }

    mod = {
        "$schema": "ruse-mod/v1",
        "id": "example-cheat-economy",
        "name": "Cheat Economy",
        "version": "1.0.0",
        "author": "Example",
        "description": (
            f"Economy cheat mod — {mode_desc[mode]}. "
            "TTunableConstante: 9999 starting money, 99 income/tick, 99/truck, "
            "4 trucks/convoy, 30s convoy interval, 9999 easy bonus."
        ),
        "patches": [
            {
                "dat": "PC/99/ZZ_GladPatchableWin.dat",
                "ndf": "genglad/patchable/clustergfx/everything.cpp.gladndfbin",
                "changes": all_everything_changes,
            },
            {
                "dat": "PC/99/ZZ_GladPatchableWin.dat",
                "ndf": "genglad/patchable/clustergfx/everythinggdconstanteoriginal.cpp.gladndfbin",
                "changes": constante_changes,
            },
        ],
    }

    out_path = root / "mods" / "example_cheat_economy.rmod"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(mod, f, indent=2, ensure_ascii=False)

    total = len(all_everything_changes) + len(constante_changes)
    print(f"\nWrote {out_path.name}: {total} total changes "
          f"({len(unit_changes)} units, {len(building_changes)} buildings, "
          f"{len(constante_changes)} constants)")


if __name__ == "__main__":
    main()
