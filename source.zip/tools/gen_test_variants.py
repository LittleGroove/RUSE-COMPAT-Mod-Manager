"""Generate test mod variants to binary-search which class causes slow loading."""
import sys, json, logging
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
logging.basicConfig(level=logging.WARNING)

from tools.gen_economy_mod import (
    build_unit_changes, build_building_changes, build_constante_changes,
    DAT, NDF_EVERYTHING, NDF_CONSTANTE, UNIT_CLASSES, BUILDING_CLASS
)
from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

root = Path(__file__).parent.parent
edat = edata_mod.open_dat(str(root / DAT))

NDF_BS = NDF_EVERYTHING.replace("/", "\\")
CONST_BS = NDF_CONSTANTE.replace("/", "\\")

ndf = ndfbin_mod.read(edat.get(NDF_BS))
ndf_const = ndfbin_mod.read(edat.get(CONST_BS))


def make_mod(name: str, unit_cls_list: list, include_buildings: bool,
             include_constants: bool, skip_upgrade: bool = False):
    import tools.gen_economy_mod as gm
    saved = gm.UNIT_CLASSES[:]
    gm.UNIT_CLASSES = unit_cls_list
    unit_ch = gm.build_unit_changes(ndf, "plus5", skip_upgrade=skip_upgrade)
    gm.UNIT_CLASSES = saved

    bld_ch = gm.build_building_changes(ndf, "plus5") if include_buildings else []
    const_ch = gm.build_constante_changes(ndf_const) if include_constants else []

    all_ev = unit_ch + bld_ch
    patches = []
    if all_ev:
        patches.append({
            "dat": "PC/99/ZZ_GladPatchableWin.dat",
            "ndf": "genglad/patchable/clustergfx/everything.cpp.gladndfbin",
            "changes": all_ev,
        })
    if const_ch:
        patches.append({
            "dat": "PC/99/ZZ_GladPatchableWin.dat",
            "ndf": "genglad/patchable/clustergfx/everythinggdconstanteoriginal.cpp.gladndfbin",
            "changes": const_ch,
        })

    mod = {
        "$schema": "ruse-mod/v1",
        "id": name, "name": name, "version": "1.0.0",
        "author": "Test", "description": name,
        "patches": patches,
    }
    out = root / "mods" / f"{name}.rmod"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(mod, f, indent=2)
    print(f"  {name}.rmod  ({len(all_ev) + len(const_ch)} changes)")


print("Generating test variants...")
# A: TTunableConstante only — known to work, baseline
make_mod("test_A_constants_only",
         [], False, True)

# B: Ground + infantry + trucks (no aircraft, no buildings, no upgrade)
make_mod("test_B_ground_infantry_trucks",
         ["TUniteAuSolDescriptor", "TInfanterieDescriptor", "TTruckDescriptor"],
         False, False)

# C: Aircraft ProductionPrice only (no UpgradePrice)
make_mod("test_C_aircraft_no_upgrade",
         ["TAvionDescriptor"], False, False, skip_upgrade=True)

# D: Aircraft WITH UpgradePrice
make_mod("test_D_aircraft_with_upgrade",
         ["TAvionDescriptor"], False, False, skip_upgrade=False)

# E: Buildings only
make_mod("test_E_buildings_only",
         [], True, False)

print("\nTest order (each loads fast if OK, slow if it contains the bad property):")
print("  1. test_A  — should always be fast (known good)")
print("  2. test_B  — ground units + infantry + trucks")
print("  3. test_C  — aircraft ProductionPrice only")
print("  4. test_D  — aircraft WITH UpgradePrice")
print("  5. test_E  — buildings only")
print("\nIf B/C/E all load fast => it was the UpgradePrice (D proves it).")
print("If B is slow => culprit is in ground units or infantry.")
