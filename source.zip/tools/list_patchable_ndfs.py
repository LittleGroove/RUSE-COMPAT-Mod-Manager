import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata

DAT = 'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat'
arc = edata.open_dat(DAT)
entries = [e for e in arc._entries if e.path.lower().endswith('.gladndfbin')]
print(f'{len(entries)} NDF entries:')
for e in sorted(entries, key=lambda x: x.path):
    print(f'  {e.path}')
