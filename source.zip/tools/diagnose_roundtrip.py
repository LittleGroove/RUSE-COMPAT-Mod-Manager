"""
Two-stage diagnostic:

Stage 1 — Round-trip test
  Read original everything.cpp.gladndfbin → write without changes → re-read →
  compare every instance/property semantically.  Any mismatch = writer bug.

Stage 2 — Patch verification
  Apply cheat_mod_v1.2.rmod to a fresh copy of the original DAT (in memory),
  then do a full semantic diff between our result and the original Cheat Mod v1.2 DAT.
  Any remaining differences = wrong patch values / missing changes.

Run:
    python tools/diagnose_roundtrip.py
"""
import shutil, sys, tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod, mod_format, applier

ROOT      = Path(__file__).parent.parent
ORIG_DAT  = ROOT / "Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat"
CHEAT_DAT = ROOT / "Claude/sources/currently_used_mod_files/Cheat Mod v1.2/99/ZZ_GladPatchableWin.dat"
RMOD      = ROOT / "mods/cheat_mod_v1.2.rmod"
NDF_PATH  = "genglad\\patchable\\clustergfx\\everything.cpp.gladndfbin"

FAIL = "FAIL"
OK   = "OK  "


# ── helpers ───────────────────────────────────────────────────────────────────

def ndf_semantic_snapshot(ndf):
    """Return {(class_name, inst_idx): {prop_name: resolved_str}} for every instance."""
    snap = {}
    for idx, inst in enumerate(ndf.instances):
        cls = ndf.classes[inst.class_index]
        props = {}
        for pv in inst.props:
            prop = next((p for p in ndf.properties if p.index == pv.prop_index), None)
            pname = prop.name if prop else f"prop#{pv.prop_index}"
            props[pname] = str(ndf.resolve_value(pv.value))
        snap[(cls.name, idx)] = props
    return snap


def diff_snapshots(snap_a, snap_b, label_a="A", label_b="B"):
    """Return list of diff strings between two snapshots."""
    diffs = []
    all_keys = set(snap_a) | set(snap_b)
    for key in sorted(all_keys):
        cls_name, idx = key
        if key not in snap_a:
            diffs.append(f"  ADDED   {cls_name}[{idx}] (in {label_b} only)")
            continue
        if key not in snap_b:
            diffs.append(f"  REMOVED {cls_name}[{idx}] (in {label_a} only)")
            continue
        pa, pb = snap_a[key], snap_b[key]
        for prop in set(pa) | set(pb):
            va = pa.get(prop, "<absent>")
            vb = pb.get(prop, "<absent>")
            if va != vb:
                diffs.append(f"  {cls_name}[{idx}].{prop}: {va!r} -> {vb!r}")
    return diffs


# ── Stage 1: Round-trip ───────────────────────────────────────────────────────

print("=" * 70)
print("Stage 1: Round-trip test (read original NDF -> write -> re-read -> compare)")
print("=" * 70)

orig_edat = edata_mod.open_dat(str(ORIG_DAT))
orig_ndf_bytes = orig_edat.get(NDF_PATH)
if orig_ndf_bytes is None:
    print(f"{FAIL} Could not find {NDF_PATH} in original DAT")
    sys.exit(1)

print(f"Original NDF bytes: {len(orig_ndf_bytes):,}")

ndf_orig = ndfbin_mod.read(orig_ndf_bytes)
print(f"Parsed: {len(ndf_orig.instances):,} instances, "
      f"{len(ndf_orig.classes)} classes, "
      f"{len(ndf_orig.properties)} properties, "
      f"{len(ndf_orig.strings)} strings")
print(f"is_compressed: {ndf_orig.is_compressed}")

# Write back without any changes
roundtrip_bytes = ndfbin_mod.write(ndf_orig, compress=ndf_orig.is_compressed)
print(f"Re-serialised bytes: {len(roundtrip_bytes):,}")

# Re-read the round-tripped bytes
ndf_rt = ndfbin_mod.read(roundtrip_bytes)
print(f"Re-parsed: {len(ndf_rt.instances):,} instances, "
      f"{len(ndf_rt.classes)} classes, "
      f"{len(ndf_rt.properties)} properties")

print("\nBuilding semantic snapshots…")
snap_orig = ndf_semantic_snapshot(ndf_orig)
snap_rt   = ndf_semantic_snapshot(ndf_rt)

rt_diffs = diff_snapshots(snap_orig, snap_rt, "original", "round-trip")
if rt_diffs:
    print(f"{FAIL} Round-trip has {len(rt_diffs)} semantic difference(s):")
    for d in rt_diffs[:50]:
        print(d)
    if len(rt_diffs) > 50:
        print(f"  ... and {len(rt_diffs) - 50} more")
else:
    print(f"{OK} Round-trip is semantically IDENTICAL ({len(snap_orig):,} instances checked)")

if len(orig_ndf_bytes) != len(roundtrip_bytes):
    print(f"  Note: byte sizes differ: orig={len(orig_ndf_bytes):,}  rt={len(roundtrip_bytes):,}")
    print("  (different size is OK as long as semantics match)")


# ── Stage 2: Patch vs cheat mod ───────────────────────────────────────────────

print()
print("=" * 70)
print("Stage 2: rmod-patched output vs original Cheat Mod v1.2")
print("=" * 70)

# Apply our rmod to a temp copy of the original DAT
# game_data_dir = .../Data/  ; rmod dat field = "PC/99/ZZ_GladPatchableWin.dat"
# applier copies to: tmpdir/PC/99/ZZ_GladPatchableWin.dat
with tempfile.TemporaryDirectory() as tmpdir:
    results = applier.apply_mod(
        mod_path=str(RMOD),
        game_data_dir=str(ORIG_DAT.parent.parent.parent),  # .../Data/
        backup=False,
        output_dir=tmpdir,
    )
    print(f"apply_mod result: {results.summary()}")
    if results.warnings:
        print(f"  Warnings ({len(results.warnings)}):")
        for w in results.warnings[:10]:
            print(f"    {w}")
    if results.errors:
        print(f"  ERRORS:")
        for e in results.errors:
            print(f"    {e}")

    # The applier writes to tmpdir/PC/99/ZZ_GladPatchableWin.dat
    patched_dat_path = Path(tmpdir) / "PC" / "99" / "ZZ_GladPatchableWin.dat"
    if not patched_dat_path.exists():
        print(f"FAIL Patched DAT not found at {patched_dat_path}")
        sys.exit(1)

    our_edat  = edata_mod.open_dat(str(patched_dat_path))
    our_bytes = our_edat.get(NDF_PATH)

if our_bytes is None:
    print(f"{FAIL} Could not find NDF in our patched DAT")
    sys.exit(1)

our_ndf = ndfbin_mod.read(our_bytes)
print(f"Our patched NDF: {len(our_bytes):,} bytes, {len(our_ndf.instances):,} instances")

# Read cheat mod NDF
cheat_edat  = edata_mod.open_dat(str(CHEAT_DAT))
cheat_bytes = cheat_edat.get(NDF_PATH)
cheat_ndf   = ndfbin_mod.read(cheat_bytes)
print(f"Cheat mod NDF:   {len(cheat_bytes):,} bytes, {len(cheat_ndf.instances):,} instances")

print("\nBuilding semantic snapshots…")
snap_ours  = ndf_semantic_snapshot(our_ndf)
snap_cheat = ndf_semantic_snapshot(cheat_ndf)

patch_diffs = diff_snapshots(snap_ours, snap_cheat, "ours", "cheat-mod")
if patch_diffs:
    print(f"{FAIL} {len(patch_diffs)} semantic difference(s) between our patch and cheat mod:")
    for d in patch_diffs[:80]:
        print(d)
    if len(patch_diffs) > 80:
        print(f"  ... and {len(patch_diffs) - 80} more")
else:
    print(f"{OK} Our patched result is semantically IDENTICAL to the Cheat Mod v1.2")

print()
print("Done.")
