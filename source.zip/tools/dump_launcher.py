import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata
import ruse_mod_engine.ndfbin as ndfbin

DAT = 'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat'
NDF_PATH = 'genglad/patchable/clustergfx/everythinggdconstantevisibilityia/launcher.cpp.gladndfbin'

arc = edata.open_dat(DAT)
entry = None
for e in arc._entries:
    p = e.path.replace('\\', '/').lower()
    if 'launcher.cpp.gladndfbin' in p:
        print('Found entry:', e.path)
        entry = e
        break

if entry is None:
    print('Entry not found!')
    sys.exit(1)

ndf = ndfbin.read(arc.get(entry.path))

cls_by_idx = {c.index: c.name for c in ndf.classes}
prop_by_idx = {p.index: p.name for p in ndf.properties}

OBJ_REF_MARKER = ndfbin.OBJ_REF_MARKER
TRANS_REF_MARKER = ndfbin.TRANS_REF_MARKER

def fmt_val(val):
    t = val.type_id
    r = val.raw
    if t == ndfbin.T.Reference:
        marker, ref = r
        if marker == OBJ_REF_MARKER:
            obj_idx, cls_idx = ref
            cls_name = cls_by_idx.get(cls_idx, f'cls_{cls_idx}')
            return f'ObjRef(inst={obj_idx}, cls={cls_name})'
        if marker == TRANS_REF_MARKER:
            return f'TransRef({ref})'
        return f'Ref(marker={marker:08X})'
    if t == ndfbin.T.Map:
        pairs = [(fmt_val(k), fmt_val(v)) for k, v in r]
        return 'Map{' + ', '.join(f'{k}->{v}' for k, v in pairs) + '}'
    if t == ndfbin.T.List:
        items = [fmt_val(x) for x in r]
        return '[' + ', '.join(items) + ']'
    if t == ndfbin.T.StringRef:
        return repr(ndf.strings[r] if isinstance(r, int) and r < len(ndf.strings) else r)
    return repr(r)[:120]

for i, inst in enumerate(ndf.instances):
    cls = cls_by_idx.get(inst.class_index, '?')
    print(f'[{i}] {cls}')
    for pv in inst.props:
        pname = prop_by_idx.get(pv.prop_index, f'prop_{pv.prop_index}')
        print(f'  {pname}: {fmt_val(pv.value)}')
