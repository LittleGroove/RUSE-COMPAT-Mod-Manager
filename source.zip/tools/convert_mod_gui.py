"""
RUSE Mod Converter GUI
======================
Takes an old-style mod folder (containing .dat replacement files) and converts
it to a surgical .rmod patch file by diffing each modified .dat against the
original game data.

Usage:
    python tools/convert_mod_gui.py
"""

import json
import logging
import re
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, font, messagebox, scrolledtext, ttk

sys.path.insert(0, str(Path(__file__).parent.parent))
from ruse_mod_engine.converter import (
    scan_mod_folder, run_conversion,
    name_to_id as _name_to_id,
    sanitize_filename as _sanitize_filename,
)

_STATE_FILE = Path(__file__).parent / ".convert_mod_gui_state.json"

log = logging.getLogger(__name__)


# ── Logging bridge ────────────────────────────────────────────────────────────

class _TextHandler(logging.Handler):
    def __init__(self, widget):
        super().__init__()
        self._widget = widget

    def emit(self, record):
        msg = self.format(record) + "\n"
        level = record.levelname
        self._widget.after(0, self._append, msg, level)

    def _append(self, msg, level):
        tag = {"WARNING": "warn", "ERROR": "err"}.get(level, "info")
        self._widget.configure(state="normal")
        self._widget.insert(tk.END, msg, tag)
        self._widget.see(tk.END)
        self._widget.configure(state="disabled")


# ── GUI ───────────────────────────────────────────────────────────────────────

def _name_to_id(name: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", name.lower()).strip("-")
    return slug or "my-mod"


def _sanitize_filename(name: str) -> str:
    """Convert a mod name to a safe filename stem (no extension).
    Strips characters illegal on Windows/POSIX and collapses whitespace."""
    safe = re.sub(r'[\\/:*?"<>|]', "", name)   # remove illegal chars
    safe = re.sub(r"\s+", "_", safe.strip())    # spaces → underscores
    return safe or "mod"


class ConvertModApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("RUSE Mod Converter")
        self.resizable(True, True)
        self.minsize(820, 620)
        self._running = False
        self._build_ui()
        self._wire_logging()
        self._load_state()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── UI construction ────────────────────────────────────────────────────────

    def _build_ui(self):
        pad = {"padx": 6, "pady": 4}

        # ── Directories ───────────────────────────────────────────────────────
        dirs_frame = ttk.LabelFrame(self, text="Directories")
        dirs_frame.pack(fill="x", **pad)
        dirs_frame.columnconfigure(1, weight=1)

        rows = [
            ("Original Game Data:", "_data_var",   self._browse_data),
            ("Mod Folder:",         "_mod_var",    self._browse_mod),
            ("Output Folder:",      "_output_var", self._browse_output),
        ]
        for row_idx, (label, attr, cmd) in enumerate(rows):
            ttk.Label(dirs_frame, text=label).grid(
                row=row_idx, column=0, sticky="e", **pad)
            var = tk.StringVar()
            setattr(self, attr, var)
            ttk.Entry(dirs_frame, textvariable=var).grid(
                row=row_idx, column=1, sticky="ew", **pad)
            ttk.Button(dirs_frame, text="Browse…", command=cmd).grid(
                row=row_idx, column=2, **pad)

        self._filename_preview_var = tk.StringVar(value="")
        ttk.Label(dirs_frame, textvariable=self._filename_preview_var,
                  foreground="gray").grid(row=3, column=1, sticky="w",
                                          padx=6, pady=(0, 4))

        # ── Mod Info ──────────────────────────────────────────────────────────
        info_frame = ttk.LabelFrame(self, text="Mod Info")
        info_frame.pack(fill="x", **pad)
        info_frame.columnconfigure(1, weight=2)
        info_frame.columnconfigure(3, weight=1)

        ttk.Label(info_frame, text="Name:").grid(row=0, column=0, sticky="e", **pad)
        self._name_var = tk.StringVar()
        self._name_var.trace_add("write", lambda *_: self._update_filename_preview())
        name_entry = ttk.Entry(info_frame, textvariable=self._name_var)
        name_entry.grid(row=0, column=1, sticky="ew", **pad)
        name_entry.bind("<FocusOut>", self._auto_fill_id)

        ttk.Label(info_frame, text="ID:").grid(row=0, column=2, sticky="e", **pad)
        self._id_var = tk.StringVar()
        ttk.Entry(info_frame, textvariable=self._id_var).grid(
            row=0, column=3, sticky="ew", **pad)

        ttk.Label(info_frame, text="Version:").grid(row=0, column=4, sticky="e", **pad)
        self._ver_var = tk.StringVar(value="1.0.0")
        ttk.Entry(info_frame, textvariable=self._ver_var, width=8).grid(
            row=0, column=5, sticky="ew", **pad)

        ttk.Label(info_frame, text="Author:").grid(row=1, column=0, sticky="e", **pad)
        self._author_var = tk.StringVar()
        ttk.Entry(info_frame, textvariable=self._author_var).grid(
            row=1, column=1, sticky="ew", **pad)

        ttk.Label(info_frame, text="Description:").grid(
            row=1, column=2, sticky="e", **pad)
        self._desc_var = tk.StringVar()
        ttk.Entry(info_frame, textvariable=self._desc_var).grid(
            row=1, column=3, columnspan=3, sticky="ew", **pad)

        # ── Detected Files ────────────────────────────────────────────────────
        detected_outer = ttk.LabelFrame(self, text="Detected .dat Files")
        detected_outer.pack(fill="both", expand=False, **pad)

        scan_bar = ttk.Frame(detected_outer)
        scan_bar.pack(fill="x", pady=(2, 0))
        ttk.Button(scan_bar, text="Scan for changes", command=self._scan).pack(
            side="left", padx=4)
        self._scan_status = tk.StringVar(value="")
        ttk.Label(scan_bar, textvariable=self._scan_status,
                  foreground="gray").pack(side="left", padx=8)

        list_frame = ttk.Frame(detected_outer)
        list_frame.pack(fill="both", expand=True)
        self._file_listbox = tk.Listbox(list_frame, height=4,
                                        selectmode="browse", activestyle="none")
        sb = ttk.Scrollbar(list_frame, orient="vertical",
                           command=self._file_listbox.yview)
        self._file_listbox.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", pady=4)
        self._file_listbox.pack(side="left", fill="both", expand=True,
                                padx=(4, 0), pady=4)

        # ── Action buttons ────────────────────────────────────────────────────
        actions = ttk.Frame(self)
        actions.pack(fill="x", **pad)
        ttk.Button(actions, text="Clear Log",
                   command=self._clear_log).pack(side="right", padx=4)
        self._convert_btn = ttk.Button(actions, text="▶  Convert to .rmod",
                                       command=self._convert)
        self._convert_btn.pack(side="right", padx=4)

        # ── Log ───────────────────────────────────────────────────────────────
        log_frame = ttk.LabelFrame(self, text="Log")
        log_frame.pack(fill="both", expand=True, **pad)

        mono = font.Font(family="Consolas", size=9)
        self._log = scrolledtext.ScrolledText(log_frame, state="disabled",
                                              font=mono, wrap="none", height=16)
        self._log.pack(fill="both", expand=True, padx=4, pady=4)
        self._log.tag_configure("info", foreground="#d4d4d4")
        self._log.tag_configure("warn", foreground="#dcdcaa")
        self._log.tag_configure("err",  foreground="#f44747")
        self._log.tag_configure("ok",   foreground="#4ec9b0")
        self._log.tag_configure("head", foreground="#9cdcfe",
                                font=("Consolas", 9, "bold"))
        self._log.configure(background="#1e1e1e")

        # ── Status bar ────────────────────────────────────────────────────────
        self._status = tk.StringVar(value="Ready.")
        ttk.Label(self, textvariable=self._status, anchor="w").pack(
            fill="x", padx=6, pady=(0, 4))

    def _wire_logging(self):
        handler = _TextHandler(self._log)
        handler.setFormatter(logging.Formatter("%(levelname)s  %(message)s"))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(logging.DEBUG)

    # ── Browse callbacks ───────────────────────────────────────────────────────

    def _browse_data(self):
        d = filedialog.askdirectory(title="Select original game Data/ directory")
        if d:
            self._data_var.set(d)

    def _browse_mod(self):
        d = filedialog.askdirectory(title="Select mod folder (contains 99/ or 1360/ etc.)")
        if d:
            self._mod_var.set(d)
            self._auto_fill_from_folder(d)

    def _browse_output(self):
        d = filedialog.askdirectory(title="Select output folder for .rmod file")
        if d:
            self._output_var.set(d)

    def _auto_fill_from_folder(self, folder: str):
        folder_name = Path(folder).name
        if not self._name_var.get():
            self._name_var.set(folder_name)
        if not self._id_var.get():
            self._id_var.set(_name_to_id(folder_name))
        if not self._output_var.get():
            mods_dir = Path(__file__).parent.parent / "mods"
            self._output_var.set(str(mods_dir))

    def _update_filename_preview(self):
        name = self._name_var.get().strip()
        if name:
            self._filename_preview_var.set(f"→ {_sanitize_filename(name)}.rmod")
        else:
            self._filename_preview_var.set("")

    def _auto_fill_id(self, _event=None):
        name = self._name_var.get().strip()
        if name and not self._id_var.get():
            self._id_var.set(_name_to_id(name))

    # ── Scan ──────────────────────────────────────────────────────────────────

    def _scan(self):
        mod_folder    = self._mod_var.get().strip()
        game_data_dir = self._data_var.get().strip()

        if not mod_folder or not game_data_dir:
            messagebox.showerror("Missing paths",
                                 "Set both Mod Folder and Original Game Data first.")
            return

        self._file_listbox.delete(0, tk.END)
        pairs = scan_mod_folder(mod_folder, game_data_dir)

        if not pairs:
            self._scan_status.set("No matching .dat files found.")
            return

        for mod_dat, orig_dat, rmod_rel in pairs:
            size_kb = mod_dat.stat().st_size // 1024
            self._file_listbox.insert(
                tk.END, f"{rmod_rel}  ({size_kb} KB)")

        self._scan_status.set(f"{len(pairs)} .dat file(s) found")

    # ── Convert ───────────────────────────────────────────────────────────────

    def _convert(self):
        if self._running:
            return

        mod_folder    = self._mod_var.get().strip()
        game_data_dir = self._data_var.get().strip()
        output_dir    = self._output_var.get().strip()
        name          = self._name_var.get().strip()
        mod_id        = self._id_var.get().strip()
        version       = self._ver_var.get().strip() or "1.0.0"
        author        = self._author_var.get().strip()
        description   = self._desc_var.get().strip()

        if not mod_folder:
            messagebox.showerror("Missing", "Set the Mod Folder.")
            return
        if not game_data_dir:
            messagebox.showerror("Missing", "Set the Original Game Data directory.")
            return
        if not output_dir:
            messagebox.showerror("Missing", "Set the Output Folder.")
            return
        if not name:
            messagebox.showerror("Missing", "Enter a mod Name.")
            return
        if not mod_id:
            mod_id = _name_to_id(name)
            self._id_var.set(mod_id)

        output_rmod = str(Path(output_dir) / (_sanitize_filename(name) + ".rmod"))

        self._running = True
        self._convert_btn.configure(state="disabled")
        self._status.set("Converting…")

        t = threading.Thread(
            target=self._run_convert,
            args=(mod_folder, game_data_dir, output_rmod,
                  name, mod_id, version, author, description),
            daemon=True,
        )
        t.start()

    def _run_convert(self, mod_folder, game_data_dir, output_rmod,
                     name, mod_id, version, author, description):
        try:
            self._log_head(f"Converting: {name}")
            self._log_head(f"  Mod folder : {mod_folder}")
            self._log_head(f"  Game data  : {game_data_dir}")
            self._log_head(f"  Output     : {output_rmod}")
            self._log_head("")

            ok = run_conversion(
                mod_folder    = mod_folder,
                game_data_dir = game_data_dir,
                output_rmod   = output_rmod,
                name          = name,
                mod_id        = mod_id,
                version       = version,
                author        = author,
                description   = description,
                log_fn        = self._log_info,
                warn_fn       = self._log_warn,
            )

            if ok:
                self._log_ok(f"\nDone — {output_rmod}")
                self.after(0, lambda: self._status.set(f"Written: {Path(output_rmod).name}"))
            else:
                self._log_err("\nConversion failed — see warnings above.")
                self.after(0, lambda: self._status.set("Conversion failed."))

        except Exception as e:
            self._log_err(f"\nUnhandled error: {e}")
            self.after(0, lambda: self._status.set("Error — see log."))
        finally:
            self.after(0, self._convert_done)

    def _convert_done(self):
        self._running = False
        self._convert_btn.configure(state="normal")

    # ── Log helpers ───────────────────────────────────────────────────────────

    def _log_head(self, msg: str):
        self._log.after(0, self._append_log, msg + "\n", "head")

    def _log_info(self, msg: str):
        self._log.after(0, self._append_log, msg + "\n", "info")

    def _log_warn(self, msg: str):
        self._log.after(0, self._append_log, "WARN  " + msg + "\n", "warn")

    def _log_err(self, msg: str):
        self._log.after(0, self._append_log, "ERR   " + msg + "\n", "err")

    def _log_ok(self, msg: str):
        self._log.after(0, self._append_log, msg + "\n", "ok")

    def _clear_log(self):
        self._log.configure(state="normal")
        self._log.delete("1.0", tk.END)
        self._log.configure(state="disabled")

    def _append_log(self, msg: str, tag: str):
        self._log.configure(state="normal")
        self._log.insert(tk.END, msg, tag)
        self._log.see(tk.END)
        self._log.configure(state="disabled")

    # ── State persistence ─────────────────────────────────────────────────────

    def _on_close(self):
        self._save_state()
        self.destroy()

    def _save_state(self):
        state = {
            "data_dir":    self._data_var.get(),
            "mod_folder":  self._mod_var.get(),
            "output_dir":  self._output_var.get(),
            "name":        self._name_var.get(),
            "mod_id":      self._id_var.get(),
            "version":     self._ver_var.get(),
            "author":      self._author_var.get(),
            "description": self._desc_var.get(),
        }
        try:
            with open(_STATE_FILE, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception:
            pass

    def _load_state(self):
        if not _STATE_FILE.exists():
            # Set sensible default for game data if not saved
            default_data = Path(__file__).parent.parent / "Claude/sources/RUSE-game/Data"
            if default_data.exists():
                self._data_var.set(str(default_data))
            return
        try:
            with open(_STATE_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)
            self._data_var.set(state.get("data_dir", ""))
            self._mod_var.set(state.get("mod_folder", ""))
            self._output_var.set(state.get("output_dir", state.get("output_rmod", "")))
            self._name_var.set(state.get("name", ""))
            self._id_var.set(state.get("mod_id", ""))
            self._ver_var.set(state.get("version", "1.0.0"))
            self._author_var.set(state.get("author", ""))
            self._desc_var.set(state.get("description", ""))
            self._update_filename_preview()
        except Exception:
            pass


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = ConvertModApp()
    app.mainloop()
