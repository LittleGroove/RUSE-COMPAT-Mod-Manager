import sys
import os
import struct
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata

SWF_MAGIC = {b'FWS', b'CWS', b'ZWS'}
BASE = 'Claude/sources/RUSE-game/Data/PC'

def find_swf_in_dat(dat_path):
    print(f'Scanning {dat_path} ...', flush=True)
    try:
        arc = edata.open_dat(dat_path)
    except Exception as ex:
        print(f'  ERROR opening: {ex}')
        return
    found = 0
    for e in arc._entries:
        p = e.path
        # Check by extension
        if p.lower().endswith('.swf'):
            print(f'  [BY EXT] {p}')
            found += 1
            continue
        # Check by magic bytes
        try:
            raw = arc.get(p)
        except Exception:
            continue
        if len(raw) < 8:
            continue
        magic = raw[:3]
        if magic in SWF_MAGIC:
            version = raw[3]
            size = struct.unpack_from('<I', raw, 4)[0]
            if 1 <= version <= 30 and 1000 <= size <= 50_000_000:
                print(f'  [BY MAGIC] {p}  version={version}  size={size}  rawlen={len(raw)}')
                found += 1
    if found == 0:
        print(f'  (no SWF found)')

# Collect all .dat files
dat_files = []
for root, dirs, files in os.walk('Claude/sources/RUSE-game'):
    for f in files:
        if f.lower().endswith('.dat'):
            dat_files.append(os.path.join(root, f).replace('\\', '/'))

dat_files.sort()
print(f'Found {len(dat_files)} dat files total\n')
for d in dat_files:
    find_swf_in_dat(d)
