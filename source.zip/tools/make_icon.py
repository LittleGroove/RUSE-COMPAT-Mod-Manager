"""Generate icon.ico for RUSE Mod Manager.

Palette matches mod_manager.py exactly:
  bg      #08101c  deep navy black
  border  #c8a020  military gold
  "RUSE"  #e0c030  bright gold  (main heading colour)
  sub     #ccd8e8  silver-white (body text colour)
  shadow  #243a5c  steel blue (border colour used as glow base)

Design: pointy-top hexagon, double gold ring, bold gold "RUSE",
silver "MOD MGR" subtitle.  Embeds 256/128/64/48/32/16 px.
"""

import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ── Palette (hex values from mod_manager.py) ─────────────────────────────────
def _hex2rgba(h: str, a: int = 255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

BG_DEEP    = _hex2rgba("#08101c")        # deep navy — window bg
BG_PANEL   = _hex2rgba("#0e1a2a")        # navy panel — slightly lighter centre
BORDER     = _hex2rgba("#c8a020")        # military gold — outer ring
BORDER_IN  = _hex2rgba("#243a5c")        # steel blue — inner ring
GOLD_BRT   = _hex2rgba("#e0c030")        # bright gold — "RUSE"
SILVER     = _hex2rgba("#ccd8e8")        # silver-white — "MOD MGR"
SHADOW     = _hex2rgba("#000000", 180)   # drop shadow


def _hex_pts(cx, cy, r):
    """Pointy-top regular hexagon."""
    return [
        (cx + r * math.cos(math.radians(60 * i - 30)),
         cy + r * math.sin(math.radians(60 * i - 30)))
        for i in range(6)
    ]


def _load_font(names, size):
    for name in names:
        for path in [name, rf"C:\Windows\Fonts\{name}"]:
            try:
                return ImageFont.truetype(path, size)
            except (OSError, IOError):
                pass
    return ImageFont.load_default()


def _gold_glow(draw, xy, text, font, radius=3):
    """Draw a soft amber glow under gold text using offset copies."""
    x, y = xy
    glow = _hex2rgba("#c8a020", 60)
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            if dx == 0 and dy == 0:
                continue
            draw.text((x + dx, y + dy), text, font=font, fill=glow)


def _make_frame(size: int) -> Image.Image:
    # Work at 2x then downscale for smoother edges
    S  = size * 2
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d   = ImageDraw.Draw(img)
    cx, cy = S / 2, S / 2

    # ── Hex fill — navy gradient-ish: outer ring darker, centre lighter ───────
    r_outer = S * 0.456
    r_inner = S * 0.38

    outer_pts = _hex_pts(cx, cy, r_outer)
    inner_pts = _hex_pts(cx, cy, r_inner)

    d.polygon(outer_pts, fill=BG_DEEP)
    d.polygon(inner_pts, fill=BG_PANEL)

    # ── Double border ring ────────────────────────────────────────────────────
    bw_gold  = max(3, round(S / 18))    # thick gold outer ring
    bw_steel = max(2, round(S / 36))    # thin steel inner ring

    d.line(outer_pts + [outer_pts[0]], fill=BORDER,    width=bw_gold)

    steel_pts = _hex_pts(cx, cy, r_outer - bw_gold - round(S / 48))
    d.line(steel_pts + [steel_pts[0]], fill=BORDER_IN, width=bw_steel)

    # ── "RUSE" — bright gold, Impact, with glow + shadow ─────────────────────
    fs   = round(S * 0.33)
    font = _load_font(["impact.ttf", "arialbd.ttf", "verdanab.ttf"], fs)

    text = "RUSE"
    bb   = d.textbbox((0, 0), text, font=font)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]

    v_shift = S * 0.055
    tx = cx - tw / 2 - bb[0]
    ty = cy - th / 2 - bb[1] - v_shift

    # Glow (only meaningful at large sizes; cheap at small)
    glow_r = max(1, round(S / 60))
    _gold_glow(d, (tx, ty), text, font, radius=glow_r)

    # Shadow offset
    sd = max(1, round(S / 60))
    d.text((tx + sd, ty + sd), text, font=font, fill=SHADOW)

    # Main text
    d.text((tx, ty), text, font=font, fill=GOLD_BRT)

    # ── "MOD MGR" — silver-white body text colour ─────────────────────────────
    if size >= 32:
        sfs  = round(S * 0.105)
        sfnt = _load_font(["arialbd.ttf", "verdanab.ttf", "impact.ttf"], sfs)
        sub  = "MOD MGR"
        sbb  = d.textbbox((0, 0), sub, font=sfnt)
        sw   = sbb[2] - sbb[0]
        sx   = cx - sw / 2 - sbb[0]
        sy   = ty + th + S * 0.055 - sbb[1] + round(S * 15 / 256)
        d.text((sx + sd, sy + sd), sub, font=sfnt, fill=SHADOW)
        d.text((sx, sy),           sub, font=sfnt, fill=SILVER)

    # ── Downscale 2x -> 1x (LANCZOS = best anti-aliasing) ────────────────────
    return img.resize((size, size), Image.LANCZOS)


def _embed_b64(b64: str, target: Path = Path("mod_manager.py")):
    """Replace the _ICON_B64 line in mod_manager.py with the real base64."""
    import re
    src = target.read_text(encoding="utf-8")
    new = re.sub(
        r'^_ICON_B64: str = .*$',
        f'_ICON_B64: str = "{b64}"  # generated — do not edit by hand',
        src,
        flags=re.MULTILINE,
    )
    if new == src:
        print("  WARNING: _ICON_B64 placeholder not found in mod_manager.py")
        return
    target.write_text(new, encoding="utf-8")
    print(f"  mod_manager.py : _ICON_B64 updated ({len(b64)} chars)")


def build(dest: Path = Path("icon.ico")):
    import base64
    from io import BytesIO

    sizes  = [256, 128, 64, 48, 32, 16]
    frames = [_make_frame(s) for s in sizes]

    frames[0].save(
        dest,
        format="ICO",
        append_images=frames[1:],
        sizes=[(s, s) for s in sizes],
    )
    print(f"icon.ico written -> {dest.resolve()}")
    print(f"  embedded sizes : {sizes}")

    # Export 64x64 PNG as base64 and write it into mod_manager.py
    buf = BytesIO()
    _make_frame(64).save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    _embed_b64(b64)


if __name__ == "__main__":
    build()
