"""
Full semantic diff of every NDF in Cheat Mod v1.2 vs the original game DAT.

Strategy:
- For each NDF present in both DATs, decompress and parse.
- Match instances by their DescriptorId (stable ID) rather than position,
  to survive reordering.
- Collect every changed/added/removed property across all instances.
- Print a summary grouped by property name, with class context.
"""
import sys
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, str(Path(__file__).parent.parent))
from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

ROOT      = Path(__file__).parent.parent
ORIG_DAT  = ROOT / "Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat"
CHEAT_DAT = ROOT / "Claude/sources/currently_used_mod_files/Cheat Mod v1.2/99/ZZ_GladPatchableWin.dat"


def stable_key(ndf, inst) -> tuple | None:
    """Return a stable identity key for an instance (DescriptorId preferred)."""
    for key_prop_name in ("DescriptorId", "ClassNameForDebug"):
        prop = ndf.prop_by_name_and_class(key_prop_name, inst.class_index)
        if prop is None:
            prop = ndf.prop_by_name(key_prop_name)
        if prop is None:
            continue
        v = inst.get(prop.index)
        if v is not None:
            cls_name = ndf.classes[inst.class_index].name
            return (cls_name, key_prop_name, str(ndf.resolve_value(v)))
    return None


def diff_ndf_semantic(orig_ndf, mod_ndf, ndf_label: str) -> list[dict]:
    """
    Diff two parsed NDFs by stable instance key.
    Returns list of diffs: {key, cls, prop, orig, mod}
    """
    # Build lookup: stable_key -> instance
    orig_by_key = {}
    for inst in orig_ndf.instances:
        k = stable_key(orig_ndf, inst)
        if k:
            orig_by_key[k] = inst

    mod_by_key = {}
    for inst in mod_ndf.instances:
        k = stable_key(mod_ndf, inst)
        if k:
            mod_by_key[k] = inst

    diffs = []
    common_keys = set(orig_by_key) & set(mod_by_key)

    for k in common_keys:
        orig_inst = orig_by_key[k]
        mod_inst  = mod_by_key[k]

        orig_props = {pv.prop_index: pv.value for pv in orig_inst.props}
        mod_props  = {pv.prop_index: pv.value for pv in mod_inst.props}

        all_indices = set(orig_props) | set(mod_props)
        for idx in all_indices:
            ov = orig_props.get(idx)
            mv = mod_props.get(idx)

            ov_str = str(orig_ndf.resolve_value(ov)) if ov else "MISSING"
            mv_str = str(mod_ndf.resolve_value(mv))  if mv else "MISSING"

            if ov_str == mv_str:
                continue

            prop = next((p for p in orig_ndf.properties if p.index == idx), None)
            if prop is None:
                prop = next((p for p in mod_ndf.properties if p.index == idx), None)
            pname = prop.name if prop else f"prop#{idx}"

            diffs.append({
                "ndf":   ndf_label,
                "cls":   k[0],
                "key":   f"{k[1]}={k[2]}",
                "prop":  pname,
                "orig":  ov_str,
                "mod":   mv_str,
            })

    return diffs


print("Opening DATs…")
orig_edat  = edata_mod.open_dat(str(ORIG_DAT))
cheat_edat = edata_mod.open_dat(str(CHEAT_DAT))

orig_files  = set(orig_edat.list())
cheat_files = set(cheat_edat.list())
common      = sorted(orig_files & cheat_files)
only_orig   = orig_files - cheat_files
only_cheat  = cheat_files - orig_files

if only_orig:
    print(f"\nFiles only in ORIGINAL ({len(only_orig)}): {list(only_orig)[:5]}")
if only_cheat:
    print(f"\nFiles only in CHEAT ({len(only_cheat)}): {list(only_cheat)[:5]}")

print(f"\nComparing {len(common)} common files…")

all_diffs = []
ndf_diff_counts = {}

for fpath in common:
    if not fpath.endswith(".gladndfbin"):
        continue
    orig_bytes  = orig_edat.get(fpath)
    cheat_bytes = cheat_edat.get(fpath)
    if orig_bytes == cheat_bytes:
        continue  # identical — skip

    label = fpath.split("\\")[-1]
    try:
        orig_ndf  = ndfbin_mod.read(orig_bytes)
        cheat_ndf = ndfbin_mod.read(cheat_bytes)
    except Exception as e:
        print(f"  PARSE ERROR in {label}: {e}")
        continue

    diffs = diff_ndf_semantic(orig_ndf, cheat_ndf, label)
    if diffs:
        ndf_diff_counts[label] = len(diffs)
        all_diffs.extend(diffs)

print(f"\nTotal property diffs across all NDFs: {len(all_diffs)}")

# ── Summary: which NDF files changed ─────────────────────────────────────────
print("\n── NDF files with changes ──")
for ndf, count in sorted(ndf_diff_counts.items(), key=lambda x: -x[1]):
    print(f"  {ndf}: {count} property diff(s)")

# ── Summary: which properties changed ────────────────────────────────────────
from collections import Counter
prop_counts = Counter(d["prop"] for d in all_diffs)
print("\n── Properties changed (by frequency) ──")
for prop, cnt in prop_counts.most_common():
    print(f"  {prop}: {cnt}")

# ── Detailed: production-related diffs ───────────────────────────────────────
PROD_KEYWORDS = {"production", "upgrade", "price", "time", "devises", "devise",
                 "camion", "convoi", "stock", "repair"}

prod_diffs = [d for d in all_diffs
              if any(k in d["prop"].lower() for k in PROD_KEYWORDS)]

print(f"\n── Production-related diffs ({len(prod_diffs)}) ──")
by_prop = defaultdict(list)
for d in prod_diffs:
    by_prop[d["prop"]].append(d)

for prop, entries in sorted(by_prop.items()):
    classes = Counter(e["cls"] for e in entries)
    sample_orig = entries[0]["orig"]
    sample_mod  = entries[0]["mod"]
    print(f"\n  {prop} ({len(entries)} instance(s)):")
    for cls, cnt in classes.most_common():
        print(f"    class={cls}: {cnt}")
    print(f"    sample: {sample_orig!r} -> {sample_mod!r}")

# ── Full list of non-production diffs ─────────────────────────────────────────
other_diffs = [d for d in all_diffs if d not in prod_diffs]
if other_diffs:
    other_props = Counter(d["prop"] for d in other_diffs)
    print(f"\n── Non-production diffs ({len(other_diffs)}) ──")
    for prop, cnt in other_props.most_common():
        sample = next(d for d in other_diffs if d["prop"] == prop)
        print(f"  {prop} ({cnt}): {sample['orig']!r} -> {sample['mod']!r}  [class: {sample['cls']}]")
