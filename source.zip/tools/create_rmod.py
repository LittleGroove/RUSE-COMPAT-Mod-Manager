"""
create_rmod.py — create a .rmod file from scratch or by diffing two .dat files.

Usage:
  # Create a blank .rmod template
  python tools/create_rmod.py --template -o mods/my_mod.rmod

  # Diff two .dat files and generate a .rmod capturing the differences
  python tools/create_rmod.py diff \\
      --original "path/to/original/ZZ_GladPatchableWin.dat" \\
      --modified  "path/to/modified/ZZ_GladPatchableWin.dat" \\
      --ndf "pc/ndf/patchable/gfx/everything.ndfbin" \\
      --name "My Balance Mod" --author "Me" \\
      -o mods/balance.rmod

The diff mode compares two .dat archives, extracts the ndfbin from each,
parses both, and generates patch entries for every property that differs.
This is the fastest way to convert an existing mod (full .dat replacement)
into a portable .rmod patch file.
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import edata as edata_mod
from ruse_mod_engine import ndfbin as ndfbin_mod
from ruse_mod_engine import mod_format


def cmd_template(args):
    """Write a blank .rmod template."""
    out = args.out or "new_mod.rmod"
    Path(out).write_text(mod_format.TEMPLATE, encoding="utf-8")
    print(f"Template written to: {out}")


def cmd_diff(args):
    """Diff two .dat files and generate a .rmod."""
    orig_edat = edata_mod.open_dat(args.original)
    mod_edat  = edata_mod.open_dat(args.modified)

    ndf_path = args.ndf

    orig_bytes = orig_edat.get(ndf_path)
    mod_bytes  = mod_edat.get(ndf_path)

    if orig_bytes is None:
        print(f"ERROR: {ndf_path!r} not found in original {args.original}", file=sys.stderr)
        sys.exit(1)
    if mod_bytes is None:
        print(f"ERROR: {ndf_path!r} not found in modified {args.modified}", file=sys.stderr)
        sys.exit(1)

    print("Parsing original NDF…")
    orig_ndf = ndfbin_mod.read(orig_bytes)
    print(f"  {len(orig_ndf.instances)} instances, {len(orig_ndf.classes)} classes")

    print("Parsing modified NDF…")
    mod_ndf = ndfbin_mod.read(mod_bytes)
    print(f"  {len(mod_ndf.instances)} instances, {len(mod_ndf.classes)} classes")

    print("Computing diff…")
    changes = _diff_ndf(orig_ndf, mod_ndf)
    print(f"  {len(changes)} change entries generated")

    # Infer the dat path relative to Data/
    dat_rel = _guess_dat_rel(args.modified)

    mod_id = re.sub(r"[^a-zA-Z0-9_-]", "-", (args.name or "my-mod").lower())
    rmod_obj = {
        "$schema": "ruse-mod/v1",
        "id": mod_id,
        "name": args.name or "Generated Mod",
        "version": "1.0.0",
        "author": args.author or "",
        "description": f"Generated diff from {Path(args.original).name} → {Path(args.modified).name}",
        "patches": [
            {
                "dat": dat_rel,
                "ndf": ndf_path,
                "changes": changes,
            }
        ],
    }

    out = args.out or "generated.rmod"
    Path(out).write_text(json.dumps(rmod_obj, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n.rmod file written to: {out}")
    print(f"Total changes: {len(changes)}")


def _diff_ndf(orig: ndfbin_mod.NdfBinary, mod: ndfbin_mod.NdfBinary) -> list:
    """
    Compare two NdfBinary objects instance by instance.
    For each instance present in both (same class, same position), compare
    each property.  Emit a change entry for any property whose value differs.
    Relies on ClassNameForDebug to identify instances uniquely when available.
    """
    changes = []

    # Build lookup: class_name → {debug_name → (idx, inst)} for original
    def build_lookup(ndf):
        lu = {}
        for idx, inst in enumerate(ndf.instances):
            cls = ndf.classes[inst.class_index] if inst.class_index < len(ndf.classes) else None
            if cls is None:
                continue
            cls_name = cls.name
            if cls_name not in lu:
                lu[cls_name] = {}
            # Try ClassNameForDebug first
            debug_name = _get_debug_name(ndf, inst)
            key = debug_name if debug_name else f"__idx_{idx}"
            lu[cls_name][key] = (idx, inst)
        return lu

    orig_lu = build_lookup(orig)
    mod_lu  = build_lookup(mod)

    for cls_name, mod_entries in mod_lu.items():
        orig_entries = orig_lu.get(cls_name, {})

        for key, (mod_idx, mod_inst) in mod_entries.items():
            if key not in orig_entries:
                continue  # new instance — skip for now (create action needs more info)
            _, orig_inst = orig_entries[key]

            prop_changes = _diff_instance(orig, orig_inst, mod, mod_inst)
            if not prop_changes:
                continue

            match_dict = {}
            if not key.startswith("__idx_"):
                match_dict["ClassNameForDebug"] = key

            change = {
                "action": "patch",
                "table": cls_name,
            }
            if match_dict:
                change["match"] = match_dict
            else:
                change["match"] = {"__order": str(mod_idx)}
            change["set"] = prop_changes
            changes.append(change)

    return changes


def _get_debug_name(ndf: ndfbin_mod.NdfBinary, inst: ndfbin_mod.NdfInstance) -> str:
    prop = ndf.prop_by_name_and_class("ClassNameForDebug", inst.class_index)
    if prop is None:
        prop = ndf.prop_by_name("ClassNameForDebug")
    if prop is None:
        return ""
    val = inst.get(prop.index)
    if val is None:
        return ""
    resolved = ndf.resolve_value(val)
    return str(resolved) if resolved else ""


def _diff_instance(
    orig_ndf: ndfbin_mod.NdfBinary,
    orig_inst: ndfbin_mod.NdfInstance,
    mod_ndf: ndfbin_mod.NdfBinary,
    mod_inst: ndfbin_mod.NdfInstance,
) -> dict:
    """Return {prop_name: {type, value}} for all properties that changed."""
    result = {}

    # Index orig props by property index
    orig_props = {pv.prop_index: pv.value for pv in orig_inst.props}

    for pv in mod_inst.props:
        prop_idx = pv.prop_index
        mod_val = pv.value

        # Resolve the property name from the mod ndf
        prop = (mod_ndf.properties[prop_idx]
                if prop_idx < len(mod_ndf.properties) else None)
        if prop is None:
            continue
        prop_name = prop.name

        orig_val = orig_props.get(prop_idx)
        if orig_val is None:
            # Property is new — include as change
            pass
        else:
            if _values_equal(orig_ndf, orig_val, mod_ndf, mod_val):
                continue  # unchanged

        # Emit a change
        type_name = ndfbin_mod.T.name(mod_val.type_id)
        encoded_value = _encode_value_for_rmod(mod_ndf, mod_val)
        if encoded_value is not None:
            result[prop_name] = {"type": type_name, "value": encoded_value}

    return result


def _values_equal(
    a_ndf: ndfbin_mod.NdfBinary, a: ndfbin_mod.NdfValue,
    b_ndf: ndfbin_mod.NdfBinary, b: ndfbin_mod.NdfValue,
) -> bool:
    if a.type_id != b.type_id:
        return False
    # For string refs, compare the actual strings
    if a.type_id in (ndfbin_mod.T.StringRef, ndfbin_mod.T.PathRef):
        return a_ndf.get_string(a.raw) == b_ndf.get_string(b.raw)
    # For references, compare resolved forms
    if a.type_id == ndfbin_mod.T.Reference:
        return a_ndf.resolve_value(a) == b_ndf.resolve_value(b)
    # For bytes/lists, compare raw
    if isinstance(a.raw, (bytes, bytearray)):
        return bytes(a.raw) == bytes(b.raw)
    if isinstance(a.raw, list):
        return a.raw == b.raw
    return a.raw == b.raw


def _encode_value_for_rmod(ndf: ndfbin_mod.NdfBinary, val: ndfbin_mod.NdfValue):
    """Convert an NdfValue's raw Python value to a .rmod-serialisable form."""
    t = val.type_id
    v = val.raw

    if t in (ndfbin_mod.T.Bool,):
        return bool(v)
    if t in (ndfbin_mod.T.Int8, ndfbin_mod.T.Int16, ndfbin_mod.T.UInt16,
             ndfbin_mod.T.Int32, ndfbin_mod.T.UInt32, ndfbin_mod.T.Long):
        return int(v)
    if t in (ndfbin_mod.T.Float32, ndfbin_mod.T.Float64):
        return float(v)
    if t in (ndfbin_mod.T.StringRef, ndfbin_mod.T.PathRef):
        return ndf.get_string(v)  # store the actual string
    if t == ndfbin_mod.T.WideStr:
        return str(v)
    if t in (ndfbin_mod.T.Vector3, ndfbin_mod.T.Color128, ndfbin_mod.T.Int2, ndfbin_mod.T.Float2):
        return list(v)
    if t == ndfbin_mod.T.TripleInt:
        return list(v)
    if t == ndfbin_mod.T.Color32:
        return list(v)
    if t in (ndfbin_mod.T.Guid, ndfbin_mod.T.Hash, ndfbin_mod.T.LocHash):
        return bytes(v).hex()
    # Complex types (lists, blobs, references) cannot be simply encoded — skip
    return None


def _guess_dat_rel(dat_path: str) -> str:
    """Try to infer the path relative to Data/ from an absolute or partial path."""
    p = Path(dat_path)
    parts = p.parts
    try:
        # Find 'Data' in the path
        idx = next(i for i, part in enumerate(parts) if part.lower() == "data")
        return "/".join(parts[idx + 1:])
    except StopIteration:
        return "/".join(parts[-3:])  # last 3 components as fallback


import re   # needed by cmd_diff


def main():
    parser = argparse.ArgumentParser(
        description="Create or generate .rmod mod files for RUSE",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="command")

    # template sub-command
    tmpl = sub.add_parser("template", help="Write a blank .rmod template")
    tmpl.add_argument("-o", "--out", help="Output .rmod file path")

    # diff sub-command
    diff = sub.add_parser("diff", help="Generate .rmod from diff of two .dat files")
    diff.add_argument("--original", required=True, help="Original (vanilla) .dat file")
    diff.add_argument("--modified",  required=True, help="Modified (modded) .dat file")
    diff.add_argument("--ndf", required=True,
                      help="Internal path to the .ndfbin inside both archives")
    diff.add_argument("--name", help="Mod display name")
    diff.add_argument("--author", help="Mod author name")
    diff.add_argument("-o", "--out", help="Output .rmod file path")

    # Also accept --template at top level for convenience
    parser.add_argument("--template", action="store_true", help="Write a blank .rmod template")
    parser.add_argument("-o", "--out", help="Output file path (for --template)")

    args = parser.parse_args()

    if args.template or args.command == "template":
        cmd_template(args)
    elif args.command == "diff":
        cmd_diff(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
