"""
Generate mods/pinnacle_map_pack.rmod by diffing the Pinnacle Map Pack .dat
against the original game .dat.

Handles object references, GUIDs, and LocHash values in addition to scalars.
Also handles raw file replacements in DataMap_Win.dat (.scenario, .kdt).

Run:
    python tools/extract_pinnacle.py
"""
import base64, json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

ROOT          = Path(__file__).parent.parent
ORIG_DAT      = ROOT / "Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat"
MOD_DAT       = ROOT / "Claude/sources/currently_used_mod_files/RUSE PINNACLE MAP PACK/99/ZZ_GladPatchableWin.dat"
ORIG_MAP_DAT  = ROOT / "Claude/sources/RUSE-game/Data/PC/1360/DataMap_Win.dat"
MOD_MAP_DAT   = ROOT / "Claude/sources/currently_used_mod_files/RUSE PINNACLE MAP PACK/1360/DataMap_Win.dat"
OUT_RMOD      = ROOT / "mods/pinnacle_map_pack.rmod"
DAT_PATH      = "PC/99/ZZ_GladPatchableWin.dat"
MAP_DAT_PATH  = "PC/1360/DataMap_Win.dat"


def serialise_val(ndf, val: ndfbin_mod.NdfValue):
    """Return a JSON-safe value representation for this NDF value."""
    t = val.type_id
    T = ndfbin_mod.T

    if t == T.Reference:
        marker, ref = val.raw
        if marker == ndfbin_mod.OBJ_REF_MARKER:
            inst_idx, cls_idx = ref
            return ("ObjRef", {"inst": inst_idx, "class": cls_idx})
        else:
            return ("TransRef", {"trans": ref})

    if t == T.Guid:
        return ("Guid", list(val.raw))

    if t == T.LocHash:
        return ("LocHash", list(val.raw))

    if t == T.Blob:
        return ("Blob", list(val.raw))

    if t == T.List:
        items = []
        for item in val.raw:
            type_name, item_val = serialise_val(ndf, item)
            items.append({"type": type_name, "value": item_val})
        elem_type = "ObjRef" if val.raw and val.raw[0].type_id == T.Reference else "Int32"
        return (f"List<{elem_type}>", items)

    if t in (T.StringRef, T.PathRef):
        return (("PathRef" if t == T.PathRef else "StringRef"),
                ndf.get_string(val.raw))

    if t == T.Bool:
        return ("Bool", val.raw)
    if t == T.Int8:
        return ("Int8", val.raw)
    if t == T.Int16:
        return ("Int16", val.raw)
    if t == T.UInt16:
        return ("UInt16", val.raw)
    if t == T.Int32:
        return ("Int32", val.raw)
    if t == T.UInt32:
        return ("UInt32", val.raw)
    if t == T.Long:
        return ("Long", val.raw)
    if t == T.Float32:
        return ("Float32", val.raw)
    if t == T.Float64:
        return ("Float64", val.raw)

    return (f"0x{t:02X}", repr(val.raw))


def diff_ndf_with_refs(orig_ndf, mod_ndf):
    """
    Return (creates, patches) for two NDF versions.

    creates  = list of {idx, class_name, local_id, props_dict}
    patches  = list of {inst_idx, class_name, match, changed_props}

    Object reference values that point to newly created instances carry a
    "$ref" placeholder (resolved later when building the JSON).
    """
    # Identify new instances (appended at end)
    new_start = len(orig_ndf.instances)
    new_instances = []
    for i in range(new_start, len(mod_ndf.instances)):
        inst = mod_ndf.instances[i]
        cls  = mod_ndf.classes[inst.class_index]
        props = {}
        for pv in inst.props:
            prop = next((p for p in mod_ndf.properties if p.index == pv.prop_index), None)
            pname = prop.name if prop else f"prop#{pv.prop_index}"
            props[pname] = pv.value
        new_instances.append((i, cls.name, props))

    # Build local_id map: new_inst_idx → local_id
    local_id_map = {}
    for inst_idx, cls_name, _ in new_instances:
        local_id_map[inst_idx] = f"{cls_name}_{inst_idx}"

    # Build creates list
    creates = []
    for inst_idx, cls_name, props in new_instances:
        set_props = {}
        for pname, val in props.items():
            t, v = serialise_val(mod_ndf, val)
            if t == "ObjRef" and isinstance(v, dict) and v["inst"] in local_id_map:
                set_props[pname] = {"$ref": local_id_map[v["inst"]]}
            else:
                set_props[pname] = {"type": t, "value": v}
        creates.append({
            "inst_idx": inst_idx,
            "class_name": cls_name,
            "local_id": local_id_map[inst_idx],
            "set": set_props,
        })

    # Identify changed instances (in shared range)
    patches = []
    for i in range(min(len(orig_ndf.instances), len(mod_ndf.instances))):
        orig_inst = orig_ndf.instances[i]
        mod_inst  = mod_ndf.instances[i]

        if orig_inst.class_index != mod_inst.class_index:
            continue

        orig_props = {pv.prop_index: pv.value for pv in orig_inst.props}
        mod_props  = {pv.prop_index: pv.value for pv in mod_inst.props}

        changed = {}
        for idx, cv in mod_props.items():
            ov = orig_props.get(idx)
            if ov is not None and str(orig_ndf.resolve_value(ov)) == str(mod_ndf.resolve_value(cv)):
                continue
            prop = next((p for p in orig_ndf.properties if p.index == idx), None)
            if prop is None:
                continue
            t, v = serialise_val(mod_ndf, cv)
            if t == "ObjRef" and isinstance(v, dict) and v["inst"] in local_id_map:
                changed[prop.name] = {"$ref": local_id_map[v["inst"]]}
            elif t.startswith("List<") and isinstance(v, list):
                # Check each list element for refs to new instances
                new_items = []
                for item in v:
                    if (isinstance(item, dict) and item.get("type") == "ObjRef"
                            and item.get("value", {}).get("inst") in local_id_map):
                        new_items.append({"$ref": local_id_map[item["value"]["inst"]]})
                    else:
                        new_items.append(item)
                changed[prop.name] = {"type": t, "value": new_items}
            else:
                changed[prop.name] = {"type": t, "value": v}

        if not changed:
            continue

        cls_name = orig_ndf.classes[orig_inst.class_index].name

        # Build match condition: prefer string identifiers, fall back to GUID/bytes
        match = {}
        for name_prop in ("ClassNameForDebug", "Name", "TrackingId", "AmmunitionId", "FileName"):
            p = orig_ndf.prop_by_name_and_class(name_prop, orig_inst.class_index)
            if p:
                v = orig_inst.get(p.index)
                if v is not None and v.type_id in (ndfbin_mod.T.StringRef, ndfbin_mod.T.PathRef, ndfbin_mod.T.WideStr):
                    match = {name_prop: str(orig_ndf.resolve_value(v))}
                    break
        if not match:
            # Use Guid fields (PackGUID etc.) as last resort — resolved as bytes repr
            for guid_prop in ("PackGUID", "Guid"):
                p = orig_ndf.prop_by_name_and_class(guid_prop, orig_inst.class_index)
                if p:
                    v = orig_inst.get(p.index)
                    if v is not None:
                        match = {guid_prop: str(orig_ndf.resolve_value(v))}
                        break

        patches.append({
            "inst_idx": i,
            "class_name": cls_name,
            "match": match,
            "set": changed,
        })

    return creates, patches, local_id_map


def build_patch_group(ndf_internal_path, ndf_fwd_path, creates, patches):
    changes = []

    for c in creates:
        changes.append({
            "action": "create",
            "table": c["class_name"],
            "local_id": c["local_id"],
            "set": c["set"],
        })

    for p in patches:
        entry = {
            "action": "patch",
            "table": p["class_name"],
        }
        if p["match"]:
            entry["match"] = p["match"]
        entry["set"] = p["set"]
        changes.append(entry)

    return {
        "dat": DAT_PATH,
        "ndf": ndf_fwd_path,
        "changes": changes,
    }


def diff_raw_dat(orig_edat, mod_edat):
    """Return list of {path, data} for every file that changed or was added."""
    orig_set = {e.lower(): e for e in orig_edat.list()}
    mod_set  = {e.lower(): e for e in mod_edat.list()}
    changed = []
    for path_lower in mod_set:
        orig_path = orig_set.get(path_lower)
        mod_path  = mod_set[path_lower]
        mod_bytes = mod_edat.get(mod_path)
        if orig_path is None:
            changed.append((mod_path, mod_bytes))  # added file
        else:
            orig_bytes = orig_edat.get(orig_path)
            if orig_bytes != mod_bytes:
                changed.append((mod_path, mod_bytes))  # changed file
    return changed


def main():
    print("Opening DATs...")
    orig_edat = edata_mod.open_dat(str(ORIG_DAT))
    mod_edat  = edata_mod.open_dat(str(MOD_DAT))

    orig_entries = orig_edat.list()

    mapinfo_path = next(e for e in orig_entries if 'chqlmapinfo' in e.lower())
    globals_path  = next(e for e in orig_entries if 'globals.cpp' in e.lower())

    patch_groups = []

    for internal_path in (mapinfo_path, globals_path):
        fwd_path = internal_path.replace("\\", "/")
        short    = internal_path.split("\\")[-1]
        print(f"\nDiffing {short}...")

        orig_bytes = orig_edat.get(internal_path)
        mod_bytes  = mod_edat.get(internal_path)

        if orig_bytes is None or mod_bytes is None:
            print(f"  SKIP — not found in one of the DATs")
            continue

        orig_ndf = ndfbin_mod.read(orig_bytes)
        mod_ndf  = ndfbin_mod.read(mod_bytes)

        creates, patches, _ = diff_ndf_with_refs(orig_ndf, mod_ndf)
        print(f"  Creates: {len(creates)}, Patches: {len(patches)}")

        if creates or patches:
            pg = build_patch_group(internal_path, fwd_path, creates, patches)
            patch_groups.append(pg)

    # ── Raw file replacements for DataMap_Win.dat ─────────────────────────────
    print(f"\nDiffing DataMap_Win.dat (raw binary files)...")
    orig_map_edat = edata_mod.open_dat(str(ORIG_MAP_DAT))
    mod_map_edat  = edata_mod.open_dat(str(MOD_MAP_DAT))
    raw_changes = diff_raw_dat(orig_map_edat, mod_map_edat)
    print(f"  {len(raw_changes)} file(s) changed/added")

    file_groups = []
    if raw_changes:
        file_entries = []
        total_bytes  = 0
        for path, data in raw_changes:
            fwd = path.replace("\\", "/")
            file_entries.append({
                "path": fwd,
                "data": base64.b64encode(data).decode("ascii"),
            })
            total_bytes += len(data)
            print(f"  {fwd.split('/')[-1]}  ({len(data):,} bytes)")
        print(f"  Total embedded: {total_bytes:,} bytes -> ~{total_bytes*4//3:,} bytes base64")
        file_groups.append({
            "dat": MAP_DAT_PATH,
            "files": file_entries,
        })

    rmod = {
        "$schema": "ruse-mod/v1",
        "id": "pinnacle-map-pack",
        "name": "RUSE Pinnacle Map Pack",
        "version": "1.0.0",
        "author": "Extracted",
        "description": (
            "Adds multiplayer maps M01-M08 to the map pool, updates "
            "campaign map preview images, and replaces map scenario data."
        ),
        "patches": patch_groups,
    }
    if file_groups:
        rmod["file_patches"] = file_groups

    total_ndf   = sum(len(pg["changes"]) for pg in patch_groups)
    total_files = sum(len(fg["files"]) for fg in file_groups)
    print(f"\nWriting {OUT_RMOD.name}  ({total_ndf} NDF change(s), {total_files} file replacement(s))...")
    with open(OUT_RMOD, "w", encoding="utf-8") as f:
        json.dump(rmod, f, indent=2, ensure_ascii=False)
    print(f"  File size: {OUT_RMOD.stat().st_size / 1024:.0f} KB")
    print("Done.")


if __name__ == "__main__":
    main()
