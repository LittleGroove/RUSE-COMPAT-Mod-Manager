"""
Diagnose why ProductionPrice changes don't show in-game.

Checks:
1. Which class owns 'ProductionPrice' in the PROP table
2. What class do TUniteAuSolDescriptor instances actually report
3. Whether any instance stores a prop at the ProductionPrice index
4. What the actual stored prop_indices are for a sample unit
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

DAT = r"C:\Program Files (x86)\Steam\steamapps\common\R.U.S.E\Data\ZZ_GladPatchableWin.dat"
NDF = "everything.cpp.gladndfbin"

print("Opening DAT…")
edat = edata_mod.open_dat(DAT)
ndf_bytes = edat.get(NDF) or edat.get(NDF.replace("/", "\\"))
print(f"NDF bytes: {len(ndf_bytes):,}")

print("Parsing NDF…")
ndf = ndfbin_mod.read(ndf_bytes)
print(f"Classes: {len(ndf.classes)}, Properties: {len(ndf.properties)}, Instances: {len(ndf.instances)}")

# 1. Find all properties named 'ProductionPrice' and what class they belong to
print("\n── Properties named 'ProductionPrice' ──")
for p in ndf.properties:
    if p.name == "ProductionPrice":
        cls = ndf.classes[p.class_index] if p.class_index < len(ndf.classes) else None
        cls_name = cls.name if cls else f"cls#{p.class_index}"
        print(f"  PROP index={p.index}  class_index={p.class_index}  class='{cls_name}'")

# 2. Find TUniteAuSolDescriptor and TInfanterieDescriptor class entries
print("\n── Class entries ──")
for target in ("TUniteAuSolDescriptor", "TInfanterieDescriptor", "TAvionDescriptor", "TBatimentDescriptor"):
    cls = ndf.class_by_name(target)
    if cls:
        print(f"  {target}: index={cls.index}")
    else:
        print(f"  {target}: NOT FOUND")

# 3. For each relevant class, look up ProductionPrice via both methods
print("\n── prop_by_name_and_class vs prop_by_name ──")
for cls_name in ("TUniteAuSolDescriptor", "TInfanterieDescriptor", "TAvionDescriptor", "TBatimentDescriptor"):
    cls = ndf.class_by_name(cls_name)
    if cls is None:
        print(f"  {cls_name}: class not found")
        continue
    p_exact = ndf.prop_by_name_and_class("ProductionPrice", cls.index)
    p_fallback = ndf.prop_by_name("ProductionPrice")
    print(f"  {cls_name} (index={cls.index}):")
    print(f"    prop_by_name_and_class → {p_exact}")
    print(f"    prop_by_name (fallback) → {p_fallback}")

# 4. Take first few TUniteAuSolDescriptor instances and look at their actual stored prop indices
print("\n── First 3 TUniteAuSolDescriptor instances (raw props) ──")
cls = ndf.class_by_name("TUniteAuSolDescriptor")
if cls:
    prod_prop = ndf.prop_by_name("ProductionPrice")
    count = 0
    for idx, inst in enumerate(ndf.instances):
        if inst.class_index != cls.index:
            continue
        # Show all prop indices stored on this instance
        stored_indices = [pv.prop_index for pv in inst.props]
        # Check if our ProductionPrice prop index is in there
        has_pp = prod_prop and prod_prop.index in stored_indices
        # Find the actual stored value at ProductionPrice index
        pp_val = inst.get(prod_prop.index) if prod_prop else None
        # Show debug name
        debug_name = ndfbin_mod.NdfBinary.resolve_value  # just for clarity
        name_prop = ndf.prop_by_name("ClassNameForDebug")
        inst_name = "?"
        if name_prop:
            v = inst.get(name_prop.index)
            if v:
                inst_name = str(ndf.resolve_value(v))
        print(f"  inst#{idx} '{inst_name}':")
        print(f"    class_index={inst.class_index}, stored prop count={len(stored_indices)}")
        print(f"    ProductionPrice prop_index={prod_prop.index if prod_prop else 'N/A'}, present={has_pp}")
        if pp_val:
            print(f"    ProductionPrice value={ndf.resolve_value(pp_val)}")
        # Show first 10 prop indices stored
        print(f"    First stored prop indices: {stored_indices[:15]}")
        count += 1
        if count >= 3:
            break

# 5. Cross-check: look for a unit we know by name and examine all its prop indices
print("\n── Look for 'Infantry' or 'Rifleman' units ──")
cls = ndf.class_by_name("TUniteAuSolDescriptor")
debug_prop = ndf.prop_by_name("ClassNameForDebug")
prod_prop = ndf.prop_by_name("ProductionPrice")
found = 0
if cls and debug_prop and prod_prop:
    for idx, inst in enumerate(ndf.instances):
        if inst.class_index != cls.index:
            continue
        name_val = inst.get(debug_prop.index)
        if name_val is None:
            continue
        name = str(ndf.resolve_value(name_val))
        if "rifleman" in name.lower() or "infantry" in name.lower():
            pp_val = inst.get(prod_prop.index)
            print(f"  inst#{idx} '{name}': ProductionPrice={ndf.resolve_value(pp_val) if pp_val else 'MISSING'}")
            # Show all prop indices
            stored_indices = [pv.prop_index for pv in inst.props]
            print(f"    All stored prop indices ({len(stored_indices)}): {sorted(stored_indices)[:20]}")
            found += 1
            if found >= 5:
                break

# 6. What prop index does a TUniteAuSolDescriptor instance actually store for its price field?
# Let's find ALL properties that could relate to price on the first TUniteAuSolDescriptor instance
print("\n── All properties on first TUniteAuSolDescriptor instance ──")
cls = ndf.class_by_name("TUniteAuSolDescriptor")
if cls:
    for idx, inst in enumerate(ndf.instances):
        if inst.class_index != cls.index:
            continue
        print(f"  Properties on inst#{idx}:")
        for pv in inst.props:
            # Find property name
            prop_obj = None
            for p in ndf.properties:
                if p.index == pv.prop_index:
                    prop_obj = p
                    break
            prop_name = prop_obj.name if prop_obj else f"prop#{pv.prop_index}"
            val_str = str(ndf.resolve_value(pv.value))
            if len(val_str) > 80:
                val_str = val_str[:77] + "..."
            print(f"    [{pv.prop_index}] {prop_name} = {val_str}")
        break
