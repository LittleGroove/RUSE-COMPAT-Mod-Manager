import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata
import ruse_mod_engine.ndfbin as ndfbin

DAT = 'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat'
arc = edata.open_dat(DAT)

OBJ_REF_MARKER = ndfbin.OBJ_REF_MARKER
TRANS_REF_MARKER = ndfbin.TRANS_REF_MARKER

def dump_instances_by_class(ndf, *class_terms):
    cls_by_idx = {c.index: c.name for c in ndf.classes}
    prop_by_idx = {p.index: p.name for p in ndf.properties}

    def fmt_val(val):
        t = val.type_id
        r = val.raw
        if t == ndfbin.T.Reference:
            marker, ref = r
            if marker == OBJ_REF_MARKER:
                obj_idx, cls_idx = ref
                return f'ObjRef(inst={obj_idx}, cls={cls_by_idx.get(cls_idx, str(cls_idx))})'
            if marker == TRANS_REF_MARKER:
                return f'TransRef({ref})'
        if t == ndfbin.T.List:
            return '[' + ', '.join(fmt_val(x) for x in r) + ']'
        if t == ndfbin.T.StringRef:
            s = ndf.strings[r] if isinstance(r, int) and r < len(ndf.strings) else str(r)
            return repr(s)
        if t == ndfbin.T.Map:
            return 'Map{' + ', '.join(f'{fmt_val(k)}->{fmt_val(v)}' for k, v in r) + '}'
        return repr(r)[:150]

    found = False
    for i, inst in enumerate(ndf.instances):
        cls = cls_by_idx.get(inst.class_index, '?')
        if any(term.lower() in cls.lower() for term in class_terms):
            if not found:
                found = True
            print(f'  [{i}] {cls}')
            for pv in inst.props:
                pname = prop_by_idx.get(pv.prop_index, f'prop_{pv.prop_index}')
                print(f'    {pname}: {fmt_val(pv.value)}')
    return found

# Look in everything.cpp for multiplayer data
for e in arc._entries:
    p = e.path
    if p.endswith('everything.cpp.gladndfbin') and 'everything_debuginfo' not in p:
        print(f'=== {p} ===')
        ndf = ndfbin.read(arc.get(p))
        dump_instances_by_class(ndf, 'Multiplayer', 'MultiplayerMode', 'NetworkMode', 'Ranked')
        break

# Look in globals.cpp
for e in arc._entries:
    p = e.path
    if p.endswith('globals.cpp.gladndfbin'):
        print(f'\n=== {p} ===')
        ndf = ndfbin.read(arc.get(p))
        dump_instances_by_class(ndf, 'Ranked', 'Multiplayer', 'Network', 'Online')
        # Also show all classes
        print('All classes in globals.cpp:')
        for c in ndf.classes:
            print(f'  {c.name}')
        break
