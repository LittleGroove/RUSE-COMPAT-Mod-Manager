"""
Verify that ProductionPrice was actually changed in the patched output DAT.

Usage:
    python tools/verify_patch.py <output_dat_path> [original_dat_path]

Example:
    python tools/verify_patch.py test_output/ZZ_GladPatchableWin.dat "C:/RUSE/Data/ZZ_GladPatchableWin.dat"
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

NDF = "genglad/patchable/clustergfx/everything.cpp.gladndfbin"
NDF_BS = NDF.replace("/", "\\")

def inspect_dat(dat_path: str, label: str):
    print(f"\n-- {label} --")
    print(f"   {dat_path}")
    p = Path(dat_path)
    if not p.exists():
        print("   FILE NOT FOUND")
        return None

    edat = edata_mod.open_dat(dat_path)
    ndf_bytes = edat.get(NDF) or edat.get(NDF_BS)
    if ndf_bytes is None:
        print("   NDF not found in DAT")
        return None

    ndf = ndfbin_mod.read(ndf_bytes)

    # Collect ProductionPrice for first 10 TUniteAuSolDescriptor instances
    cls = ndf.class_by_name("TUniteAuSolDescriptor")
    debug_prop = ndf.prop_by_name("ClassNameForDebug")
    prod_prop = ndf.prop_by_name("ProductionPrice")
    upgrade_prop = ndf.prop_by_name("UpgradePrice")

    print(f"   Classes: {len(ndf.classes)}, Properties: {len(ndf.properties)}, Instances: {len(ndf.instances)}")
    print(f"   ProductionPrice PROP entry: {prod_prop}")
    print(f"   TUniteAuSolDescriptor class: {cls}")

    if cls and prod_prop and debug_prop:
        print(f"   First 10 TUniteAuSolDescriptor ProductionPrice values:")
        count = 0
        for idx, inst in enumerate(ndf.instances):
            if inst.class_index != cls.index:
                continue
            name_val = inst.get(debug_prop.index)
            name = str(ndf.resolve_value(name_val)) if name_val else f"inst#{idx}"
            pp_val = inst.get(prod_prop.index)
            pp = ndf.resolve_value(pp_val) if pp_val else "MISSING"
            print(f"     {name}: {pp}")
            count += 1
            if count >= 10:
                break

    # Check TTunableConstante
    const_cls = ndf.class_by_name("TTunableConstante")
    if const_cls:
        qte_prop = ndf.prop_by_name("QteDeviseInitiale")
        print(f"\n   TTunableConstante instances: {len(ndf.class_instances(const_cls))}")
        for idx, inst in enumerate(ndf.instances):
            if inst.class_index != const_cls.index:
                continue
            if qte_prop:
                v = inst.get(qte_prop.index)
                print(f"   QteDeviseInitiale = {ndf.resolve_value(v) if v else 'MISSING'}")

    return ndf

args = sys.argv[1:]
if not args:
    # Try default test_output location
    script_dir = Path(__file__).parent.parent
    default = script_dir / "test_output" / "ZZ_GladPatchableWin.dat"
    args = [str(default)]
    print(f"No path given, trying default: {default}")

inspect_dat(args[0], "Patched output")
if len(args) > 1:
    inspect_dat(args[1], "Original")
