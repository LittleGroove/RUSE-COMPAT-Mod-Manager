"""
Inspect the two NDF files that changed in the Pinnacle Map Pack's ZZ_GladPatchableWin.dat.
Shows what instances/properties were added, changed, or removed.

Run:
    python tools/inspect_pinnacle_ndf.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

ROOT     = Path(__file__).parent.parent
ORIG_DAT = ROOT / "Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat"
MOD_DAT  = ROOT / "Claude/sources/currently_used_mod_files/RUSE PINNACLE MAP PACK/99/ZZ_GladPatchableWin.dat"

_PREFIX = (
    "genglad\\patchable\\clustergfx\\everythinggdconstantevisibilityia\\launchermap\\alpha\\"
    "chqlmapscriptingbattleofthebulge\\chqlmapeta\\chqlmapchess\\chqlmapscriptingmate\\"
    "chqlmapscriptingompassrose\\chqlmapscriptingdiplomatietriangulaire\\"
    "chqlmapscripting_colly\\chqlmapscriptingedge\\chqlmapscriptinggam_ostfriesland\\"
    "chqlmapma\\chqlmaphurtgen\\chqlmapkorsun\\chqlmaprakdeschevaliers\\"
    "chqlmapursk43_ladder\\chqlmapscriptingm01_leipzig\\chqlmap2_tunisie\\"
    "chqlmapscripting_chapter3_italie\\chqlmapscripting_chapter4_cotentin\\"
    "chqlmapscripting_chapter5_hollande\\chqlmapscripting_chapter6_ardennes\\"
    "chqlmapscripting_chapter7_allemagne\\chqlmapscripting_chapter8_allemagne\\"
    "chqlmapscripting_chapter2ireille\\chqlmapscriptingrobert\\chqlmapseize\\"
    "chqlmapquare\\chqlmapupercrossroads4\\chqlmapscriptingwamps\\"
    "chqlmapscriptingtwoislands\\chqlmapscriptingvalley\\"
)

CHANGED_NDFS = [
    _PREFIX + "chqlmapinfo.cpp.gladndfbin",
    _PREFIX + "chqlmapisc\\globals.cpp.gladndfbin",
]


def describe_value(ndf, val):
    """Return a readable string for an NDF value."""
    if val is None:
        return "<none>"
    try:
        return str(ndf.resolve_value(val))
    except Exception:
        return f"<raw:{val.raw!r}>"


def snapshot(ndf):
    """Return {(class_name, global_idx): {prop_name: resolved_str}}"""
    snap = {}
    for idx, inst in enumerate(ndf.instances):
        cls = ndf.classes[inst.class_index]
        props = {}
        for pv in inst.props:
            prop = next((p for p in ndf.properties if p.index == pv.prop_index), None)
            pname = prop.name if prop else f"prop#{pv.prop_index}"
            props[pname] = describe_value(ndf, pv.value)
        snap[(cls.name, idx)] = props
    return snap


def diff_snapshots(snap_a, snap_b):
    added   = []
    removed = []
    changed = []
    all_keys = set(snap_a) | set(snap_b)
    for key in sorted(all_keys):
        cls_name, idx = key
        if key not in snap_a:
            added.append((cls_name, idx, snap_b[key]))
        elif key not in snap_b:
            removed.append((cls_name, idx, snap_a[key]))
        else:
            pa, pb = snap_a[key], snap_b[key]
            prop_diffs = {}
            for prop in set(pa) | set(pb):
                va, vb = pa.get(prop, "<absent>"), pb.get(prop, "<absent>")
                if va != vb:
                    prop_diffs[prop] = (va, vb)
            if prop_diffs:
                changed.append((cls_name, idx, prop_diffs))
    return added, removed, changed


def print_instance(cls_name, idx, props, label=""):
    tag = f" [{label}]" if label else ""
    print(f"  {cls_name}[{idx}]{tag}")
    for k, v in props.items():
        print(f"    {k} = {v}")


orig_edat = edata_mod.open_dat(str(ORIG_DAT))
mod_edat  = edata_mod.open_dat(str(MOD_DAT))

for ndf_path in CHANGED_NDFS:
    print("=" * 70)
    print(f"NDF: {ndf_path.split(chr(92))[-1]}")
    print("=" * 70)

    orig_bytes = orig_edat.get(ndf_path)
    mod_bytes  = mod_edat.get(ndf_path)

    if orig_bytes is None:
        print(f"  Not in original DAT — entire file is NEW ({len(mod_bytes):,} bytes)")
        mod_ndf = ndfbin_mod.read(mod_bytes)
        print(f"  Mod NDF: {len(mod_ndf.instances)} instances, {len(mod_ndf.classes)} classes")
        for i, inst in enumerate(mod_ndf.instances):
            cls = mod_ndf.classes[inst.class_index]
            props = {
                next((p for p in mod_ndf.properties if p.index == pv.prop_index), type('X', (), {'name': f'prop#{pv.prop_index}'})()).name:
                describe_value(mod_ndf, pv.value)
                for pv in inst.props
            }
            print_instance(cls.name, i, props, "NEW")
        continue

    orig_ndf = ndfbin_mod.read(orig_bytes)
    mod_ndf  = ndfbin_mod.read(mod_bytes)

    print(f"  Original: {len(orig_bytes):,} bytes, {len(orig_ndf.instances)} instances, {len(orig_ndf.classes)} classes")
    print(f"  Mod:      {len(mod_bytes):,} bytes, {len(mod_ndf.instances)} instances, {len(mod_ndf.classes)} classes")

    snap_orig = snapshot(orig_ndf)
    snap_mod  = snapshot(mod_ndf)
    added, removed, changed = diff_snapshots(snap_orig, snap_mod)

    print(f"\n  Added instances:   {len(added)}")
    print(f"  Removed instances: {len(removed)}")
    print(f"  Changed instances: {len(changed)}")

    if added:
        print("\n--- ADDED ---")
        for cls_name, idx, props in added:
            print_instance(cls_name, idx, props, "ADDED")

    if removed:
        print("\n--- REMOVED ---")
        for cls_name, idx, props in removed:
            print_instance(cls_name, idx, props, "REMOVED")

    if changed:
        print("\n--- CHANGED ---")
        for cls_name, idx, prop_diffs in changed:
            print(f"  {cls_name}[{idx}]")
            for prop, (va, vb) in prop_diffs.items():
                print(f"    {prop}: {va!r} -> {vb!r}")

    print()
