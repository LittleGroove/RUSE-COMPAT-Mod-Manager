"""
inspect_ndf.py — browse NDF binary files from inside a RUSE .dat archive.

Usage:
  # List all NDF classes in a .dat
  python tools/inspect_ndf.py <path.dat> <internal/path.ndfbin> --classes

  # List all instances of a class
  python tools/inspect_ndf.py <path.dat> <internal/path.ndfbin> --table TUniteAuSolDescriptor

  # Show one instance's properties (matched by ClassNameForDebug)
  python tools/inspect_ndf.py <path.dat> <internal/path.ndfbin> \\
      --table TUniteAuSolDescriptor --match ClassNameForDebug=Unit_Tiger

  # Show every property of every instance that contains a string
  python tools/inspect_ndf.py <path.dat> <internal/path.ndfbin> \\
      --table TUniteAuSolDescriptor --search "Tiger"

  # Read a raw .ndfbin file directly (already extracted)
  python tools/inspect_ndf.py --raw <path.ndfbin> --classes
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import edata as edata_mod
from ruse_mod_engine import ndfbin as ndfbin_mod


def _load_ndf(args) -> ndfbin_mod.NdfBinary:
    if args.raw:
        data = Path(args.raw).read_bytes()
        return ndfbin_mod.read(data)

    if not args.dat or not args.ndf:
        print("ERROR: Provide --raw <ndfbin_file>  or  <dat_file> <ndf_path_in_dat>",
              file=sys.stderr)
        sys.exit(1)

    edat = edata_mod.open_dat(args.dat)
    data = edat.get(args.ndf)
    if data is None:
        print(f"ERROR: {args.ndf!r} not found in {args.dat}", file=sys.stderr)
        print("Available paths:")
        for p in edat.list():
            print(f"  {p}")
        sys.exit(1)
    return ndfbin_mod.read(data)


def _fmt_value(ndf: ndfbin_mod.NdfBinary, val: ndfbin_mod.NdfValue) -> str:
    """Human-readable representation of an NdfValue."""
    resolved = ndf.resolve_value(val)
    type_name = ndfbin_mod.T.name(val.type_id)
    if isinstance(resolved, bytes):
        return f"[{type_name}] 0x{resolved.hex()}"
    if isinstance(resolved, list):
        if len(resolved) > 6:
            return f"[{type_name}] [{', '.join(str(x) for x in resolved[:6])}, …] ({len(resolved)} items)"
        return f"[{type_name}] {resolved}"
    return f"[{type_name}] {resolved}"


def cmd_classes(ndf: ndfbin_mod.NdfBinary):
    print(f"Classes ({len(ndf.classes)}):")
    for cls in ndf.classes:
        inst_count = len(ndf.class_instances(cls.index))
        print(f"  [{cls.index:4d}] {cls.name:<60} ({inst_count} instances)")


def cmd_table(ndf: ndfbin_mod.NdfBinary, table: str, match: dict, search: str, limit: int):
    cls = ndf.class_by_name(table)
    if cls is None:
        print(f"ERROR: Class '{table}' not found.")
        print("Available classes (first 20):")
        for c in ndf.classes[:20]:
            print(f"  {c.name}")
        sys.exit(1)

    instances = ndf.find_instances(table, match if match else None)
    if not instances:
        print(f"No instances of '{table}' matched {match}.")
        return

    print(f"Table: {table}  ({len(instances)} instance(s) shown)")
    print()

    shown = 0
    for inst_idx, inst in instances:
        if limit and shown >= limit:
            print(f"  … (limit {limit} reached; use --limit to see more)")
            break
        print(f"  Instance #{inst_idx}:")
        for pv in inst.props:
            prop = ndf.properties[pv.prop_index] if pv.prop_index < len(ndf.properties) else None
            prop_name = prop.name if prop else f"prop#{pv.prop_index}"
            val_str = _fmt_value(ndf, pv.value)
            if search and search.lower() not in val_str.lower() and search.lower() not in prop_name.lower():
                continue
            print(f"    {prop_name:<45} {val_str}")
        print()
        shown += 1


def cmd_strings(ndf: ndfbin_mod.NdfBinary, search: str):
    print(f"String table ({len(ndf.strings)} entries):")
    for i, s in enumerate(ndf.strings):
        if search and search.lower() not in s.lower():
            continue
        print(f"  [{i:5d}] {s!r}")


def cmd_trans(ndf: ndfbin_mod.NdfBinary, search: str):
    print(f"Trans table ({len(ndf.trans)} entries):")
    for i, s in enumerate(ndf.trans):
        if search and search.lower() not in s.lower():
            continue
        print(f"  [{i:5d}] {s!r}")


def main():
    parser = argparse.ArgumentParser(
        description="Browse NDF binary files from RUSE .dat archives",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("dat", nargs="?", help="Path to the .dat archive")
    parser.add_argument("ndf", nargs="?", help="Internal NDF path inside the .dat")
    parser.add_argument("--raw", help="Read a .ndfbin file directly (no .dat needed)")
    parser.add_argument("--classes", action="store_true", help="List all NDF classes")
    parser.add_argument("--table", "-t", help="Show instances of this NDF class")
    parser.add_argument("--match", "-m", nargs="*",
                        help="Match conditions: PROP=VALUE (multiple allowed)")
    parser.add_argument("--search", "-s", help="Filter output to lines containing this string")
    parser.add_argument("--strings", action="store_true", help="Show string table")
    parser.add_argument("--trans", action="store_true", help="Show trans table")
    parser.add_argument("--limit", "-n", type=int, default=0,
                        help="Max instances to show per table (0 = all)")
    args = parser.parse_args()

    if not (args.classes or args.table or args.strings or args.trans):
        parser.print_help()
        sys.exit(0)

    ndf = _load_ndf(args)

    # Parse match conditions
    match = {}
    if args.match:
        for m in args.match:
            if "=" not in m:
                print(f"ERROR: Match condition must be PROP=VALUE, got: {m!r}", file=sys.stderr)
                sys.exit(1)
            k, _, v = m.partition("=")
            match[k.strip()] = v.strip()

    if args.classes:
        cmd_classes(ndf)
    if args.strings:
        cmd_strings(ndf, args.search or "")
    if args.trans:
        cmd_trans(ndf, args.search or "")
    if args.table:
        cmd_table(ndf, args.table, match, args.search or "", args.limit)


if __name__ == "__main__":
    main()
