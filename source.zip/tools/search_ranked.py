import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata
import ruse_mod_engine.ndfbin as ndfbin
import os

DAT_FILES = [
    'Claude/sources/RUSE-game/Data/PC/1360/ZZ_GladPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/1360/ZZ_GladNotPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/1360/ZZ_Win.dat',
    'Claude/sources/RUSE-game/Data/PC/1360/Data_Common.dat',
    'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladNotPatchableWin.dat',
]

TERMS = [b'ranked', b'Ranked', b'RANKED', b'rank', b'Rank']

for dat_path in DAT_FILES:
    if not os.path.exists(dat_path):
        print(f'MISSING: {dat_path}')
        continue
    arc = edata.open_dat(dat_path)
    for e in arc._entries:
        raw = arc.get(e.path)
        for term in TERMS:
            if term in raw:
                print(f'{dat_path}  |  {e.path}  |  contains "{term.decode()}"')
                break
