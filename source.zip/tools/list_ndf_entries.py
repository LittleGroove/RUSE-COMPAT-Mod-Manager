import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata
import os

DAT_FILES = [
    ('PC/99/ZZ_GladNotPatchableWin.dat', 'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladNotPatchableWin.dat'),
    ('PC/1360/ZZ_GladNotPatchableWin.dat', 'Claude/sources/RUSE-game/Data/PC/1360/ZZ_GladNotPatchableWin.dat'),
    ('PC/1360/Data_Common.dat', 'Claude/sources/RUSE-game/Data/PC/1360/Data_Common.dat'),
    ('PC/1360/ZZ_Win.dat', 'Claude/sources/RUSE-game/Data/PC/1360/ZZ_Win.dat'),
]

for label, dat_path in DAT_FILES:
    if not os.path.exists(dat_path):
        print(f'MISSING: {dat_path}')
        continue
    arc = edata.open_dat(dat_path)
    ndf_entries = [e.path for e in arc._entries if e.path.lower().endswith('.gladndfbin')]
    print(f'\n=== {label} ({len(ndf_entries)} NDF entries) ===')
    for p in ndf_entries:
        print(f'  {p}')
