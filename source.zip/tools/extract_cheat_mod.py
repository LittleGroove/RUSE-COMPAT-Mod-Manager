"""
Build rmod files by diffing a mod DAT against the original game DAT.

Usage:
    python tools/extract_cheat_mod.py               # builds both rmod outputs
    python tools/extract_cheat_mod.py --only-cheat  # cheat_mod_v1.2.rmod only
    python tools/extract_cheat_mod.py --only-economy # example_cheat_economy.rmod only
"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ruse_mod_engine import edata as edata_mod, ndfbin as ndfbin_mod

ROOT      = Path(__file__).parent.parent
ORIG_DAT  = ROOT / "Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat"
CHEAT_DAT = ROOT / "Claude/sources/currently_used_mod_files/Cheat Mod v1.2/99/ZZ_GladPatchableWin.dat"

# NDF files to compare (internal DAT paths, backslash)
NDFS = [
    "genglad\\patchable\\clustergfx\\everything.cpp.gladndfbin",
    "genglad\\patchable\\clustergfx\\everythinggdconstanteoriginal.cpp.gladndfbin",
]

# rmod DAT/NDF paths (forward slash, relative to game Data root)
NDF_RMOD_PATHS = {
    "genglad\\patchable\\clustergfx\\everything.cpp.gladndfbin":
        ("PC/99/ZZ_GladPatchableWin.dat",
         "genglad/patchable/clustergfx/everything.cpp.gladndfbin"),
    "genglad\\patchable\\clustergfx\\everythinggdconstanteoriginal.cpp.gladndfbin":
        ("PC/99/ZZ_GladPatchableWin.dat",
         "genglad/patchable/clustergfx/everythinggdconstanteoriginal.cpp.gladndfbin"),
}

# Extra TTunableConstante overrides added on top for the economy rmod
ECONOMY_EXTRAS = {
    "QteDeviseInitiale":               9999,
    "QuantiteGenAutoDevises":          99,
    "QteDeviseParCamion":              99,
    "NbCamionParConvoi":               4,
    "TempsENtreDeuxConvois":           30,
    "StockDeviseSupplementaireFacile": 9999,
}

TYPE_NAMES = {
    ndfbin_mod.T.Bool:    "Bool",
    ndfbin_mod.T.Int8:    "Int8",
    ndfbin_mod.T.Int16:   "Int16",
    ndfbin_mod.T.Int32:   "Int32",
    ndfbin_mod.T.UInt32:  "UInt32",
    ndfbin_mod.T.Float32: "Float32",
    ndfbin_mod.T.Float64: "Float64",
}


def val_type_name(val: ndfbin_mod.NdfValue) -> str:
    if val.type_id == ndfbin_mod.T.List:
        inner = TYPE_NAMES.get(val.raw[0].type_id, "Int32") if val.raw else "Int32"
        return f"List<{inner}>"
    return TYPE_NAMES.get(val.type_id, f"0x{val.type_id:02X}")


def serialise_val(ndf, val: ndfbin_mod.NdfValue):
    if val.type_id == ndfbin_mod.T.List:
        return [item.raw for item in val.raw]
    return val.raw


def diff_ndf(orig_ndf, mod_ndf) -> list[dict]:
    """Return rmod change objects for every instance that differs."""
    changes = []

    for i, (orig_inst, mod_inst) in enumerate(zip(orig_ndf.instances, mod_ndf.instances)):
        if orig_inst.class_index != mod_inst.class_index:
            continue

        orig_props = {pv.prop_index: pv.value for pv in orig_inst.props}
        mod_props  = {pv.prop_index: pv.value for pv in mod_inst.props}

        changed_set: dict[str, dict] = {}

        # Properties the mod changed or added
        for idx, cv in mod_props.items():
            ov = orig_props.get(idx)
            if ov is not None and str(orig_ndf.resolve_value(ov)) == str(mod_ndf.resolve_value(cv)):
                continue  # unchanged
            prop = next((p for p in orig_ndf.properties if p.index == idx), None)
            if prop is None:
                continue
            changed_set[prop.name] = {
                "type":  val_type_name(cv),
                "value": serialise_val(mod_ndf, cv),
            }

        # Properties the mod removed — emit as delete_props
        removed_props = []
        for idx in orig_props:
            if idx not in mod_props:
                prop = next((p for p in orig_ndf.properties if p.index == idx), None)
                if prop is not None:
                    removed_props.append(prop.name)

        if not changed_set and not removed_props:
            continue

        cls_name   = orig_ndf.classes[orig_inst.class_index].name
        debug_prop = orig_ndf.prop_by_name_and_class("ClassNameForDebug", orig_inst.class_index)
        name_v     = orig_inst.get(debug_prop.index) if debug_prop else None
        inst_name  = str(orig_ndf.resolve_value(name_v)) if name_v else None

        if inst_name is None:
            # Fall back to DescriptorId or index
            desc_prop = orig_ndf.prop_by_name_and_class("DescriptorId", orig_inst.class_index)
            did = orig_inst.get(desc_prop.index) if desc_prop else None
            inst_name = str(orig_ndf.resolve_value(did)) if did else f"inst#{i}"
            match = {"DescriptorId": int(inst_name)} if inst_name.isdigit() else {}
        else:
            match = {"ClassNameForDebug": inst_name}

        if changed_set:
            changes.append({
                "action": "patch",
                "table":  cls_name,
                "match":  match,
                "set":    changed_set,
            })

        if removed_props:
            changes.append({
                "action": "delete_props",
                "table":  cls_name,
                "match":  match,
                "props":  removed_props,
            })

    return changes


def build_patches_from_diff(orig_edat, mod_edat) -> dict[str, list[dict]]:
    """Returns {ndf_bs_path: [change, ...]} for all diffed NDF files."""
    result = {}
    for ndf_path in NDFS:
        orig_bytes = orig_edat.get(ndf_path)
        mod_bytes  = mod_edat.get(ndf_path)
        if orig_bytes is None or mod_bytes is None:
            print(f"  Skipping {ndf_path} (not found in one of the DATs)")
            continue
        print(f"  Diffing {ndf_path.split(chr(92))[-1]}…")
        orig_ndf = ndfbin_mod.read(orig_bytes)
        mod_ndf  = ndfbin_mod.read(mod_bytes)
        changes  = diff_ndf(orig_ndf, mod_ndf)
        print(f"    {len(changes)} instance(s) changed")
        if changes:
            result[ndf_path] = changes
    return result


def patches_to_rmod_patches(changes_by_ndf: dict) -> list[dict]:
    patch_groups = []
    for ndf_bs, changes in changes_by_ndf.items():
        dat_path, ndf_fwd = NDF_RMOD_PATHS[ndf_bs]
        patch_groups.append({
            "dat":     dat_path,
            "ndf":     ndf_fwd,
            "changes": changes,
        })
    return patch_groups


def write_rmod(path: Path, mod_id: str, name: str, description: str,
               patch_groups: list[dict]):
    mod = {
        "$schema":     "ruse-mod/v1",
        "id":          mod_id,
        "name":        name,
        "version":     "1.0.0",
        "author":      "Extracted",
        "description": description,
        "patches":     patch_groups,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(mod, f, indent=2, ensure_ascii=False)
    total = sum(len(pg["changes"]) for pg in patch_groups)
    print(f"  Wrote {path.name} ({total} change(s) across {len(patch_groups)} patch group(s))")


def main():
    only_cheat   = "--only-cheat"   in sys.argv
    only_economy = "--only-economy" in sys.argv

    print("Opening DATs…")
    orig_edat  = edata_mod.open_dat(str(ORIG_DAT))
    cheat_edat = edata_mod.open_dat(str(CHEAT_DAT))

    print("\nDiffing Cheat Mod v1.2 vs original…")
    cheat_changes = build_patches_from_diff(orig_edat, cheat_edat)

    # ── cheat_mod_v1.2.rmod ─────────────────────────────────────────────────
    if not only_economy:
        print("\nWriting cheat_mod_v1.2.rmod…")
        write_rmod(
            ROOT / "mods" / "cheat_mod_v1.2.rmod",
            mod_id      = "cheat-mod-v1-2",
            name        = "Cheat Mod v1.2",
            description = "Exact replication of Cheat Mod v1.2 unit prices and production times.",
            patch_groups= patches_to_rmod_patches(cheat_changes),
        )

    # ── example_cheat_economy.rmod ───────────────────────────────────────────
    if not only_cheat:
        print("\nWriting example_cheat_economy.rmod…")

        # Add TTunableConstante extras to the constante patch group
        const_ndf_bs = "genglad\\patchable\\clustergfx\\everythinggdconstanteoriginal.cpp.gladndfbin"
        const_bytes  = orig_edat.get(const_ndf_bs)
        const_ndf    = ndfbin_mod.read(const_bytes)

        extra_changes = []
        for prop_name, new_val in ECONOMY_EXTRAS.items():
            prop = const_ndf.prop_by_name(prop_name)
            if prop is None:
                print(f"  WARNING: {prop_name!r} not found in constante NDF")
                continue
            for inst in const_ndf.instances:
                v = inst.get(prop.index)
                if v is not None:
                    tname = TYPE_NAMES.get(v.type_id, "Int32")
                    extra_changes.append({
                        "action": "patch",
                        "table":  "TTunableConstante",
                        "match":  {},
                        "set":    {prop_name: {"type": tname, "value": new_val}},
                    })
                    break

        # Merge extra constante changes into existing constante patch group (or add new)
        economy_patches = list(patches_to_rmod_patches(cheat_changes))
        const_fwd = NDF_RMOD_PATHS[const_ndf_bs][1]
        const_dat = NDF_RMOD_PATHS[const_ndf_bs][0]
        for pg in economy_patches:
            if pg["ndf"] == const_fwd:
                pg["changes"] = extra_changes + pg["changes"]
                break
        else:
            economy_patches.append({
                "dat":     const_dat,
                "ndf":     const_fwd,
                "changes": extra_changes,
            })

        write_rmod(
            ROOT / "mods" / "example_cheat_economy.rmod",
            mod_id      = "example-cheat-economy",
            name        = "Cheat Economy",
            description = (
                "Cheat Mod v1.2 unit prices + production times, plus economy boosts: "
                "9999 starting money, 99 income/tick, 99/truck, "
                "4 trucks/convoy, 30s interval, 9999 easy bonus."
            ),
            patch_groups = economy_patches,
        )


if __name__ == "__main__":
    main()
