import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import ruse_mod_engine.edata as edata
import ruse_mod_engine.ndfbin as ndfbin
import os

DAT_FILES = [
    'Claude/sources/RUSE-game/Data/PC/1360/ZZ_GladPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/1360/ZZ_GladNotPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladPatchableWin.dat',
    'Claude/sources/RUSE-game/Data/PC/99/ZZ_GladNotPatchableWin.dat',
]

TERMS = ['ranked', 'Ranked', 'rank', 'Rank', 'matchmaking', 'Matchmaking']

for dat_path in DAT_FILES:
    if not os.path.exists(dat_path):
        print(f'MISSING: {dat_path}')
        continue
    arc = edata.open_dat(dat_path)
    for e in arc._entries:
        p = e.path.lower()
        if not p.endswith('.gladndfbin'):
            continue
        raw = arc.get(e.path)
        try:
            ndf = ndfbin.read(raw)
        except Exception as ex:
            continue
        for s in ndf.strings:
            for term in TERMS:
                if term.lower() in s.lower():
                    print(f'{dat_path}  |  {e.path}')
                    print(f'  string: {repr(s)}')
                    break
