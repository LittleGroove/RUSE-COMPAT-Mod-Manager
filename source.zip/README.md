# RUSE Mod Manager

A new mod format and toolchain for **R.U.S.E.** that lets multiple mods coexist on the same `.dat` files.

## The Problem

Traditional RUSE mods distribute a complete replacement `.dat` file.  Because many mods target the same files (e.g. `ZZ_GladPatchableWin.dat`), only one mod can be active at a time — installing a second mod overwrites the first.

## The Solution: `.rmod` files

A `.rmod` file is a small JSON document describing **what to change** inside a `.dat` archive, not a full replacement.  The mod engine opens the game's `.dat`, applies only the specified changes, and writes the result back.  Multiple `.rmod` files targeting the same `.dat` file are applied in sequence — they are naturally compatible as long as they don't modify the same property on the same unit.

---

## Project Structure

```
ModManager/
├── ruse_mod_engine/       ← core Python library
│   ├── edata.py           ← .dat (edata) container read/write
│   ├── ndfbin.py          ← NDF binary parse/serialize + object model
│   ├── mod_format.py      ← .rmod JSON format definition
│   └── applier.py         ← mod application engine
├── tools/
│   ├── apply_mods.py      ← CLI: apply .rmod files to game data
│   ├── inspect_dat.py     ← CLI: browse .dat archive contents
│   ├── inspect_ndf.py     ← CLI: browse NDF classes and instances
│   └── create_rmod.py     ← CLI: create .rmod from template or diff
├── mods/
│   ├── example_cheat.rmod
│   └── example_balance.rmod
└── README.md
```

---

## Requirements

- **Python 3.8+** (no third-party packages needed — pure stdlib)

---

## Quick Start

### 1. Apply a mod

```bat
python tools\apply_mods.py mods\example_balance.rmod ^
    --game-dir "C:\Program Files (x86)\Steam\steamapps\common\R.U.S.E\Data"
```

A `.dat.bak` backup is created automatically before any file is changed.

### 2. Apply multiple mods (they stack!)

```bat
python tools\apply_mods.py mods\balance.rmod mods\cheat.rmod ^
    --game-dir "C:\...\R.U.S.E\Data"
```

Later mods override earlier ones when they modify the same property.

### 3. Check for conflicts before applying

```bat
python tools\apply_mods.py mods\balance.rmod mods\cheat.rmod ^
    --game-dir "C:\...\R.U.S.E\Data" --check-conflicts
```

### 4. Restore original files from backup

```bat
python tools\apply_mods.py ^
    --restore "C:\...\R.U.S.E\Data\PC\99\ZZ_GladPatchableWin.dat"
```

### 5. Browse what's inside a .dat

```bat
python tools\inspect_dat.py "C:\...\R.U.S.E\Data\PC\99\ZZ_GladPatchableWin.dat"
```

### 6. Browse NDF classes and instances

```bat
REM List all NDF classes
python tools\inspect_ndf.py "C:\...\ZZ_GladPatchableWin.dat" ^
    "pc/ndf/patchable/gfx/everything.ndfbin" --classes

REM Show all ground unit instances
python tools\inspect_ndf.py "C:\...\ZZ_GladPatchableWin.dat" ^
    "pc/ndf/patchable/gfx/everything.ndfbin" ^
    --table TUniteAuSolDescriptor

REM Show just the Tiger
python tools\inspect_ndf.py "C:\...\ZZ_GladPatchableWin.dat" ^
    "pc/ndf/patchable/gfx/everything.ndfbin" ^
    --table TUniteAuSolDescriptor --match ClassNameForDebug=Unit_Tiger
```

### 7. Convert an existing mod to .rmod

If you have an original and a modded `.dat`, diff them:

```bat
python tools\create_rmod.py diff ^
    --original "originals\ZZ_GladPatchableWin.dat" ^
    --modified  "mods_dat\ZZ_GladPatchableWin.dat" ^
    --ndf "pc/ndf/patchable/gfx/everything.ndfbin" ^
    --name "My Converted Mod" --author "Me" ^
    -o mods\converted.rmod
```

### 8. Create a blank .rmod template

```bat
python tools\create_rmod.py template -o mods\my_mod.rmod
```

---

## .rmod Format Reference

```json
{
  "$schema": "ruse-mod/v1",
  "id": "my-mod",
  "name": "My Mod Name",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "What this mod changes",
  "patches": [
    {
      "dat": "PC/99/ZZ_GladPatchableWin.dat",
      "ndf": "pc/ndf/patchable/gfx/everything.ndfbin",
      "changes": [
        {
          "action": "patch",
          "table": "TUniteAuSolDescriptor",
          "match": { "ClassNameForDebug": "Unit_Tiger" },
          "set": {
            "MaxPhysicalDamages": { "type": "Int32",   "value": 300  },
            "MaxSpeed":           { "type": "Float32", "value": 18.0 }
          }
        }
      ]
    }
  ]
}
```

### Actions

| Action   | Description |
|----------|-------------|
| `patch`  | Find matching instance(s) and update their properties |
| `delete` | Remove matching instance(s) from the table |
| `create` | Add a new instance to the table |

### Supported Types

| Type name     | NDF meaning |
|---------------|-------------|
| `Bool`        | Boolean (0/1) |
| `Int8`        | 8-bit signed integer |
| `Int16`       | 16-bit signed integer |
| `UInt16`      | 16-bit unsigned integer |
| `Int32`       | 32-bit signed integer (most common for costs, HP, times) |
| `UInt32`      | 32-bit unsigned integer |
| `Long`        | 64-bit signed integer |
| `Float32`     | 32-bit float (speeds, ranges, multipliers) |
| `Float64`     | 64-bit double |
| `StringRef`   | String value (resolved via STRG table) |
| `PathRef`     | Filename string (resolved via STRG table) |
| `WideStr`     | UTF-16 wide string |
| `Vector3`     | 3-component float vector `[x, y, z]` |
| `Int2`        | 2-component int pair `[x, y]` |
| `Float2`      | 2-component float pair `[x, y]` |

### Common RUSE .dat targets

| File | What it contains |
|------|-----------------|
| `PC/99/ZZ_GladPatchableWin.dat` | Main game data: units, weapons, buildings, AI, constants |
| `PC/99/ZZ_GladNotPatchableWin.dat` | Non-patchable core game data |
| `PC/1360/Data_Common.dat` | Common 1360-resolution data |
| `PC/1360/IA_Common.dat` | Mission scripts (.xyz files) |

### Common NDF targets inside ZZ_GladPatchableWin.dat

| Path | Contents |
|------|----------|
| `pc/ndf/patchable/gfx/everything.ndfbin` | All unit/weapon/building/AI descriptors |
| `pc/ndf/patchable/gfx/globals.cpp.gladndfbin` | Global game constants |
| `pc/ndf/patchable/gfx/mapinfo.cpp.gladndfbin` | Map info and clustermap data |

### Common NDF classes

| Class | Description |
|-------|-------------|
| `TUniteAuSolDescriptor` | Ground units (infantry, tanks, artillery, vehicles) |
| `TAvionDescriptor` | Aircraft |
| `TBatimentDescriptor` | Buildings (barracks, factories, airports) |
| `TAmmunition` | Weapon ammunition (damage, range, accuracy) |
| `TWeaponDescriptor` | Weapon system configs |
| `TGameDesignAddOn` | Game constants (starting money, time limits, etc.) |
| `TIAStratModuleDescriptor` | AI strategy profiles |
| `TMultiMapInfo` | Multiplayer map definitions |

---

## How Multiple Mods Stack

Given `balance.rmod` and `cheat.rmod` both patching `ZZ_GladPatchableWin.dat`:

1. Engine opens the **vanilla** `.dat` (or the already-patched one if applying sequentially)
2. Applies `balance.rmod` changes → writes result
3. Applies `cheat.rmod` changes on top → writes final result

If both mods change `Unit_Tiger.ProductionPrice`, the last applied value wins.
The `--check-conflicts` flag warns you about this before applying.

---

## Converting Existing Mods

To convert the "Adjusted Times and Costs" mod or "Cheat Mod v1.2" to .rmod format:

1. Keep the original vanilla `.dat` somewhere safe
2. Run `create_rmod.py diff` pointing at the vanilla and modded `.dat`
3. The generated `.rmod` captures every changed property as a patch entry
4. Share the tiny `.rmod` instead of the full `.dat`

This is the whole point: **dozens of mods, one set of `.dat` files**.
