"""
Conversion utilities: diff old-style mod .dat files against originals and
produce .rmod patch files.  Used by both mod_manager.py and convert_mod_gui.py.
"""

import base64
import json
import re
from pathlib import Path

from . import edata as edata_mod
from . import ndfbin as ndfbin_mod
from .ndfbin import T


# ── Helpers ───────────────────────────────────────────────────────────────────

def name_to_id(name: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", name.lower()).strip("-")
    return slug or "my-mod"


def sanitize_filename(name: str) -> str:
    safe = re.sub(r'[\\/:*?"<>|]', "", name)
    safe = re.sub(r"\s+", "_", safe.strip())
    return safe or "mod"


# ── Type serialisation ────────────────────────────────────────────────────────

_SCALAR_TYPES = {
    T.Bool:      "Bool",
    T.Int8:      "Int8",
    T.Int16:     "Int16",
    T.UInt16:    "UInt16",
    T.Int32:     "Int32",
    T.UInt32:    "UInt32",
    T.Long:      "Long",
    T.Float32:   "Float32",
    T.Float64:   "Float64",
    T.StringRef: "StringRef",
    T.PathRef:   "PathRef",
    T.WideStr:   "WideStr",
}


def val_to_rmod(ndf, val):
    """Convert NdfValue → (type_name, json_value). Returns None if unsupported."""
    t = val.type_id

    if t == T.Bool:
        return ("Bool", int(val.raw))

    if t in _SCALAR_TYPES and t not in (T.StringRef, T.PathRef, T.WideStr):
        return (_SCALAR_TYPES[t], val.raw)

    if t in (T.StringRef, T.PathRef):
        return (_SCALAR_TYPES[t], str(ndf.resolve_value(val)))

    if t == T.WideStr:
        return ("WideStr", val.raw)

    if t == T.Vector3:
        return ("Vector3", list(val.raw))

    if t == T.Color128:
        return ("Color128", list(val.raw))

    if t == T.Color32:
        return ("Color32", list(val.raw))

    if t == T.TripleInt:
        return ("TripleInt", list(val.raw))

    if t == T.Int2:
        return ("Int2", list(val.raw))

    if t == T.Float2:
        return ("Float2", list(val.raw))

    if t == T.Matrix:
        return ("Matrix", list(val.raw))

    if t == T.Blob:
        return ("Blob", base64.b64encode(val.raw).decode("ascii"))

    if t == T.ZipBlob:
        data = val.raw.get("data", b"")
        flag = val.raw.get("flag", 0)
        return ("ZipBlob", {"flag": flag, "data": base64.b64encode(data).decode("ascii")})

    if t == T.Hash:
        return ("Hash", val.raw.hex())

    if t == T.Pair:
        k_res = val_to_rmod(ndf, val.raw[0])
        v_res = val_to_rmod(ndf, val.raw[1])
        if k_res is None or v_res is None:
            return None
        return ("Pair", [{"type": k_res[0], "value": k_res[1]},
                          {"type": v_res[0], "value": v_res[1]}])

    if t == T.List:
        if not val.raw:
            return ("List<Int32>", [])
        inner = val_to_rmod(ndf, val.raw[0])
        if inner is None:
            return None
        items = []
        for item in val.raw:
            r = val_to_rmod(ndf, item)
            if r is None:
                return None
            items.append(r[1])
        return (f"List<{inner[0]}>", items)

    if t == T.Reference:
        marker, ref = val.raw
        if marker == ndfbin_mod.OBJ_REF_MARKER:
            obj_idx, cls_idx = ref
            return ("ObjRef", {"inst": obj_idx, "class": cls_idx})
        if marker == ndfbin_mod.TRANS_REF_MARKER:
            return ("TransRef", {"trans": ref})
        return None

    if t == T.LocHash:
        return ("LocHash", val.raw.hex())

    if t == T.Guid:
        return ("Guid", val.raw.hex())

    if t == T.Map:
        if not val.raw:
            return ("Map<Int32,Int32>", [])
        k0, v0 = val.raw[0]
        ki = val_to_rmod(ndf, k0)
        vi = val_to_rmod(ndf, v0)
        if ki is None or vi is None:
            return None
        items = []
        for k, v in val.raw:
            kr = val_to_rmod(ndf, k)
            vr = val_to_rmod(ndf, v)
            if kr is None or vr is None:
                return None
            items.append([kr[1], vr[1]])
        return (f"Map<{ki[0]},{vi[0]}>", items)

    return None


# ── NDF diff ──────────────────────────────────────────────────────────────────

def _serialize_props(inst, ndf, warn_fn) -> dict:
    set_props = {}
    for pv in inst.props:
        prop = next((p for p in ndf.properties if p.index == pv.prop_index), None)
        if prop is None:
            continue
        result = val_to_rmod(ndf, pv.value)
        if result is None:
            warn_fn(f"    SKIP unsupported type 0x{pv.value.type_id:02X} "
                    f"on prop '{prop.name}' (new instance)")
            continue
        set_props[prop.name] = {"type": result[0], "value": result[1]}
    return set_props


def diff_ndf(orig_ndf, mod_ndf, warn_fn) -> list:
    """Return rmod change dicts for every differing instance."""
    changes = []
    orig_count = len(orig_ndf.instances)

    for i in range(orig_count, len(mod_ndf.instances)):
        inst = mod_ndf.instances[i]
        cls_name = mod_ndf.classes[inst.class_index].name
        set_props = _serialize_props(inst, mod_ndf, warn_fn)
        if set_props:
            changes.append({
                "action":   "create",
                "table":    cls_name,
                "local_id": f"inst_{i}",
                "set":      set_props,
            })

    for i, (orig_inst, mod_inst) in enumerate(
            zip(orig_ndf.instances, mod_ndf.instances)):
        if orig_inst.class_index != mod_inst.class_index:
            continue

        orig_props = {pv.prop_index: pv.value for pv in orig_inst.props}
        mod_props  = {pv.prop_index: pv.value for pv in mod_inst.props}

        changed_set = {}
        for idx, cv in mod_props.items():
            ov = orig_props.get(idx)
            if ov is not None and (str(orig_ndf.resolve_value(ov)) ==
                                   str(mod_ndf.resolve_value(cv))):
                continue
            prop = next((p for p in orig_ndf.properties if p.index == idx), None)
            if prop is None:
                continue
            result = val_to_rmod(mod_ndf, cv)
            if result is None:
                warn_fn(f"    SKIP unsupported type 0x{cv.type_id:02X} "
                        f"on prop '{prop.name}'")
                continue
            changed_set[prop.name] = {"type": result[0], "value": result[1]}

        removed = [
            p.name
            for idx in orig_props
            if idx not in mod_props
            for p in [next((p for p in orig_ndf.properties if p.index == idx), None)]
            if p is not None
        ]

        if not changed_set and not removed:
            continue

        cls_name = orig_ndf.classes[orig_inst.class_index].name

        debug_p = orig_ndf.prop_by_name_and_class("ClassNameForDebug",
                                                   orig_inst.class_index)
        name_v  = orig_inst.get(debug_p.index) if debug_p else None
        if name_v is not None and "ClassNameForDebug" not in changed_set:
            match = {"ClassNameForDebug": str(orig_ndf.resolve_value(name_v))}
        else:
            desc_p = orig_ndf.prop_by_name_and_class("DescriptorId",
                                                      orig_inst.class_index)
            did = orig_inst.get(desc_p.index) if desc_p else None
            if did is not None and "DescriptorId" not in changed_set:
                match = {"DescriptorId": str(orig_ndf.resolve_value(did))}
            else:
                match = {"_index": str(i)}

        if changed_set:
            changes.append({"action": "patch", "table": cls_name,
                             "match": match, "set": changed_set})
        if removed:
            changes.append({"action": "delete_props", "table": cls_name,
                             "match": match, "props": removed})

    return changes


# ── DAT pair conversion ───────────────────────────────────────────────────────

def convert_dat_pair(mod_dat: Path, orig_dat: Path, rmod_dat_path: str,
                     log_fn, warn_fn):
    """Compare one modded .dat against its original.
    Returns (patch_groups, file_patches_group_or_None)."""
    mod_edat  = edata_mod.open_dat(str(mod_dat))
    orig_edat = edata_mod.open_dat(str(orig_dat))

    patch_groups     = []
    raw_file_patches = []

    for entry_path in mod_edat.list():
        mod_bytes  = mod_edat.get(entry_path)
        orig_bytes = orig_edat.get(entry_path)
        if orig_bytes is None:
            orig_bytes = orig_edat.get(entry_path.replace("\\", "/"))
        if orig_bytes is None:
            orig_bytes = orig_edat.get(entry_path.replace("/", "\\"))

        if orig_bytes is not None and orig_bytes == mod_bytes:
            continue

        entry_fwd   = entry_path.replace("\\", "/")
        entry_lower = entry_fwd.lower()
        is_ndf      = (entry_lower.endswith(".ndfbin") or
                       entry_lower.endswith(".gladndfbin"))

        if is_ndf and orig_bytes is not None:
            log_fn(f"  Diffing NDF: {entry_fwd.split('/')[-1]}")
            try:
                orig_ndf = ndfbin_mod.read(orig_bytes)
                mod_ndf  = ndfbin_mod.read(mod_bytes)
                changes  = diff_ndf(orig_ndf, mod_ndf, warn_fn)
                log_fn(f"    {len(changes)} change(s)")
                if changes:
                    patch_groups.append({"dat": rmod_dat_path,
                                         "ndf": entry_fwd,
                                         "changes": changes})
            except Exception as e:
                warn_fn(f"  NDF parse failed ({e}) — adding as raw file patch")
                raw_file_patches.append({
                    "path": entry_fwd,
                    "data": base64.b64encode(mod_bytes).decode("ascii"),
                })
        else:
            label = "New file" if orig_bytes is None else "Changed (non-NDF)"
            log_fn(f"  {label}: {entry_fwd.split('/')[-1]}")
            raw_file_patches.append({
                "path": entry_fwd,
                "data": base64.b64encode(mod_bytes).decode("ascii"),
            })

    file_group = ({"dat": rmod_dat_path, "files": raw_file_patches}
                  if raw_file_patches else None)
    return patch_groups, file_group


# ── Folder scan ───────────────────────────────────────────────────────────────

def scan_mod_folder(mod_folder: str, game_data_dir: str) -> list:
    """Find .dat files in mod_folder and match them to originals.
    Returns list of (mod_dat_path, orig_dat_path, rmod_dat_rel_str)."""
    mod_root  = Path(mod_folder)
    game_root = Path(game_data_dir)
    results = []
    for mod_dat in sorted(mod_root.rglob("*.dat")):
        rel = mod_dat.relative_to(mod_root)
        orig = game_root / "PC" / rel
        rmod_rel = f"PC/{rel.as_posix()}"
        if not orig.exists():
            orig = game_root / rel
            rmod_rel = rel.as_posix()
            if not orig.exists():
                continue
        results.append((mod_dat, orig, rmod_rel))
    return results


# ── Full conversion runner ────────────────────────────────────────────────────

def run_conversion(mod_folder, game_data_dir, output_rmod,
                   name, mod_id, version, author, description,
                   log_fn, warn_fn) -> bool:
    pairs = scan_mod_folder(mod_folder, game_data_dir)
    if not pairs:
        warn_fn("No matching .dat files found between mod folder and game data.")
        return False

    all_patch_groups = []
    all_file_patches = []

    for mod_dat, orig_dat, rmod_dat_path in pairs:
        log_fn(f"\n── {rmod_dat_path} ──")
        patch_groups, file_group = convert_dat_pair(
            mod_dat, orig_dat, rmod_dat_path, log_fn, warn_fn)
        all_patch_groups.extend(patch_groups)
        if file_group:
            all_file_patches.append(file_group)

    total_ndf = sum(len(pg["changes"]) for pg in all_patch_groups)
    total_raw = sum(len(fg["files"])   for fg in all_file_patches)
    log_fn(f"\nTotal: {total_ndf} NDF change(s), {total_raw} raw file patch(es)")

    rmod_obj: dict = {
        "$schema": "ruse-mod/v1",
        "id":      mod_id,
        "name":    name,
        "version": version,
        "patches": all_patch_groups,
    }
    if author:
        rmod_obj["author"] = author
    if description:
        rmod_obj["description"] = description
    if all_file_patches:
        rmod_obj["file_patches"] = all_file_patches

    out = Path(output_rmod)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rmod_obj, f, indent=2, ensure_ascii=False)
    log_fn(f"Wrote: {output_rmod}")
    return True
