"""
.rmod file format definition and validation.

A .rmod file is a JSON document that describes one RUSE mod as a set of
surgical patches to NDF binary files inside .dat archives.  Instead of
distributing a full replacement .dat file, a .rmod only contains the changes —
this lets multiple incompatible mods coexist.

File extension: .rmod
Encoding: UTF-8 JSON

Schema (v1)
-----------

{
  "$schema": "ruse-mod/v1",
  "id":          "unique-kebab-case-id",       // required, no spaces
  "name":        "Display Name",               // required
  "version":     "1.0.0",                      // required
  "author":      "Author Name",                // optional
  "description": "What this mod does",         // optional
  "game_version": "1.4",                       // optional — target RUSE version
  "patches": [                                 // required, list of patch groups
    {
      "dat":  "PC/99/ZZ_GladPatchableWin.dat", // required — path relative to game Data/
      "ndf":  "genglad/patchable/clustergfx/everything.cpp.gladndfbin",  // required — path inside .dat
      "changes": [                             // required, list of changes
        {
          "action": "patch",                   // "patch" (default) | "create" | "delete"
          "table":  "TUniteAuSolDescriptor",   //   | "delete_props"
          "match":  {                          // match conditions (property → value)
            "ClassNameForDebug": "Unit_Stug_III_B"
          },
          "set": {                             // properties to change (patch/create)
            "SeuilMort": {
              "type":  "Float32",              // NDF type name (see ndfbin.T)
              "value": 600.0
            },
            "ProductionTime": {
              "type":  "Int32",
              "value": 8
            }
          },
          "props": ["PropA", "PropB"]          // properties to remove (delete_props only)
        },
        {
          "action": "patch",
          "table": "TTunableConstante",
          "match": {},
          "set": {
            "QteDeviseInitiale": {"type": "Int32", "value": 500}
          }
        }
      ]
    }
  ]
}

Supported actions
-----------------
  "patch"        — find matching instance(s), update their properties
  "delete"       — find matching instance(s), remove them from the table
  "delete_props" — find matching instance(s), remove specific named properties
                   (requires "props": ["PropName", ...] instead of "set")
  "create"       — add a new instance to the table (advanced; "set" defines initial props)

Patch group flags
-----------------
  "create_if_missing": true  — if the ndf file does not exist in the .dat, create it
                               from scratch before applying changes (useful for new datasets)

Supported type names (case-insensitive)
----------------------------------------
  Bool, Int8, Int16, UInt16, Int32, UInt32, Long, Float32, Float64,
  StringRef, PathRef, WideStr / WideString, Vector3, Color32, Color128,
  TripleInt, Int2, Float2

Match conditions
----------------
  Each key-value pair in "match" is a property name and its expected string
  representation.  All conditions must match (logical AND).
  Use "ClassNameForDebug" as the primary stable identifier.
  If "match" is omitted the change applies to ALL instances of the table.

Notes
-----
  - dat paths use forward or back slashes; normalised internally.
  - ndf paths inside the .dat also use forward or back slashes.
  - "value" for StringRef/PathRef should be the string content, NOT an index.
    The engine handles the string table insertion.
  - For Vector3, Color128, Int2, Float2 pass "value" as a JSON array, e.g. [1.0, 0.0, 0.0].
"""

import base64
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── Data classes ──────────────────────────────────────────────────────────────

@dataclass
class ModValueDef:
    """A single property value in a 'set' block."""
    type_name: str
    value: Any


@dataclass
class ModChange:
    """One change entry inside a patch group."""
    action: str                          # "patch" | "create" | "delete" | "delete_props"
    table: str                           # NDF class name
    match: Dict[str, str]                # property→value match conditions
    set_props: Dict[str, ModValueDef]    # property→value for patch/create
    del_props: List[str] = field(default_factory=list)  # property names for delete_props
    local_id: Optional[str] = None       # create only: label for $ref resolution


@dataclass
class ModPatchGroup:
    """Targets one ndfbin file inside one .dat archive."""
    dat: str                   # relative to game Data/  e.g. "PC/99/ZZ_GladPatchableWin.dat"
    ndf: str                   # path inside .dat         e.g. "genglad/.../everything.cpp.gladndfbin"
    changes: List[ModChange]
    create_if_missing: bool = False  # create a blank NDF if the file is not in the .dat


@dataclass
class ModFilePatch:
    """Replaces an entire file inside a .dat archive with new binary content."""
    dat: str    # relative to game Data/
    path: str   # path inside .dat (forward slashes)
    data: bytes # replacement file contents


@dataclass
class ModFileGroup:
    """Groups raw file replacements for one .dat archive."""
    dat: str                  # relative to game Data/
    files: List[ModFilePatch]


@dataclass
class RuseMod:
    """Parsed representation of a .rmod file."""
    schema: str
    id: str
    name: str
    version: str
    author: str
    description: str
    game_version: str
    patches: List[ModPatchGroup]
    file_patches: List[ModFileGroup] = field(default_factory=list)

    def summary(self) -> str:
        total_ndf = sum(len(p.changes) for p in self.patches)
        total_files = sum(len(g.files) for g in self.file_patches)
        parts = []
        if total_ndf:
            parts.append(f"{total_ndf} NDF change(s) across {len(self.patches)} ndf file(s)")
        if total_files:
            parts.append(f"{total_files} raw file replacement(s)")
        return (f"{self.name} v{self.version} by {self.author or 'unknown'} — "
                + (", ".join(parts) if parts else "0 changes"))


# ── Parser ────────────────────────────────────────────────────────────────────

class ModFormatError(ValueError):
    pass


def _require(obj: dict, key: str, context: str) -> Any:
    if key not in obj:
        raise ModFormatError(f"Missing required field '{key}' in {context}")
    return obj[key]


def _parse_value_def(raw: Any, prop_name: str) -> ModValueDef:
    if isinstance(raw, dict):
        # "$ref" shorthand: {"$ref": "local_id"}
        if "$ref" in raw:
            return ModValueDef(type_name="$ref", value=str(raw["$ref"]))
        type_name = _require(raw, "type", f"property '{prop_name}'")
        # "$ref" as type field: {"type": "$ref", "value": "local_id"}
        if str(type_name) == "$ref":
            value = _require(raw, "value", f"property '{prop_name}'")
            return ModValueDef(type_name="$ref", value=str(value))
        value = _require(raw, "value", f"property '{prop_name}'")
    else:
        # Shorthand: just a value — caller must supply type or we infer
        raise ModFormatError(
            f"Property '{prop_name}' must be an object with 'type' and 'value' keys. "
            f"Got: {raw!r}"
        )
    return ModValueDef(type_name=str(type_name), value=value)


def _parse_change(raw: dict, idx: int) -> ModChange:
    ctx = f"changes[{idx}]"
    action = raw.get("action", "patch").lower()
    valid_actions = ("patch", "create", "delete", "delete_props")
    if action not in valid_actions:
        raise ModFormatError(f"{ctx}: unknown action {action!r}. Expected {'/'.join(valid_actions)}")
    table = _require(raw, "table", ctx)
    match = raw.get("match", {})
    if not isinstance(match, dict):
        raise ModFormatError(f"{ctx}: 'match' must be a dict of {{property: value}}")
    set_raw = raw.get("set", {})
    if not isinstance(set_raw, dict):
        raise ModFormatError(f"{ctx}: 'set' must be a dict of {{property: {{type,value}}}}")
    set_props = {}
    for prop_name, val_raw in set_raw.items():
        set_props[prop_name] = _parse_value_def(val_raw, prop_name)
    del_props_raw = raw.get("props", [])
    if not isinstance(del_props_raw, list):
        raise ModFormatError(f"{ctx}: 'props' must be a list of property name strings")
    del_props = [str(p) for p in del_props_raw]
    if action == "delete_props" and not del_props:
        raise ModFormatError(f"{ctx}: 'delete_props' action requires a non-empty 'props' list")
    local_id = raw.get("local_id") or None
    match_str = {k: str(v) for k, v in match.items()}
    return ModChange(action=action, table=table, match=match_str,
                     set_props=set_props, del_props=del_props, local_id=local_id)


def _parse_patch_group(raw: dict, idx: int) -> ModPatchGroup:
    ctx = f"patches[{idx}]"
    dat = _require(raw, "dat", ctx).replace("\\", "/")
    ndf = _require(raw, "ndf", ctx).replace("\\", "/")
    changes_raw = _require(raw, "changes", ctx)
    if not isinstance(changes_raw, list):
        raise ModFormatError(f"{ctx}: 'changes' must be a list")
    changes = [_parse_change(c, i) for i, c in enumerate(changes_raw)]
    create_if_missing = bool(raw.get("create_if_missing", False))
    return ModPatchGroup(dat=dat, ndf=ndf, changes=changes,
                         create_if_missing=create_if_missing)


def _parse_file_group(raw: dict, idx: int) -> ModFileGroup:
    ctx = f"file_patches[{idx}]"
    dat = _require(raw, "dat", ctx).replace("\\", "/")
    files_raw = _require(raw, "files", ctx)
    if not isinstance(files_raw, list):
        raise ModFormatError(f"{ctx}: 'files' must be a list")
    files = []
    for j, f in enumerate(files_raw):
        fctx = f"{ctx}.files[{j}]"
        path = _require(f, "path", fctx).replace("\\", "/")
        data_b64 = _require(f, "data", fctx)
        try:
            data = base64.b64decode(data_b64)
        except Exception as e:
            raise ModFormatError(f"{fctx}: invalid base64 in 'data': {e}")
        files.append(ModFilePatch(dat=dat, path=path, data=data))
    return ModFileGroup(dat=dat, files=files)


def parse(data: str) -> RuseMod:
    """Parse a JSON string into a RuseMod object."""
    try:
        obj = json.loads(data)
    except json.JSONDecodeError as e:
        raise ModFormatError(f"Invalid JSON: {e}")

    if not isinstance(obj, dict):
        raise ModFormatError("Root must be a JSON object")

    schema = obj.get("$schema", "ruse-mod/v1")
    mod_id = _require(obj, "id", "root")
    if not re.match(r"^[a-zA-Z0-9_\-]+$", mod_id):
        raise ModFormatError(f"'id' must contain only letters, digits, hyphens, underscores. Got: {mod_id!r}")
    name = _require(obj, "name", "root")
    version = _require(obj, "version", "root")
    author = obj.get("author", "")
    description = obj.get("description", "")
    game_version = obj.get("game_version", "")
    patches_raw = obj.get("patches", [])
    if not isinstance(patches_raw, list):
        raise ModFormatError("'patches' must be a list")
    patches = [_parse_patch_group(p, i) for i, p in enumerate(patches_raw)]
    file_patches_raw = obj.get("file_patches", [])
    if not isinstance(file_patches_raw, list):
        raise ModFormatError("'file_patches' must be a list")
    file_patches = [_parse_file_group(g, i) for i, g in enumerate(file_patches_raw)]

    return RuseMod(
        schema=schema,
        id=mod_id,
        name=name,
        version=version,
        author=author,
        description=description,
        game_version=game_version,
        patches=patches,
        file_patches=file_patches,
    )


def load(path: str) -> RuseMod:
    """Load and parse a .rmod file from disk."""
    with open(path, "r", encoding="utf-8") as f:
        return parse(f.read())


def dump(mod: RuseMod) -> str:
    """Serialise a RuseMod back to a JSON string."""
    obj: Dict[str, Any] = {
        "$schema": mod.schema,
        "id": mod.id,
        "name": mod.name,
        "version": mod.version,
    }
    if mod.author:
        obj["author"] = mod.author
    if mod.description:
        obj["description"] = mod.description
    if mod.game_version:
        obj["game_version"] = mod.game_version

    obj["patches"] = []
    for pg in mod.patches:
        pg_obj: Dict[str, Any] = {"dat": pg.dat, "ndf": pg.ndf}
        if pg.create_if_missing:
            pg_obj["create_if_missing"] = True
        pg_obj["changes"] = []
        for ch in pg.changes:
            ch_obj: Dict[str, Any] = {"action": ch.action, "table": ch.table}
            if ch.local_id:
                ch_obj["local_id"] = ch.local_id
            if ch.match:
                ch_obj["match"] = ch.match
            if ch.set_props:
                ch_obj["set"] = {}
                for pname, v in ch.set_props.items():
                    if v.type_name == "$ref":
                        ch_obj["set"][pname] = {"$ref": v.value}
                    else:
                        ch_obj["set"][pname] = {"type": v.type_name, "value": v.value}
            if ch.del_props:
                ch_obj["props"] = ch.del_props
            pg_obj["changes"].append(ch_obj)
        obj["patches"].append(pg_obj)

    if mod.file_patches:
        obj["file_patches"] = []
        for fg in mod.file_patches:
            fg_obj: Dict[str, Any] = {
                "dat": fg.dat,
                "files": [
                    {"path": fp.path, "data": base64.b64encode(fp.data).decode("ascii")}
                    for fp in fg.files
                ],
            }
            obj["file_patches"].append(fg_obj)

    return json.dumps(obj, indent=2, ensure_ascii=False)


def save(mod: RuseMod, path: str) -> None:
    """Write a RuseMod to disk as a .rmod file."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(dump(mod))


# ── Template helpers ──────────────────────────────────────────────────────────

TEMPLATE = """\
{
  "$schema": "ruse-mod/v1",
  "id": "my-mod",
  "name": "My Mod Name",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "Describe what this mod changes",
  "patches": [
    {
      "dat": "PC/99/ZZ_GladPatchableWin.dat",
      "ndf": "genglad/patchable/clustergfx/everything.cpp.gladndfbin",
      "changes": [
        {
          "action": "patch",
          "table": "TUniteAuSolDescriptor",
          "match": {
            "ClassNameForDebug": "Unit_Stug_III_B"
          },
          "set": {
            "SeuilMort":      { "type": "Float32", "value": 600.0 },
            "ProductionTime": { "type": "Int32",   "value": 8     }
          }
        }
      ]
    }
  ]
}
"""


# ── Known RUSE dat / ndf paths ────────────────────────────────────────────────

KNOWN_DAT_FILES = {
    "patchable": "PC/99/ZZ_GladPatchableWin.dat",
    "notpatchable": "PC/99/ZZ_GladNotPatchableWin.dat",
    "mapdata_1360": "PC/1360/DataMap_Win.dat",
    "common_1360": "PC/1360/Data_Common.dat",
    "ia_1360": "PC/1360/IA_Common.dat",
    "zz_1360": "PC/1360/ZZ_Win.dat",
}

KNOWN_NDF_FILES = {
    # Primary unit/weapon/building/AI database inside PC/99/ZZ_GladPatchableWin.dat
    "everything":            "genglad/patchable/clustergfx/everything.cpp.gladndfbin",
    # Game-wide scalar constants (TTunableConstante — economy, timings, AI, colours)
    "constants_original":    "genglad/patchable/clustergfx/everythinggdconstanteoriginal.cpp.gladndfbin",
    "constants_atomic":      "genglad/patchable/clustergfx/everythinggdconstanteatomic.cpp.gladndfbin",
    # Visibility range table (TVisibilityRange × 50)
    "constants_visibility":  "genglad/patchable/clustergfx/everythinggdconstantevisibility.cpp.gladndfbin",
    # globals.cpp.gladndfbin / mapinfo.cpp.gladndfbin are at the leaf of a very
    # deep chain inside the dat.  Use inspect_dat.py to find the full internal path.
}

COMMON_TABLES = [
    "TUniteAuSolDescriptor",       # ground units          — everything.cpp.gladndfbin
    "TAvionDescriptor",            # aircraft              — everything.cpp.gladndfbin
    "TBatimentDescriptor",         # buildings             — everything.cpp.gladndfbin
    "TAmmunition",                 # ammunition/weapons    — everything.cpp.gladndfbin
    "TWeaponDescriptor",           # weapon configurations — everything.cpp.gladndfbin
    "TIAProfil",                   # AI profiles           — everything.cpp.gladndfbin
    "TTunableConstante",           # game-wide constants   — everythinggdconstanteoriginal.cpp.gladndfbin
    "TVisibilityRange",            # vision ranges         — everythinggdconstantevisibility.cpp.gladndfbin
    "TMultiMapInfo",               # multiplayer map list  — globals.cpp.gladndfbin (deep chain)
    "TChapterMapInfo",             # campaign chapters     — globals.cpp.gladndfbin (deep chain)
    "TMapLoadInfo",                # map load info         — mapinfo.cpp.gladndfbin (deep chain)
]
