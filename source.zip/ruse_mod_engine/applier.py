"""
Mod applier — applies one or more .rmod patches to the RUSE game data.

Usage (Python API)
------------------
    from ruse_mod_engine.applier import apply_mod, apply_mods

    # Apply a single mod to game data
    apply_mod(
        mod_path="mods/my_mod.rmod",
        game_data_dir="C:/Steam/steamapps/common/R.U.S.E/Data",
    )

    # Apply multiple mods in order (later mods override earlier for the same property)
    apply_mods(
        mod_paths=["mods/balance.rmod", "mods/cheat.rmod"],
        game_data_dir="C:/Steam/steamapps/common/R.U.S.E/Data",
        backup=True,   # back up each .dat before modifying
    )

How it works
------------
For each .rmod file:
  1. For each patch group (dat + ndf target):
     a. Open the .dat archive.
     b. Extract the target .ndfbin bytes.
     c. Parse the NDF binary into an NdfBinary object.
     d. For each change entry:
        - "patch":  find matching instances, update their properties.
        - "delete": find matching instances, remove them.
        - "create": add a new instance with the given properties.
     e. Re-serialise the NdfBinary back to bytes.
     f. Replace the .ndfbin inside the .dat archive.
     g. Write the patched .dat back to disk.

Conflict handling
-----------------
When two mods patch the same property on the same instance, the last mod applied
wins.  The applier logs all changes so you can see what happened.

Error handling
--------------
If a match produces zero results the change is skipped with a warning.
If a match produces multiple results all of them are patched (useful for
applying the same change to every instance of a class).
"""

import logging
import os
import shutil
from pathlib import Path
from typing import List, Optional

from . import edata as edata_mod
from . import ndfbin as ndfbin_mod
from . import mod_format

log = logging.getLogger(__name__)


# ── Main entry points ─────────────────────────────────────────────────────────

def apply_mod(
    mod_path: str,
    game_data_dir: str,
    *,
    backup: bool = True,
    dry_run: bool = False,
    output_dir: Optional[str] = None,
) -> "ApplyResult":
    """Apply a single .rmod file to the game data directory.

    If output_dir is set the patched .dat files are written there
    (mirroring the Data/ sub-path) and the originals are never touched.
    """
    mod = mod_format.load(mod_path)
    return _apply(mod, game_data_dir, backup=backup, dry_run=dry_run,
                  output_dir=output_dir)


def apply_mods(
    mod_paths: List[str],
    game_data_dir: str,
    *,
    backup: bool = True,
    dry_run: bool = False,
    output_dir: Optional[str] = None,
) -> List["ApplyResult"]:
    """Apply multiple .rmod files in order.

    Each mod's changes are layered on top of the previous mod's output so that
    mods lower in the list override earlier ones for the same properties.
    """
    if output_dir and not dry_run:
        clear_output_dats(mod_paths, output_dir)
    results = []
    for path in mod_paths:
        result = apply_mod(path, game_data_dir, backup=backup, dry_run=dry_run,
                           output_dir=output_dir)
        results.append(result)
    return results


def clear_output_dats(mod_paths: List[str], output_dir: str) -> None:
    """Delete any output .dat files touched by the given mods so a fresh apply run
    always starts from the original game data rather than stale prior output."""
    out_root = Path(output_dir)
    to_delete: set = set()
    for path in mod_paths:
        try:
            mod = mod_format.load(path)
            for pg in mod.patches:
                to_delete.add(pg.dat.replace("/", os.sep))
            for fg in mod.file_patches:
                to_delete.add(fg.dat.replace("/", os.sep))
        except Exception:
            pass
    for dat_rel in to_delete:
        p = out_root / dat_rel
        if p.exists():
            p.unlink()
            log.info("Cleared stale output: %s", p.name)


# ── Result object ─────────────────────────────────────────────────────────────

class ChangeRecord:
    """Before/after record for one property change."""
    __slots__ = ("table", "instance_id", "prop", "old_val", "new_val")

    def __init__(self, table: str, instance_id: str, prop: str,
                 old_val: str, new_val: str):
        self.table = table
        self.instance_id = instance_id
        self.prop = prop
        self.old_val = old_val
        self.new_val = new_val

    def __str__(self):
        return f"  {self.table}[{self.instance_id}].{self.prop}: {self.old_val!r} -> {self.new_val!r}"


class ApplyResult:
    def __init__(self, mod_name: str):
        self.mod_name = mod_name
        self.changes_applied: int = 0
        self.warnings: List[str] = []
        self.errors: List[str] = []
        self.change_log: List[ChangeRecord] = []

    def warn(self, msg: str):
        self.warnings.append(msg)
        log.warning("[%s] %s", self.mod_name, msg)

    def error(self, msg: str):
        self.errors.append(msg)
        log.error("[%s] %s", self.mod_name, msg)

    def ok(self):
        return len(self.errors) == 0

    def summary(self) -> str:
        status = "OK" if self.ok() else "ERRORS"
        return (f"[{status}] {self.mod_name}: {self.changes_applied} change(s) applied, "
                f"{len(self.warnings)} warning(s), {len(self.errors)} error(s)")

    def __repr__(self):
        return self.summary()


# ── Core application logic ────────────────────────────────────────────────────

def _apply(
    mod: mod_format.RuseMod,
    game_data_dir: str,
    backup: bool,
    dry_run: bool,
    output_dir: Optional[str] = None,
) -> ApplyResult:
    result = ApplyResult(mod.name)
    data_root = Path(game_data_dir)
    out_root = Path(output_dir) if output_dir else None
    # Tracks which .dat files have already been copied to output this run.
    # Only the first patch_group for a given .dat copies from source; subsequent
    # groups for the same .dat work on the already-patched copy so their changes
    # are not overwritten.
    copied_dats: set = set()

    for patch_group in mod.patches:
        dat_rel = patch_group.dat.replace("/", os.sep)
        src_dat_path = data_root / dat_rel

        if not src_dat_path.exists():
            result.error(f"DAT file not found: {src_dat_path}")
            continue

        # Determine which path to actually open/write
        if out_root is not None:
            work_dat_path = out_root / dat_rel
            work_dat_path.parent.mkdir(parents=True, exist_ok=True)
            if dat_rel not in copied_dats:
                if not work_dat_path.exists():
                    # File not yet in output — copy fresh from source.
                    # If it already exists, a previous mod in the chain already wrote it; use that.
                    log.info("Copying %s -> %s", src_dat_path.name, work_dat_path)
                    shutil.copy2(str(src_dat_path), str(work_dat_path))
                copied_dats.add(dat_rel)
        else:
            work_dat_path = src_dat_path
            if not dry_run and backup:
                _make_backup(work_dat_path)

        log.info("Opening %s", work_dat_path)

        try:
            edat = edata_mod.open_dat(str(work_dat_path))
        except Exception as e:
            result.error(f"Failed to open {work_dat_path}: {e}")
            continue

        ndf_path_in_dat = patch_group.ndf
        ndf_bytes = edat.get(ndf_path_in_dat)
        if ndf_bytes is None:
            ndf_bytes = edat.get(ndf_path_in_dat.replace("/", "\\"))

        is_new_file = (ndf_bytes is None)
        if is_new_file:
            if not patch_group.create_if_missing:
                result.error(
                    f"NDF file {ndf_path_in_dat!r} not found in {work_dat_path.name}. "
                    f"Available: {edat.list()[:10]}"
                )
                continue
            log.info("create_if_missing: starting with blank NDF for %s", ndf_path_in_dat)
            ndf = ndfbin_mod.NdfBinary()
        else:
            log.info("Parsing NDF: %s", ndf_path_in_dat)
            try:
                ndf = ndfbin_mod.read(ndf_bytes)
            except Exception as e:
                result.error(f"Failed to parse NDF {ndf_path_in_dat!r}: {e}")
                continue

        # local_id → (inst_idx, class_idx): populated by create actions for $ref resolution
        create_map: dict = {}

        changed = False
        for change in patch_group.changes:
            n = _apply_change(change, ndf, result, create_map)
            if n > 0:
                changed = True
                result.changes_applied += n

        if changed and not dry_run:
            log.info("Re-serialising NDF and repacking DAT…")
            try:
                compress = (not is_new_file) and ndf.is_compressed
                new_ndf_bytes = ndfbin_mod.write(ndf, compress=compress)
                if is_new_file:
                    edat.add(ndf_path_in_dat, new_ndf_bytes)
                else:
                    edat.replace(ndf_path_in_dat, new_ndf_bytes)
                log.info("Wrote %s", work_dat_path.name)
            except Exception as e:
                result.error(f"Failed to write patched NDF: {e}")

    # ── Raw file replacements ─────────────────────────────────────────────────
    for file_group in mod.file_patches:
        dat_rel = file_group.dat.replace("/", os.sep)
        src_dat_path = data_root / dat_rel

        if not src_dat_path.exists():
            result.error(f"DAT file not found (file_patches): {src_dat_path}")
            continue

        if out_root is not None:
            work_dat_path = out_root / dat_rel
            work_dat_path.parent.mkdir(parents=True, exist_ok=True)
            if dat_rel not in copied_dats:
                if not work_dat_path.exists():
                    log.info("Copying %s -> %s", src_dat_path.name, work_dat_path)
                    shutil.copy2(str(src_dat_path), str(work_dat_path))
                copied_dats.add(dat_rel)
        else:
            work_dat_path = src_dat_path
            if not dry_run and backup:
                _make_backup(work_dat_path)

        try:
            edat = edata_mod.open_dat(str(work_dat_path))
        except Exception as e:
            result.error(f"Failed to open {work_dat_path} for file_patches: {e}")
            continue

        for fp in file_group.files:
            if dry_run:
                result.changes_applied += 1
                continue
            try:
                path_bs = fp.path.replace("/", "\\")
                if edat.get(path_bs) is None and edat.get(fp.path) is None:
                    result.warn(f"file_patch: path {fp.path!r} not found in {work_dat_path.name} — skipped")
                    continue
                edat.replace(path_bs, fp.data)
                log.info("file_patch: replaced %s in %s", fp.path, work_dat_path.name)
                result.changes_applied += 1
            except Exception as e:
                result.error(f"file_patch: failed to replace {fp.path!r}: {e}")

    return result


def _apply_change(
    change: mod_format.ModChange,
    ndf: ndfbin_mod.NdfBinary,
    result: ApplyResult,
    create_map: dict,
) -> int:
    """Apply one ModChange.  Returns number of instances affected."""

    if change.action == "patch":
        return _action_patch(change, ndf, result, create_map)
    if change.action == "delete":
        return _action_delete(change, ndf, result)
    if change.action == "delete_props":
        return _action_delete_props(change, ndf, result)
    if change.action == "create":
        return _action_create(change, ndf, result, create_map)

    result.warn(f"Unknown action '{change.action}' for table '{change.table}'")
    return 0


def _action_patch(
    change: mod_format.ModChange,
    ndf: ndfbin_mod.NdfBinary,
    result: ApplyResult,
    create_map: dict,
) -> int:
    matches = ndf.find_instances(change.table, change.match or None)
    if not matches:
        result.warn(
            f"patch: no instances of '{change.table}' matched "
            f"{change.match} — skipped"
        )
        return 0

    affected = 0
    for inst_idx, inst in matches:
        # Determine a human-readable id for this instance (ClassNameForDebug preferred)
        instance_id = _instance_label(inst, ndf, inst_idx)

        for prop_name, val_def in change.set_props.items():
            try:
                ndf_val = _make_ndf_value(val_def, prop_name, ndf, create_map)
            except Exception as e:
                result.warn(f"patch: cannot create value for '{prop_name}': {e}")
                continue

            # Capture old value before overwriting
            old_val_str = _read_prop_str(inst, prop_name, ndf)

            ok = ndf.set_property(inst, prop_name, ndf_val)
            if not ok:
                result.warn(
                    f"patch: property '{prop_name}' not found in class '{change.table}' "
                    f"(instance #{inst_idx})"
                )
            else:
                new_val_str = str(ndf.resolve_value(ndf_val))
                rec = ChangeRecord(change.table, instance_id, prop_name,
                                   old_val_str, new_val_str)
                result.change_log.append(rec)
                log.info("%s", rec)
        affected += 1

    return affected


def _instance_label(inst, ndf: ndfbin_mod.NdfBinary, idx: int) -> str:
    """Return ClassNameForDebug string or AmmunitionId or fallback to index."""
    for candidate in ("ClassNameForDebug", "AmmunitionId", "_ShortDatabaseName"):
        # Must look up by class to get the correct property index for this class
        prop = ndf.prop_by_name_and_class(candidate, inst.class_index)
        if prop is None:
            continue
        val = inst.get(prop.index)
        if val is not None:
            return str(ndf.resolve_value(val))
    return f"#{idx}"


def _read_prop_str(inst, prop_name: str, ndf: ndfbin_mod.NdfBinary) -> str:
    """Return the current string representation of a property, or '?' if absent."""
    prop = ndf.prop_by_name_and_class(prop_name, inst.class_index)
    if prop is None:
        prop = ndf.prop_by_name(prop_name)
    if prop is None:
        return "?"
    val = inst.get(prop.index)
    if val is None:
        return "?"
    return str(ndf.resolve_value(val))


def _action_delete(
    change: mod_format.ModChange,
    ndf: ndfbin_mod.NdfBinary,
    result: ApplyResult,
) -> int:
    matches = ndf.find_instances(change.table, change.match or None)
    if not matches:
        result.warn(
            f"delete: no instances of '{change.table}' matched "
            f"{change.match} — skipped"
        )
        return 0

    indices_to_remove = sorted([idx for idx, _ in matches], reverse=True)
    for idx in indices_to_remove:
        del ndf.instances[idx]
    log.info("delete: removed %d instance(s) of '%s'", len(indices_to_remove), change.table)
    return len(indices_to_remove)


def _action_delete_props(
    change: mod_format.ModChange,
    ndf: ndfbin_mod.NdfBinary,
    result: ApplyResult,
) -> int:
    matches = ndf.find_instances(change.table, change.match or None)
    if not matches:
        result.warn(
            f"delete_props: no instances of '{change.table}' matched "
            f"{change.match} — skipped"
        )
        return 0

    affected = 0
    for inst_idx, inst in matches:
        for prop_name in change.del_props:
            prop = ndf.prop_by_name_and_class(prop_name, inst.class_index)
            if prop is None:
                prop = ndf.prop_by_name(prop_name)
            if prop is None:
                result.warn(
                    f"delete_props: property '{prop_name}' not found in NDF — skipped"
                )
                continue
            removed = inst.remove(prop.index)
            if not removed:
                result.warn(
                    f"delete_props: property '{prop_name}' not present on instance "
                    f"#{inst_idx} — skipped"
                )
            else:
                log.info("delete_props: removed '%s' from %s[%d]",
                         prop_name, change.table, inst_idx)
        affected += 1

    return affected


def _action_create(
    change: mod_format.ModChange,
    ndf: ndfbin_mod.NdfBinary,
    result: ApplyResult,
    create_map: dict,
) -> int:
    cls = ndf.class_by_name(change.table)
    if cls is None:
        result.warn(f"create: class '{change.table}' not found in NDF — skipped")
        return 0

    inst = ndfbin_mod.NdfInstance(class_index=cls.index)
    for prop_name, val_def in change.set_props.items():
        try:
            ndf_val = _make_ndf_value(val_def, prop_name, ndf, create_map)
        except Exception as e:
            result.warn(f"create: cannot create value for '{prop_name}': {e}")
            continue
        ok = ndf.set_property(inst, prop_name, ndf_val)
        if not ok:
            result.warn(f"create: property '{prop_name}' not found in class '{change.table}'")

    inst_idx = len(ndf.instances)
    ndf.instances.append(inst)

    if change.local_id:
        create_map[change.local_id] = (inst_idx, cls.index)
        log.info("create: added new instance to '%s' as '%s' (idx=%d)",
                 change.table, change.local_id, inst_idx)
    else:
        log.info("create: added new instance to '%s' (idx=%d)", change.table, inst_idx)
    return 1


# ── Value construction ────────────────────────────────────────────────────────

def _make_ndf_value(
    val_def: mod_format.ModValueDef,
    prop_name: str,
    ndf: ndfbin_mod.NdfBinary,
    create_map: dict = None,
) -> ndfbin_mod.NdfValue:
    """Convert a ModValueDef into an NdfValue, resolving string refs and $refs."""
    # Resolve symbolic reference to a created instance
    if val_def.type_name == "$ref":
        if create_map is None or val_def.value not in create_map:
            raise ValueError(
                f"$ref '{val_def.value}' not found in create_map "
                f"(create must appear before the patch that references it)"
            )
        inst_idx, cls_idx = create_map[val_def.value]
        return ndfbin_mod.NdfValue(
            ndfbin_mod.T.Reference,
            (ndfbin_mod.OBJ_REF_MARKER, (inst_idx, cls_idx))
        )

    # For List types, elements in the raw list may themselves be $ref dicts or ObjRef dicts
    key = val_def.type_name.lower().strip()
    if key.startswith("list<") and key.endswith(">") and isinstance(val_def.value, list):
        elem_type = key[5:-1].strip()
        items = []
        for elem in val_def.value:
            if isinstance(elem, dict) and "$ref" in elem:
                elem_def = mod_format.ModValueDef(type_name="$ref", value=str(elem["$ref"]))
            elif isinstance(elem, dict) and "type" in elem:
                elem_type_here = elem["type"]
                elem_val = elem.get("value", elem)
                if elem_type_here == "$ref":
                    elem_def = mod_format.ModValueDef(type_name="$ref", value=str(elem_val))
                else:
                    elem_def = mod_format.ModValueDef(type_name=elem_type_here, value=elem_val)
            else:
                # Infer Reference subtype from dict keys so mixed ObjRef/TransRef lists work
                if isinstance(elem, dict) and "trans" in elem and "inst" not in elem:
                    actual_elem_type = "TransRef"
                elif isinstance(elem, dict) and "inst" in elem and "class" in elem:
                    actual_elem_type = "ObjRef"
                else:
                    actual_elem_type = elem_type
                elem_def = mod_format.ModValueDef(type_name=actual_elem_type, value=elem)
            items.append(_make_ndf_value(elem_def, prop_name, ndf, create_map))
        return ndfbin_mod.NdfValue(ndfbin_mod.T.List, items)

    ndf_val = ndfbin_mod.make_value(val_def.type_name, val_def.value)
    _resolve_string_refs(ndf_val, ndf)
    return ndf_val


def _resolve_string_refs(
    ndf_val: ndfbin_mod.NdfValue,
    ndf: ndfbin_mod.NdfBinary,
) -> None:
    """Recursively convert any StringRef/PathRef raw strings to STRG table indices.

    make_value() leaves StringRef/PathRef raws as Python strings so the caller can
    resolve them against the live NDF string table.  This function walks the value
    tree (including List and Map containers) and performs that resolution in-place.
    """
    t = ndf_val.type_id
    if t in (ndfbin_mod.T.StringRef, ndfbin_mod.T.PathRef):
        if isinstance(ndf_val.raw, str):
            ndf_val.raw = ndf.ensure_string(ndf_val.raw)
    elif t == ndfbin_mod.T.List:
        for item in ndf_val.raw:
            _resolve_string_refs(item, ndf)
    elif t == ndfbin_mod.T.Map:
        for k, v in ndf_val.raw:
            _resolve_string_refs(k, ndf)
            _resolve_string_refs(v, ndf)
    elif t == ndfbin_mod.T.Pair:
        k, v = ndf_val.raw
        _resolve_string_refs(k, ndf)
        _resolve_string_refs(v, ndf)


# ── Backup helpers ────────────────────────────────────────────────────────────

def _make_backup(dat_path: Path) -> None:
    backup_path = dat_path.with_suffix(".dat.bak")
    if not backup_path.exists():
        shutil.copy2(str(dat_path), str(backup_path))
        log.info("Backup: %s → %s", dat_path.name, backup_path.name)
    else:
        log.debug("Backup already exists: %s", backup_path.name)


def restore_backup(dat_path: str) -> bool:
    """Restore a .dat from its .bak backup if one exists.  Returns True on success."""
    p = Path(dat_path)
    backup = p.with_suffix(".dat.bak")
    if not backup.exists():
        log.warning("No backup found for %s", p.name)
        return False
    shutil.copy2(str(backup), str(p))
    log.info("Restored: %s from backup", p.name)
    return True


# ── Conflict detection ────────────────────────────────────────────────────────

def check_conflicts(
    mod_paths: List[str],
    game_data_dir: str,
) -> List[str]:
    """
    Dry-run all mods and return a list of conflict descriptions where two mods
    patch the same property on the same instance.

    Returns a list of human-readable conflict strings (empty = no conflicts).
    """
    # Map (dat, ndf, table, match_key, prop_name) → list of mod names
    patches: dict = {}
    conflicts: List[str] = []

    for mod_path in mod_paths:
        mod = mod_format.load(mod_path)
        for pg in mod.patches:
            for ch in pg.changes:
                if ch.action != "patch":
                    continue
                match_key = ";".join(f"{k}={v}" for k, v in sorted(ch.match.items()))
                for prop_name in ch.set_props:
                    key = (pg.dat, pg.ndf, ch.table, match_key, prop_name)
                    if key not in patches:
                        patches[key] = []
                    patches[key].append(mod.name)

    for key, mod_names in patches.items():
        if len(mod_names) > 1:
            dat, ndf, table, match_key, prop_name = key
            conflicts.append(
                f"Conflict on {table}.{prop_name} [{match_key}] in {ndf}: "
                f"{' vs '.join(mod_names)}"
            )

    return conflicts
