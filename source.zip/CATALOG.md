# RUSE Mod Engine — Data Catalog

Everything the engine can change, where it lives, and what type each property is.
All data verified directly from `Data\PC\99\ZZ_GladPatchableWin.dat`.

---

## 1. File Structure

RUSE loads `.dat` archives from `Data\PC\` in resolution priority order.
**The only files that matter for mods are in `Data\PC\99\`** — the other directories (`60`, `64`, `1360`) either defer to `99` or contain resources unrelated to unit data.

| File (relative to `Data\`) | What it contains | Mod target? |
|---|---|:---:|
| `PC\99\ZZ_GladPatchableWin.dat` | Units, weapons, buildings, AI, economy constants, map menus, visibility | **YES — primary** |
| `PC\99\ZZ_GladNotPatchableWin.dat` | 3D models, shaders, terrain geometry | No |
| `PC\1360\DataMap_Win.dat` | Map scenario files, sector coordinates, camera paths | Advanced |
| `PC\1360\IA_Common.dat` | Python mission scripts for most campaign/challenge maps | Advanced |
| `PC\64\99\IA_Common.dat` | Python mission scripts for a few specific maps | Advanced |
| `PC\64\99\ZZ_Win.dat` | Localization text, Flash UI, most in-game graphics | No |
| `PC\DLC\ZZ_Win_DLC3.dat` | Japan faction meshes, sounds, localization | No |
| `PC\60\*`, `PC\64\*`, `PC\1360\ZZ_GladPatchableWin.dat` | Duplicates / older resolution variants — defer to `PC\99` | No |

---

## 2. NDF Files Inside `PC\99\ZZ_GladPatchableWin.dat`

Use `inspect_dat.py` to browse all 576 entries. Key modding targets:

| Internal path (use forward slashes in `.rmod`) | Contents | Instances |
|---|---|---|
| `genglad/patchable/clustergfx/everything.cpp.gladndfbin` | **All units, weapons, buildings, AI** | 63,704 (389 classes) |
| `genglad/patchable/clustergfx/everythinggdconstanteoriginal.cpp.gladndfbin` | Game-wide scalar constants | 1 (`TTunableConstante`) |
| `genglad/patchable/clustergfx/everythinggdconstanteatomic.cpp.gladndfbin` | Atomic game constants | 1 (`TTunableConstante`) |
| `genglad/patchable/clustergfx/everythinggdconstantevisibility.cpp.gladndfbin` | Vision range table | 53 |
| `genglad/patchable/.../.../globals.cpp.gladndfbin` | Multiplayer/campaign map menu entries | ~145 |
| `genglad/patchable/.../.../mapinfo.cpp.gladndfbin` | Scenario → GUID map load info | ~40 |

> **Note:** `globals.cpp.gladndfbin` and `mapinfo.cpp.gladndfbin` are at the leaf of a very long nested chain inside the dat. Run `python tools/inspect_dat.py <dat> --search globals` to find the exact internal path. Do not hard-code the full path — use the shorthand keys in `KNOWN_NDF_FILES` once those are wired up.

---

## 3. `TUniteAuSolDescriptor` — Ground Units

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everything.cpp.gladndfbin`  
**Match key:** `ClassNameForDebug` (StringRef)  
**Instance count:** 204

### Properties

| Property | NDF Type | Example value | Notes |
|---|---|---|---|
| `DescriptorId` | UInt32 | 1013 | Internal ID — do not change |
| `ClassNameForDebug` | StringRef | `"Unit_Stug_III_B"` | **Use this as the match key** |
| `SeuilMort` | Float32 | 400.0 | HP / hit-point threshold before destruction |
| `SeuilPinned` | Float32 | 200.0 | HP threshold at which unit becomes pinned |
| `VitesseLineaire` | Float32 | 4030.0 | Max road speed (game units; divide by 52 ≈ km/h) |
| `VitesseCombat` | Float32 | 6500.0 | Max off-road speed (game units; divide by 52 ≈ km/h) |
| `MaxAcceleration` | Float32 | 5200.0 | Acceleration rate |
| `MaxDeceleration` | Float32 | 10400.0 | Deceleration rate |
| `TempsDemiTour` | Float32 | 0.40 | Half-turn time in seconds |
| `SpeedBonusOnRoad` | Float32 | 0.61 | Road speed multiplier |
| `DetectionBase` | Float32 | 26.0 | Base detection range (game units) |
| `PorteeVisionVolant` | Float32 | 2600.0 | Air vision range (game units) |
| `ProductionTime` | Int32 | 10 | Production time in seconds |
| `ProductionPrice` | List\<Int32\> | `[50, 50, 50, 50, 50]` | Cost per game mode — **List type, 5 values; cannot be patched with simple Int32** |
| `Factory` | Int32 | 8 | Factory type that produces this unit |
| `Category` | Int32 | 2 | Unit category (affects AI behavior) |
| `CategorieIA` | Int32 | 4 | AI category |
| `Nationalite` | Int32 | — | Nation ID |
| `SignatureRadar` | Int32 | — | Radar visibility level |
| `Radius` | Float32 | 520.0 | Collision/display radius |
| `Scale` | Float32 | 1.0 | 3D model scale |
| `StickToGround` | Bool | True | True = ground unit; False = airborne |
| `ShowInMenu` | List\<Bool\> | list[5] | Visibility per game mode |
| `InitialFlagSet` | List | list[11] | Faction/ability flags — advanced |
| `ArmorDescriptor` | Reference | — | Points to TArmureDescriptor instance |
| `WeaponDescriptor` | Reference | — | Points to TWeaponDescriptor instance |
| `GfxDescriptor` | Reference | — | 3D graphics descriptor |
| `IconeType` | Int32 | 1 | Map icon type |
| `PositionInMenu` | Int32 | 1 | Position in unit selection menu |
| `NameInMenuToken` | LocHash | — | Localization hash for unit name |

### All 204 `ClassNameForDebug` values

<details>
<summary>Click to expand full unit list</summary>

```
Unit_140mm_5_5_Inch_BL_Mk_III_L_30    Unit_150mm_sFH_18_L_30
Unit_152mm_howitzer                    Unit_155mm_GPF
Unit_155mm_M1_Long_Tom_L_45           Unit_203mm_howitzer
Unit_203mm_howitzer_atomique           Unit_20mm_Breda
Unit_20mm_FlaK_30_L_112               Unit_210mm_Morser
Unit_210mm_Obice_da_M1935_L_23_8      Unit_25mm_CA_mle_1938
Unit_37mm_AA                          Unit_40mm_M1_Bofors_L_60
Unit_40mm_M1_Bofors_L_60_UK           Unit_45mm_L46
Unit_47mm_AT                          Unit_75mm_Canonne_da_75_27
Unit_75mm_Type35                       Unit_75mm_Type88
Unit_75mm_le_FK_38_L_34               Unit_75mm_mle_1897
Unit_76mm_ZIS_3                        Unit_87mm_QF_25_pounder
Unit_88mm_FlaK_36L_56                  Unit_88mm_Flak
Unit_ARL_40                            Unit_ARL_40_atomique
Unit_ARL_44                            Unit_AVRE_atomique
Unit_Archer                            Unit_Autoblinda_40
Unit_Autoblinda_43                     Unit_B1_Bis
Unit_BA_11                             Unit_Battleship
Unit_Breda_Dovunque_90_53             Unit_Breda_Dovunque_atomique
Unit_Bunker_enterre_JAP               Unit_Cannone_da_47_32_M35
Unit_Canon_atomique_FR                 Unit_Canon_atomique_GER
Unit_Canon_atomique_ITA                Unit_Canon_atomique_JAP
Unit_Canon_atomique_UK                 Unit_Canon_atomique_URSS
Unit_Canon_atomique_US                 Unit_Carro_Armato_M11_39
Unit_Carro_Armato_M13_40              Unit_Carro_Armato_M15_42
Unit_Carro_Armato_P_26_40             Unit_Carro_Veloce
Unit_Char_DCA_M4_SKINK                Unit_Churchill_A22
Unit_Churchill_AVRE                    Unit_Churchill_atomique
Unit_Coventry_armoured_car            Unit_Cruiser_A13
Unit_Cruiser_A27_Cromwell             Unit_Daimler_AC_MK_1
Unit_Destroyer                         Unit_EBR_atomique
Unit_FCM_F1                            Unit_FCM_F1_atomique
Unit_GER_37mm_Pak36                   Unit_Heavy_Cruiser
Unit_Hotchkiss_H_39                   Unit_IS2
Unit_IS3                               Unit_IS3_atomique
Unit_Jagdpanther                       Unit_KV1
Unit_Katyusha                          Unit_Katyusha_atomique
Unit_KingTigerAS                       Unit_Kubelwagen
Unit_Kurogane                          Unit_L6_40_Lanciafiamme
Unit_LCVP                              Unit_LST
Unit_Laffly_W15_TCC                   Unit_Lanciafiamme_atomique
Unit_Long_Tom_atomique                Unit_Long_Tom_nuke
Unit_Lorraine_37_L                    Unit_M10_Wolverine
Unit_M15_AA_Tank_atomique             Unit_M16_GMC
Unit_M19_GMC_Twin_40mm               Unit_M1_57mm_L_50
Unit_M1_57mm_L_50_SOLO               Unit_M24_Chaffee
Unit_M26_Pershing                     Unit_M36_Jackson
Unit_M3A1_Stuart                      Unit_M3_Lee
Unit_M3_Lee_cinematique               Unit_M40_GMC
Unit_M4_Sherman                       Unit_M5_76mm_L_50
Unit_M7_Priest                        Unit_M8_Greyhound
Unit_M_15_AA_Tank                     Unit_Marder_II
Unit_Matilda                           Unit_Maus
Unit_Maus_atomique                    Unit_Morser_atomique
Unit_OI_Heavy_Tank                    Unit_OI_Heavy_Tank_atomique
Unit_P26_atomique                     Unit_PZIV_Wirbelwind
Unit_PaK_40_75mm_L_48                Unit_Panhard_178
Unit_Panhard_EBR_75                   Unit_Panzer_III_J
Unit_Panzer_IV_G                      Unit_Panzer_IV_cinematique
Unit_Panzer_VI_B_Tigre_II            Unit_Panzer_VI_Tigre
Unit_Panzer_V_G_Panther              Unit_Position_105mm_JAP
Unit_Position_DCA_JAP                Unit_Puma_atomique
Unit_QF_17_pounder_76mm              Unit_QF_2_pounder_40_mm
Unit_SA_25mm_L_1934                  Unit_SA_47mm_1937
Unit_SU_100                           Unit_SU_122
Unit_SU_85                            Unit_Sau_40
Unit_SdKfz_234_2_Puma                Unit_SdkFz_222
Unit_Sdkfz251                         Unit_Sdkfz251_atomique
Unit_Semovente_M_40_75_18            Unit_Semovente_M_43_105_25
Unit_Semovente_M_90_53               Unit_Sexton
Unit_Sherman_Calliope                 Unit_Sherman_Calliope_atomique
Unit_Sherman_Firefly                  Unit_Sherman_lance_flammes
Unit_Sherman_lance_flammes_atomique  Unit_Skink_atomique
Unit_Somua_S_35                       Unit_Stug_III_B
Unit_SturmTiger                       Unit_Super_Pershing
Unit_Super_Pershing_DEMO             Unit_T26
Unit_T28                              Unit_T28_atomique
Unit_T34                              Unit_TaSe_20mm
Unit_Tourelle_AT_ITA                 Unit_Tourelle_AT_UK
Unit_Tourelle_AT_US                  Unit_Tourelle_ArtillerieHeavy_URSS
Unit_Tourelle_ArtillerieLight_URSS   Unit_Tourelle_Artillerie_UK
Unit_Tourelle_DCA_US                 Unit_Tourelle_Light_FR
Unit_Tourelle_MG_GER                 Unit_Tourelle_MG_US
Unit_Tourelle_Maginot_FR             Unit_Tourelle_Outpost_UK
Unit_Tourelle_Siegfried_GER          Unit_TransportCanon
Unit_TransportCanon_FR               Unit_TransportCanon_GER
Unit_TransportCanon_ITA              Unit_TransportCanon_JAP
Unit_TransportCanon_UK               Unit_TransportCanon_URSS
Unit_TransportHQ                     Unit_TransportSoldier
Unit_TransportSoldier_FR             Unit_TransportSoldier_GER
Unit_TransportSoldier_ITA            Unit_TransportSoldier_JAP
Unit_TransportSoldier_UK             Unit_TransportSoldier_URSS
Unit_Type1_AOV                       Unit_Type1_AOV_atomique
Unit_Type2_75mm_KuSe                 Unit_Type2_HoRi
Unit_Type3_ChiNu                     Unit_Type4_HaTo
Unit_Type4_HaTo_atomique             Unit_Type5_47mm_HoRu
Unit_Type5_ChiRi                     Unit_Type95_HaGo
Unit_Type97_ChiHa                    Unit_Unite_Vide_B
Unit_Unite_Vide_L                    Unit_V2_launcher
Unit_V2_nuclear_launcher             Unit_Vickers
Unit_Willis_MB                       Unit_Wirbelwind_atomique
Unit_Wurfrahmen_PV                   Unit_ZSU_37
```
</details>

---

## 4. `TAvionDescriptor` — Aircraft

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everything.cpp.gladndfbin`  
**Match key:** `ClassNameForDebug` (StringRef)  
**Instance count:** 63

### Properties

| Property | NDF Type | Example value | Notes |
|---|---|---|---|
| `ClassNameForDebug` | StringRef | `"Avion_ME109_GR"` | **Match key** |
| `SeuilMort` | Float32 | 200.0 | HP before destruction |
| `SeuilPinned` | Float32 | 201.0 | Pinned threshold (usually > SeuilMort = effectively never pinned) |
| `VitesseLineaire` | Float32 | 15600.0 | Air speed (game units; ÷ 52 ≈ km/h) |
| `VitesseLineaireAuSol` | Float32 | 13000.0 | Ground taxi speed |
| `ProductionTime` | Int32 | 5 | Production time in seconds |
| `ProductionPrice` | List\<Int32\> | list[5] | Cost per game mode — **List type** |
| `UpgradePrice` | Int32 | 50 | Upgrade cost |
| `UpgradeTime` | Int32 | 50 | Upgrade time |
| `MaxAcceleration` | Float32 | 3900.0 | |
| `MaxDeceleration` | Float32 | 2600.0 | |
| `TempsDemiTour` | Float32 | 1.0 | Turn time in seconds |
| `PorteeVisionVolant` | Float32 | 208000.0 | Air vision range |
| `PorteeAttackReflexAir` | Float32 | 156000.0 | Auto-engage range vs air |
| `PorteeAttackReflexSol` | Float32 | 182000.0 | Auto-engage range vs ground |
| `DetectionBase` | Float32 | — | Base detection range |
| `SignatureRadar` | Int32 | 3 | Radar visibility level |
| `CategoryVolant` | Int32 | 4 | Flight category |
| `Factory` | Int32 | 9 | Factory type |

### All 63 `ClassNameForDebug` values

```
Avion_Ar234              Avion_Ar234_PV          Avion_B17_High_PV
Avion_B17_PV             Avion_B25               Avion_B25_PV
Avion_C47_Para           Avion_C47_Para_RU       Avion_C47_Para_URSS
Avion_Caproni_314_Para   Avion_Corsair_F4U       Avion_Corsair_F4U_PV
Avion_F6F_Hellcat        Avion_F6F_Hellcat_PV    Avion_Grasshopper
Avion_HE_111             Avion_HE_111_High_PV    Avion_HE_111_PV
Avion_Junkers_87         Avion_Junkers_87_GR     Avion_Junkers_87_PV
Avion_Junkers_87_Rudel   Avion_Ki_61             Avion_Ki_61_PV
Avion_Ki_84              Avion_Ki_84_PV          Avion_ME109_GR
Avion_ME109_PV           Avion_ME262             Avion_ME262_PV
Avion_Mitsubishi_Ki_57   Avion_Mitsubishi_Ki_57_reco
Avion_P40Warhawk         Avion_P47Thunderbolt    Avion_P47Thunderbolt_PV
Avion_P51_PV             Avion_Potez_650_Para    Avion_Seafire
Avion_Seafire_PV         Avion_Spitfire          Avion_Spitfire_PV
Avion_Storch_GR          Avion_Tempest           Avion_Tempest_PV
Avion_Typhoon            Avion_Typhoon_PV        Avion_Wyvern
Avion_Wyvern_PV          Avion_Yak9              Avion_Yak9_PV
Avion_Zero               Avion_Zero_PV           Avion_il2
Avion_il2_PV             Avion_il2_nuke          Avion_Ju_52_Para
(plus remaining variants not listed in spreadsheet)
```

---

## 5. `TBatimentDescriptor` — Buildings

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everything.cpp.gladndfbin`  
**Match key:** `ClassNameForDebug` (StringRef)  
**Instance count:** 135

### Properties

| Property | NDF Type | Example value | Notes |
|---|---|---|---|
| `ClassNameForDebug` | StringRef | `"Building_HeadquarterGR"` | **Match key** |
| `SeuilMort` | Float32 | 4500.0 | HP before destruction |
| `SeuilPinned` | Float32 | 4500.0 | Pinned threshold |
| `ProductionPrice` | List\<Int32\> | list[5] | Cost per game mode — **List type** |
| `DetectionBase` | Float32 | 26000.0 | Detection range |
| `PorteeVisionVolant` | Float32 | 52000.0 | Air vision range |
| `DistanceToRoad` | Float32 | 11700.0 | Snap distance to road when placing |
| `TypeBatiment` | Int32 | 3 | Building type ID |
| `Menu` | Int32 | 7 | Which build menu this appears in |
| `CanBeSpawnedInMapMulti` | Bool | True | Available in multiplayer |
| `SignatureRadar` | Int32 | 2 | Radar signature |
| `Nationalite` | Int32 | — | Nation ID |

### Key `ClassNameForDebug` values (selected)

```
Building_Headquarter          Building_HeadquarterGR
Building_HeadquarterURSS      Building_HeadquarterUK
Building_HeadquarterFR        Building_HeadquarterITA
Building_TruckFactory         Building_TruckFactoryGR
Building_TruckFactoryURSS     Building_TruckFactoryUK
Building_TruckFactoryFR       Building_TruckFactoryITA
Building_BatimentAdministratif    Building_BatimentAdministratifGR
Building_BatimentDepot            Building_BatimentDepotGR
Building_VehiculeFactory          Building_VehiculeFactoryGR
Building_VehiculeFactoryURSS      Building_VehiculeFactoryUK
Building_AirFactory               Building_AirFactoryGR
Building_CaserneBlindee           Building_CaserneBlindeeGR
Building_CaserneSoldier           Building_CaserneSoldierGR
Building_Tourelle_AT_ITA          Building_Tourelle_AT_UK
Building_Tourelle_MG_GER          Building_Bunker_enterre_JAP
(+ 105 more — run inspect_ndf.py on everything.cpp.gladndfbin for the full list)
```

---

## 6. `TAmmunition` — Ammunition / Weapons

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everything.cpp.gladndfbin`  
**Match key:** `AmmunitionId` (UInt32) — **no `ClassNameForDebug`; match by numeric ID**  
**Instance count:** 139  
**ID range:** 1000–1138 (contiguous)

### Properties

| Property | NDF Type | Example value | Notes |
|---|---|---|---|
| `AmmunitionId` | UInt32 | 1000 | **Match key** — use `{"AmmunitionId": "1000"}` |
| `Name` | LocHash | — | Localization hash for ammo name |
| `TypeName` | LocHash | — | Localization hash for ammo type |
| `Arme` | Int32 | 4 | Weapon category (infantry, tank, AT, AA, arty, etc.) |
| `Puissance` | Float32 | 8.0 | Base damage |
| `TempsEntreDeuxTirs` | Float32 | 0.40 | Time between shots (seconds) |
| `TempsEntreDeuxSalves` | Float32 | 4.0 | Time between volleys (seconds) |
| `NbTirParSalves` | Int32 | 10 | Shots per volley |
| `PorteeMaximale` | Float32 | 65000.0 | Max range (game units; ÷ 13000 × 175 ≈ km) |
| `PorteeMinimale` | Float32 | — | Min range (game units) |
| `AngleDispersion` | Float32 | 0.08 | Accuracy dispersion angle (radians; smaller = more accurate) |
| `RayonPinned` | Float32 | 130.0 | Suppression radius (game units) |
| `SuppressDamages` | Float32 | — | Suppression damage amount |
| `RadiusSplashSuppressDamages` | Float32 | — | Area splash suppression radius |
| `FX_vitesse_de_depart` | Float32 | 60000.0 | Projectile muzzle velocity (visual) |
| `FX_frottement` | Float32 | 0.001 | Projectile drag (visual) |
| `FX_tir_tendu` | Bool | True | True = flat trajectory; False = arced |
| `PourcentageTirDirect` | Float32 | 1.0 | Ratio of direct fire |
| `PourcentageTirDirectEnMouvement` | Float32 | 0.80 | Accuracy while moving (ratio) |
| `TirIndirect` | Bool | — | True = indirect/artillery fire |
| `AllowAmbushShot` | Bool | True | Can fire from ambush in forest |
| `Level` | Int32 | 1 | Ammo tier/level |
| `ProjectileType` | Reference | — | Visual projectile descriptor |
| `Icon` | Reference | — | Ammo icon in UI |
| `StressManager` | Reference | — | Stress/morale effect descriptor |

**Note:** Use `inspect_ndf.py` with `--class TAmmunition` to see which weapon uses which `AmmunitionId`.

---

## 7. `TWeaponDescriptor` — Weapon Configurations

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everything.cpp.gladndfbin`  
**Instance count:** 259  
**Structure:** Contains a list of turret descriptors (`TurretDescriptorList`), each of which references an ammunition instance.

Weapon descriptors are complex nested structures. To change weapon stats, modify the `TAmmunition` instance that the weapon points to.

---

## 8. `TIAProfil` — AI Profiles

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everything.cpp.gladndfbin`  
**Instance count:** 10  
**Match:** No `ClassNameForDebug` — match by property values or use empty match `{}` with caution

### Properties

| Property | NDF Type | Example | Notes |
|---|---|---|---|
| `CashReserveTempsActivation` | Float32 | 240.0 | Time before AI starts reserving cash (seconds) |
| `AttaqueTempsActivation` | Float32 | 30.0 | Time before AI attacks (seconds) |
| `OffensiveNbMissionMax` | Int32 | -1 | Max offensive missions (-1 = unlimited) |
| `DefenseDistanceMenace` | Float32 | 312000.0 | Threat detection radius |
| `DefenseDistanceUrgent` | Float32 | 156000.0 | Emergency defense radius |
| `DefenseMaxUnitOnPosition` | Float32 | 1.0 | Max units on defense position |
| `HarcelementActif` | Bool | True | AI harassment enabled |
| `ProdIdleCanCreateFactory` | Bool | True | AI can build factories when idle |
| `PourcentChanceUtiliserCarteManipAuDebut` | Int32 | 40 | % chance AI uses manipulation card at start |
| `PercentMoneyToReserveForBatimentAdmin` | Int32 | 20 | % money reserved for admin buildings |

---

## 9. `TTunableConstante` — Game-Wide Constants

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everythinggdconstanteoriginal.cpp.gladndfbin`  
**Match:** Use empty match `{}` (only 1 instance)  
**Instance count:** 1

This is the master constants table for all game-wide settings.

### Economy & Production

| Property | Type | Default | Description |
|---|---|---|---|
| `QteDeviseInitiale` | Int32 | 200 | Starting money per player |
| `TempsGenAutoDevises` | Int32 | 4 | Seconds between auto-income ticks |
| `QuantiteGenAutoDevises` | Int32 | 1 | Income per tick |
| `QteDeviseParCamion` | Int32 | 3 | Resource per supply truck |
| `NbCamionParConvoi` | Int32 | 3 | Trucks per convoy |
| `TempsENtreDeuxConvois` | Int32 | 30 | Seconds between convoys |
| `StockDeviseSupplementaireFacile` | Int32 | 72 | Bonus starting money on Easy difficulty |
| `MinProductionTime` | Float32 | 1.0 | Minimum production time (clamp) |
| `MaximumBatimentProduction` | UInt32 | 2 | Max simultaneous building productions |
| `PopCapTotal` | Int32 | 200 | Total population cap |
| `PopCapPerAlliance` | Int32 | 100 | Population cap per alliance |
| `PopCapPerPlayer` | Int32 | 100 | Population cap per player |

### Difficulty Multipliers

| Property | Type | Default | Description |
|---|---|---|---|
| `MultiplicateurSeuilPinnedEtMortJoueurFacile` | Float32 | 1.5 | Player unit HP multiplier on Easy |
| `MultiplicateurSeuilPinnedEtMortIAFacile` | Float32 | 0.75 | AI unit HP multiplier on Easy |
| `MultiplicateurSeuilPinnedEtMortJoueurMoyen` | Float32 | 1.0 | Player unit HP multiplier on Normal |
| `MultiplicateurSeuilPinnedEtMortIAMoyen` | Float32 | 1.0 | AI unit HP multiplier on Normal |
| `MultiplicateurSeuilPinnedEtMortJoueurDifficile` | Float32 | 0.75 | Player unit HP multiplier on Hard |
| `MultiplicateurSeuilPinnedEtMortIADifficile` | Float32 | 1.25 | AI unit HP multiplier on Hard |

### Combat & Vision

| Property | Type | Default | Description |
|---|---|---|---|
| `CouvertBonusForet` | Float32 | 78000.0 | Forest concealment bonus range |
| `DistanceIgnoreForet` | Float32 | 26000.0 | Distance at which forest is ignored |
| `DistanceMinimumVision` | Float32 | 26000.0 | Minimum vision range |
| `AltitudeVol` | Float32 | 52000.0 | Aircraft altitude |
| `NbAvionsParAeroport` | Int32 | 8 | Aircraft per airfield |
| `BlitzAccelerationRatio` | Float32 | 1.5 | Speed multiplier during Blitz ruse |
| `BlitzMaxSpeed` | Float32 | 65000.0 | Max speed cap during Blitz ruse |
| `MultiplicateurPinnedEmbuscade` | Float32 | 3.0 | Suppression multiplier for ambush |
| `TimeToBeStealthedAfterReveal` | Float32 | 10.0 | Seconds to re-stealth after being spotted |
| `RegenerationPinnedHorsCombat` | Float32 | 10.0 | Pin recovery rate when out of combat |

### Multiplayer & Matchmaking

| Property | Type | Default | Description |
|---|---|---|---|
| `DureeDecompteLaunchGameMulti` | Int32 | 10 | Countdown before MP game starts (seconds) |
| `NbLeague` | Int32 | 7 | Number of ranked leagues |
| `DefaultCote` | Int32 | 1500 | Default ELO rating |
| `TimeLimitTable` | List\<Int32\> | List[8] | Available time limits for MP matches |

---

## 10. `TVisibilityRange` — Vision Range Table

**Location:** `PC\99\ZZ_GladPatchableWin.dat` → `genglad/patchable/clustergfx/everythinggdconstantevisibility.cpp.gladndfbin`  
**Instance count:** 50  
**Structure:** Each instance has one property: `AltitudeMax` (Float32) — defines the upper altitude boundary for a vision band.

---

## 11. Map Menu Data (globals / mapinfo)

These NDF files are located at the leaf of a long nested path inside `PC\99\ZZ_GladPatchableWin.dat`. Find the exact internal path by running:

```
python tools/inspect_dat.py "Data/PC/99/ZZ_GladPatchableWin.dat" --search globals
```

### `TMultiMapInfo` — Multiplayer maps (17 instances)

| Property | Type | Notes |
|---|---|---|
| `Name` | StringRef | Map display name |
| `Guid` | Guid | Unique map identifier |
| `TrackingId` | StringRef | Internal ID (e.g. `"MP01"`) |
| `NbPlayers` | Int32 | 2, 3, or 4 |

**Known instances:** Blitz, Tank Graveyard, Frontline, Above the River, Face-to-Face, Strongholds, Behind Enemy Lines, Tripartite, Triangular Diplomacy, Cauldron, The Border, Diplomats, Meeting on the Field of Honor, Closing the Pocket, + DLC maps

### `TChapterMapInfo` — Campaign chapters (14 instances)

| Property | Type | Notes |
|---|---|---|
| `Guid` | Guid | Campaign chapter GUID |
| `TrackingId` | StringRef | Internal ID (e.g. `"M01"`) |
| `NbSecondaryObjectives` | Int32 | Number of optional objectives |

### `TChallengeMapInfo` — Challenge operations (12 instances)

| Property | Type | Notes |
|---|---|---|
| `CategoryId` | Int32 | Difficulty tier (1/2/3) |
| `Operation Name` | StringRef | e.g. `"Anzio"`, `"Seelöwe"` |

### `TMapLoadInfo` — Scenario load table (in `mapinfo.cpp.gladndfbin`)

Maps internal scenario file names to GUIDs. Used by the game to load the correct `.dat` when a mission starts.

---

## 12. `TGameDesignAddOn` — Scenario Objects

**Location:** **NOT** in `ZZ_GladPatchableWin.dat`. These live inside per-map scenario `.dat` files in `PC\1360\DataMap_Win.dat`.

Each map scenario contains subclasses:
- `TGameDesignItemList` — root container
- `TGameDesignItem` — individual scenario object
- `TGameDesignAddOn_Spawn` — unit spawn point
- `TGameDesignAddOn_StartingPoint` — player starting position
- `TGameDesignAddOn_LabelVille` — city label on map
- `TGameDesignAddOn_CircularZone` — circular objective zone
- `TGameDesignAddOn_RectangleZone` — rectangular objective zone

---

## 13. NDF Type Reference

Types used in `.rmod` `"type"` fields:

| Type name | Size | Range / Format |
|---|---|---|
| `Bool` | 1 byte | `true` / `false` |
| `Int8` | 1 byte | −128 to 127 |
| `Int16` | 2 bytes | −32768 to 32767 |
| `UInt16` | 2 bytes | 0 to 65535 |
| `Int32` | 4 bytes | −2,147,483,648 to 2,147,483,647 |
| `UInt32` | 4 bytes | 0 to 4,294,967,295 |
| `Long` | 8 bytes | 64-bit integer |
| `Float32` | 4 bytes | Single-precision float |
| `Float64` | 8 bytes | Double-precision float |
| `StringRef` | 4 bytes | Index into string table — pass string value in JSON |
| `PathRef` | 4 bytes | Index into path string table |
| `WideStr` | variable | Length-prefixed UTF-16 string |
| `Vector3` | 12 bytes | `[x, y, z]` as JSON array of floats |
| `Color32` | 4 bytes | ARGB as `[r, g, b, a]` or packed int |
| `Color128` | 16 bytes | ARGB as `[r, g, b, a]` floats |
| `TripleInt` | 12 bytes | `[a, b, c]` as JSON array of ints |
| `Int2` | 8 bytes | `[a, b]` as JSON array of ints |
| `Float2` | 8 bytes | `[x, y]` as JSON array of floats |
| `List` | variable | Cannot be patched with simple scalar type |
| `Reference` | 8 bytes | Object or trans reference — not directly patchable |
| `LocHash` | 8 bytes | Localization hash — not directly patchable |

**Patchable with simple values:** Bool, Int8, Int16, UInt16, Int32, UInt32, Long, Float32, Float64, StringRef, PathRef  
**Not yet supported:** List, Reference, LocHash, WideStr, Vector3, Color32, Color128, TripleInt, Int2, Float2

---

## 14. `.rmod` Quick Reference

```json
{
  "$schema": "ruse-mod/v1",
  "id": "my-mod",
  "name": "My Mod",
  "version": "1.0.0",
  "author": "Author",
  "description": "What this mod changes",
  "patches": [
    {
      "dat": "PC/99/ZZ_GladPatchableWin.dat",
      "ndf": "genglad/patchable/clustergfx/everything.cpp.gladndfbin",
      "changes": [
        {
          "action": "patch",
          "table": "TUniteAuSolDescriptor",
          "match": { "ClassNameForDebug": "Unit_Stug_III_B" },
          "set": {
            "SeuilMort":      { "type": "Float32", "value": 600.0 },
            "VitesseLineaire":{ "type": "Float32", "value": 5200.0 },
            "ProductionTime": { "type": "Int32",   "value": 8 }
          }
        },
        {
          "action": "patch",
          "table": "TAmmunition",
          "match": { "AmmunitionId": "1010" },
          "set": {
            "Puissance":         { "type": "Float32", "value": 20.0 },
            "PorteeMaximale":    { "type": "Float32", "value": 80000.0 },
            "AngleDispersion":   { "type": "Float32", "value": 0.05 }
          }
        }
      ]
    },
    {
      "dat": "PC/99/ZZ_GladPatchableWin.dat",
      "ndf": "genglad/patchable/clustergfx/everythinggdconstanteoriginal.cpp.gladndfbin",
      "changes": [
        {
          "action": "patch",
          "table": "TTunableConstante",
          "match": {},
          "set": {
            "QteDeviseInitiale": { "type": "Int32", "value": 500 }
          }
        }
      ]
    }
  ]
}
```
