"""
R.U.S.E. Compat Mod Manager
============================
Unified mod manager with four tabs:
  Mod Manager  — deploy / restore mods to the live game
  Convert      — convert old-style mod folders to .rmod
  Create       — build new .rmod files with a dat explorer
  Settings     — configure game root and folder paths
"""

import base64
import ctypes
import json
import logging
import os
import re
import shutil
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, font, messagebox, scrolledtext, ttk

# When running as a PyInstaller --onefile exe, __file__ points to a temp
# extraction dir; sys.executable is always the real exe location.
if getattr(sys, "frozen", False):
    _LAUNCH_DIR = Path(sys.executable).parent.resolve()
else:
    _LAUNCH_DIR = Path(__file__).parent.resolve()
sys.path.insert(0, str(_LAUNCH_DIR))

from ruse_mod_engine import applier as applier_mod
from ruse_mod_engine import edata as edata_mod
from ruse_mod_engine import ndfbin as ndfbin_mod
from ruse_mod_engine.ndfbin import T
from ruse_mod_engine.converter import (
    scan_mod_folder, run_conversion,
    name_to_id as _name_to_id,
    sanitize_filename as _sanitize_filename,
)

_SETTINGS_FILE    = _LAUNCH_DIR / "settings.json"
_MGR_STATE_FILE   = _LAUNCH_DIR / ".manager_state.json"

# ── Window icon (base64 PNG, written by make_icon.py) ────────────────────────
_ICON_B64: str = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAZjElEQVR4nNV7CZhVxbXuX1V7OvPpc3puaKBBUASViFfQ6xhRjOMXLqLGRM1VTOKUeH0v5kVDjLnve7nv+oya9xL1xiFqfIrxJhoThxiNRAERJ2QQsIEe6eHM4x6q6n21TzeCQZv5y1vf131299m7qtaqtf61aq21gUNIUoK8fd+x+m6/A4j6HoeYtEM0D3n11VMYIX/xgNXuigfbT08m9G8NZvlLFOKUoKY9Ri7r/KNiXwno2MWrPUKUTA7BwnCQ6amnwC66CFxdr3zk8CRQuV5KcltdhNFMgcM0CAyNoFjmz4G4Vx5/eV/q08/9fykAKUHxQ4DcDrFwIdh/PX/CbZLjukiYJXNFAdeTXNcIYxTcdkEjQUKqtkxL4J6s6907/+qetDKJpUtBD6YgyIEeUNny6vuO1WZfs9pVf7/3+MSzKKM3BSxyZibP4brSAyEsFgIp20ChDNTHgHIFnDLCIkEC25UpInHlMV/Z8pw/psIG4i9W/l0L4Kmd1Hb5g5PmhUL4FyFwFiVAsSJczokWDdXmXLEWePiPHB9uBX70dYZ5swEuIItV6RmM6LpGQAhelELedcxXtr6onjkY+EAOFOMLF0Kohb18b2syEjGuI8Bt4SBluZIQnAOmAVoXBl57H3j4eY43P3AhmQZd4xAucMJMA5edBRw/ncDxIKsOEAsRQilBqcKfIwcJH8j+qrv/a2RH3nt80nmS4CFTJ8l8ScDzJNc0X93RO0zwzDKB/3jOhmMztHRMhhGIgXMPxVQXsgODADNwxvEMt32V+mZRqoA73sHFB7Kvz739KTsnlHxHSJyldtvxhCsl0eJhEGXjD78ALH3NRmoIiDUlUdc8EWakGcJzQCiDlAL5wU0opvtQyleQTOpYeCrDP51M0BCvCYIdJHwg++vWpKw8FAqw86RUgCakEEDABGEMWLUeePD3Hla8ayPc3Ij61okwQg0KA+E5ZeQGOyG4h0h9OwKRBrjVAkrpbqT6t8Ate0gkDNx6OcO84wBxkPCB7Ktb++4FE28VnrzeNGmyVJVqE4WhgwUtIJUj+NGvPPxphQdimmgZ14ZgchIYM+HaJVTygygXhiC4W9tCyhCKNyMYbYIeiKKc7UNpuBO5dBqCAyceRHwg++rWghY5M+27NXBCwEIBYCgL/OZ14Mk/20hnJBLNTUiMmw6mB/2drhaGkR/eBs4dUMJ88KgtQUIID0wzEYjUI5psB6EayvntKAxtPaj4QMYKX087TYWvn+/WGAVeWgX8+BEX6ZSDUMOouteDUoZKMYVSth9OJe9PSSj1d37X2ZQVC19QZjCOULzVF4YSzMHEB7LbXV8CqlT9EzuvjunWlq9xoAcCSDS1IVzfAaqZcKtFVApDPvNSeP6ujknKiJXeS8AIRBGua0Ug2rjf+DCqwWMKQEoQtYbdha+7ujXgmWVyxK1paJo0EaG6cdCtCLhTQTHTh2phCJ5ng/qM11R9z6i2LClcX2j7hw+BK4+/fIOPD2MKQC4BVZ/LJ02aHbLIHaEddi49gLB4ZMSt/VHi6dc9DA+Kndxak6++dimDUnY77HIGlGkA2Y267zHtPz5UbJGWktynO8klSgtGN3i3AliyBPT22yFWPjz5SEL4GgnpuZ6yr5pgVqyV8qHnOVa868KMm2iaMB1WtHnErZV8gKsW074OKtuXcq84H13L3zzjr1gKshM+yFF8KAxuQsHHhzKSSeMTfIiBlB3pRoJML5b5GofrX9wemZVeuHCp2K0A5Ihk/vrbaRGWqX6oUbQ6vHZoWb5O4uHnBd5cw0F0Ey3jx8OKt0EzguCu7at7pTgM7jqglKoJiFDj7VWY4QtLSAmmFrLLNyPfU0KkEJyqO82gwoc2BKONPriWs70Y7hvBhzoNt15OcdJRRAoJSYlMeRw20fQj53x1c35nLdA+vQytwIkE6gWIFrIgX39f4sa7PbgOR7K1vpxom+lJaiikQrWQRiHTo9SdaJoOyyCmJ6jucQmNCkdI2DvrACFSTUyEID7AjhKjknJBQiogsAwBl4uSukc9q54xGNFAiFV1CGGUSsZQsUtZz6kUiGI+GG1GpPEwaGYExeGPUS7k2U0/lcEbL6Vk8bkUJZs2AKK8O7Frn7EdrpCAZQCrNgjhVjQ696SJ6374Nftmu7rRdN0SYaYJp1yA6zlSN0LCKdluqeLyl94LnLx6E/vm/OO8Oxed7r01kGUxCiJUZCg86XJIV9do8JN9JzJk8sqPHtVv5ZL3nDu7+uSUFloiARpkklLuSbecd6p/3ahPe2O9+XWd8shP/tm7oSoMixCP2JV1CIYH/DOFGYoR7oW4dB1v0W3OA6UKWjQGyblUKuXujQDIqFIGTSlVNBerq998yvSVge2VxgcZM6lUSycRCUm4FNKWMPNCiDWLLynf/T8fFhvGRb38lI7IDTND+qmlCndjYaYPDNjPpQbKvx0/OfwAAF+VFdZ3bS3e8r2Li7eeN4c53cXwxaD0JEloGyHEkELkKQLrLzzL/c32nvK3lr7BZk9qZw2RhHE3IaYGhBTUEIBJQqqEe8J2cvIbAVMOEEJadrL33dqjhjFIaYJaqOc5ZddmTBIWU8DuD0sAyvxdVAbfEgkZ0z7oxKyZHflvNEVErlxFMhgmEc8j0DWGZ/9SOOnF11LVx38aDzoudBUPuZ7ELfcMXXTaLP3emTPHf7+uTj+2UhXgCkTUAhiL6zpp96R+VlnH3QuPKz1QLAfmhuKkTtMUONZAUo3DGEGxKiNf/V7PZa6bBCFjxx10zDt26IRCdkgupPC4rH16UpbKnHuehONKkcm5XqJOn/zH5fb1GzuV65KeuheQrvp0PUlsDo2q9XIp1Y8KYnIFzz38sMip4RA7NpPzeNUWwnWlLFcFdzwpCkWuolE5mJXX/pcHMv/Y0kBL/vyitg4upIxFGOrrNCTiOjzBAlzUNnesTDPdYwHsLAq14QQUEuSq73WuenVlricWZtRxQUMWlaZBj/z50+kJoQBzR1zB6DNqQj9AHflbRcWEe9KJRLTxjCqUFzIeZfTlN7N9F3xj45tSSGqZVFOMtDQa2kddznHDGW6ozahFucqUJPn1c6meux/qXXf/453vDQ9WC56QkREBHLS0uFQMDAx7qZBFMxoj45Rr0HSimSY1PtjsJA1DmeQeDOR7AsoIram0UuWhtEc+3lZZEbLo1FSON6rkKYHgmTyPDAx6erJZhRm1I4Qysfuf6Fu7ZlOA0eS0mckEbfR6uxM18ycHry4gpDoUcR40idohf/GuJ2Wh5MlCBfqeRAFqiZSBVWwv7XlC6QXL5j154RmJ1rakNn7Vu+lLrvx+72Km08ayTaxSSXDDVJLaAW6+HBiDnHlk4rW6KUdusEhu0ku9fV/ybxrDBDTsJy25ru2Y8a1WuFDmCAWZpmZ7/6NKdnwTlerQNFYsJP0EimZt6yqvsmfFFlomDdiOENEww/zTEhcPp+2Ge7/fcvf2fq96zx9i97RSnjrxKJnpKRJN12vcMyZxzcWtR5482xicPv3VNehJPUb+ED1VEhYa8QLkgAtASihQxKJz6tsV85xLdA865f94cqjztRX5oRsW1WWqtqBm4PNhRkU7ugYrmymupcL5iQfzhwGT0UqVC9claGm0vhgNaUfwavXWxgbn2mVr6eyuYWppISU6lVQAKCFYMD8x3rLo11au1u0f3p3977WE5dhE91UAo0LoG3K469YO3srXN9TrdP4Joee/dm60s1IVxh4NRFD9oCs27/nX3VXvvpf7174B26uLaZRSiFzR45rBWqVhPTBxPJ39k8tKz+YKMHfHnKFTfyPe31iZAwJ2sLyATwoAlQAWf7/zrWWr8r2hIEU4qGm3LG6ZftkFDR3besoV31PsAWlUiO5BSl9/nzWcOCX7iyd+0/eVFe8W1lgmZYwSWqlwEQoyRg3zR7c9XJ1VF6HlnRgjCg2f/EO6+64Hezc88buutcSz03vgAGpzYz+9QP+Qmw6YyGsaaXMczoWg2oed7gWvvJpa9uzJrdWxBlHqW6yA3nIl7ztvnjW7q7/1tP/2bb24bkNh6cp3chtnzYwsUGd7FRs0N+rm1kFx8Zbe6jNTp5k+fzUvAPyfx3rXre80bZY8/PBxzdpx2Nxr7okIKPaTTJ0gaFE+CjUqOqNEkg82i3qTUffTk6n02S5EANsWZaqZ/8B047pEnXF5Xcy4tlAll/77z7v+067yjZZJiYoMTYNIy2ItK9ZUWnSdeiP8+crQ2sj4tCNb2ZQZR00M1R82gRIl2rFJ218BjLq/0euRPCe1hQ+Szg53pXZKAKWyIIrUv/10h5RwPKnOz9l0zvVKZS4NA+SDj+ymZR+6R8QjdNiTmKryeoQQqgqq24e9CGMQo8cbNRpjRt2iE3MPzD121f3HH47sEZfyf/EkO19jfmJUO3T9AdLnVfHmECIH/egGUOVvnDQ7nDi8wzy5aktT1Q80jchyhcvBYddzPTnocennAkpliVOOjwSfuKvj7KpLpgmVLBWgSgsGUp4XtVSo5JugL3SNEdyzZOI/WDqZYZoUUbOyJJ3j3YyqU/Tn5+HoXjKnIgsV+6sjplSfI9urIliuYvKRGF+EAghETfmHdNZ1o2GmOY4UHeOt4InHRifajlCmIJNxRp79U6Y3XxKFtiTesG25JRHXiXq+rUk3zzgh/gWXI8Q5ZF1MI0Mp13vrg1KmvVW3XQ6x8zpMnVIhSYQLErnprqEL3aJ9lMIOLj6fR7qnvBNJWK7KAtGIrjXWG6QxadCmeoPojBDOZTReZ7BE3NDjDSaJR6kDGfvS6nVeziuVb9i41c6r5KBhUN9VRSMaUYfpXz493Hv7z3pWt7Umx7/1kdnYbBWuX7+53O1xMMtkUM0DsbCmniEfbiwXb/zx1ndKRa971rRI1tBoeOd1JOt09YOGhAHKmKXgZk/40vaIe796Ixta5mQ2da8K3f/g0uwJKiOrQuH+oYozoYH/btnyodSflhemN9QZ7htvpXvLXuSwK/+N3HPjOeSWbKZv8dZheWF9vTXJMIi1fcjhy98rpFatcbJNzfF4mTad9L+fw2HpovjejNahxb/5PV8QiugzQkEayOQ41m6sZF95szBc9ozIKXPGB8/8ivlW7+ryfb9cmj1RrWPnoIqC03feG+oneqJBrW+/BSDVmNLDYCF4zBmXnfHP6z9cg74tn4C7FmqccdEPSHpztw1RcilgA0akLZqMxDZ188k3/1I+O6Wt7bVixd7S3ZvPlTIVDWBmrKEh0TbJnFJ2A5NcT2B7Wrb+4nnrkbaEttyx3Q8HU24qk/OaYTsWNC3aNm5CIsCDR2zo45VpxxeKwxlB0tv9U/JO+XYCRMchmWifDNrfoPLmKpO4XwKAj+sCJceM59PG1WUeRnJCAIRQv6pLmYGMy6ZEExWYzQ0wTRPFUhmlYgnNTXFOqM7e3dx/ejBgoa65AR1HxJHNZjA8nEbBMfyCiWWZSt1lqVQh24atuZYVnwuriiCpoLGhA1YghJ7ePiiG9HA8glBicVSvwmOD0PVRFpSWamicMMu/TvWlQMAP3GGIQEgiqqqbgbiCU4WwmWwGN33nJixadBE/7fTT5NVXXaWde+458uz5870FC76sT506jTlO1dne309ffOlldu89P5UvvPCCO2XyZPnc739vrFr1NrVtG1dffTUWLFhA5s07g197zTfJueeeK84680xx1vz52tFHz6L5bMo2TNN78qmnQ3feeSdefunF6uSODv7+B2sC//fJp2goGJBCchAiUK2UVZJVOefRwuPnkranAqgNRrSaQNWlOrmqnAig6TqbNb3j/amHTZleLhdFR0v0nfPPP/+Eby2+oiufGc4/8utnDuvt3pqtVivR++78wfIzz7/0iMsuWWSsXP5XQQhLKl9iWaacNX3Smskdk6eXSgXRmjBWX3LxJSd8+4Zv9vZ9/EHaijaZDQ31kkBO+vm/37bs5HlfnvGt669zfv2rB/IyFJoAlQD3IwzqZ5L3lCltLwTwiRxGrwiB53FsWL/W/tJ5F8ZK5TK6tm3j046YERoeHKikt3dts+Lj5mzr6dWnTZnQ6bmuHks0GX2DmaZorK5oEO8jh8sE55yMjlEeGWPq4dMD6fSw3b91w8cXX3XTnFAoZrzzzirOmCZvWfI/prRMPLzliccfG+CVTA9B6wQ//Nij2G+f4wBZCwQkHwn3VFGSy1A4hI/Wrxs+8eQvtgwODsCxbdHT3e21t4/3onXJsGYYWvv4dnR+vFWzTAO59IDb2NjIi8USK+fSVZUVDIbC+Gj92toYQwNwq47s7urm9fX1bkNzW/j1vyzTFi640JkyqT1VLBa8d99emeqYML4yONBfhh6bUKs2K4gYBWd5gAVA/ESNDzKGFYVwHT+EVYc9zgX6e7vKmzZuqGxe+85HjFJn/bo19pNPLjW+ffMtTTfeeKP8859fkX9d9krKsoL6tTf/oH3evDPZo796sCAhNco0yjlHf2/3jjEohb2l82P3V48+Zi7+xg0tFy1aJDZt7jQ2r3u3ExDVF5//z8IvfnGf9p2bvxsPxxMRz7H9NYbjbSPJRhUBqjPJHrCGUZmNlItWPDolKj23C4TE4iHIu5YKcv8zHBNnzIARafWRv5Dq8psdXKcqg+EoqeYHNygzdir5wVC8sbWUHRqQRuzoxmR8iEgv3bNtC6xwLFDX0NoeNfnqVK5SP9zXVQwmW8ZpeiBpWiaq2cENkhLLKe8YY7s04rPq6yLpgEmHevv6iVstFZPNk6bmhrvW6dHWuUGDDOaGujZHmo44PpxoY1Yo6WuoVx5A5/trcOUFDN+9lMpMUTVzyRzR9PYxS2MjpKtoWwUWARVTqcTHx2sQifciVD8J8eapcGPNKOcHSSHTC0nNqaoEbhrhdpcLYsaaWxjTWKZQbRHcSUQbJ6iql5kvFJFK2ccwRr1Y80RTKpWSEpVyBTDCU9XEZizU7nK5Y4x82W1I5+yYHohzM1wfqDgezFjLcWojXEQam6aeXmdFElRVorlTRrpvHdJ9g9AtiuMOJ1DlcqUJQmK3Tdra7v4JIE2kKBUrJHnZGRQTGgn58SMCqb4h5LMZJFsyCCXGI9aoWt2iKGV6qe13f0gwTVfmwYQQ0DQGoofM2hFCSE3TVA3RVHz6p4jaUcKv5Y/8rqXaNP/TH0PFB5oWNGqNE9JnhmqmFgjXI1TXCqZbumsXURrejP7uXsCz8Y9Ha7j8HIq50wlyJcBgUh1E1RlSfqYAiFISv7dmVqnZefcLhLivhIO0oVDm7he/QPSjJjM8/bqFpa9xbN+6CaF0D8KJVkQbD4MVSqBSGEYp2we7nN2lL0Dt1OgUNX53WcMnVqru/eRyl3v8p7wawFnhBKL1E6AZIV/dK9luDGxbDztrY84sHVeeY2LOkbUHs0UIXZNcgmiUsC/NvfCjgmoBIKTW/fK3DRIjtqFaSlwjdTsh8pqASROFspSGBnXCY8M54I5HBf60kgPcQbypEZGGiX6FVkV1+VSXLwy+T50h+Jy+oTq/U8QM1fkCtgsDyGzfitxACvWNFP90soYrziaIBIFsQU0oua4TLRFlKFXlS6WqvG3uli1v+8Pe/hkC+DTt3AcohESuJKWqGBsayMp1Eo+9CLyxxvHrg7FEAqH6DgTjrXBVvT4/4HeK1HqDRs1P7nVniKaZsCINfq8QMwK1XqFMDwa2bIVherjqPBNfPomgrR6+uu9o4wlTFIo8RRh+9m/Pbrtj6VLwT3eHfK4Adm4sGu0ElRJnqSKkw6Ubtoimylov+91hHOm0Az2oIdkyyccH1Suk+gFV84TfHeabuV9JxVg02lAVirf4DZS6FYbwbBSHO5Ee6IVbqWDuTANXnMNw6tFApgjYDvwSfCxEabEsuATuIMT62Wh/0M6NXzsT2dde4EJZqhQ0V2ah+gOffl36+JBKuQhFAzvwQZnBZ+HDritRIKfWJ31g9ZkPJ1WwBac0jOG+rSgNDSKRVN1hOs48zu8uR74EyZj0wgGqq+MvpXixVMKdc7++5WU17KuvnqKddtpf1KF5t5Ine9sN/sID4xJxXbueADdYJjkw+CAl1GGGMcMHOCtS7wuKu2Wke9YhvX0AiTqCRaebWHAyRvsD1WNc18GUnZer8iXBxf/apXX2mtXeWD3EZE8EsPs+4daklPp+4kMtrKZMRzDS4PcD6mYInNsop7agv6cX0rZxxhwNP/iahmRMolwFHNWdSlUlmhDbFimqkXt/8rutP/btfMlIS+9OSH/ABKBIAcnq+/+2U3yv8aEwhMJwl7/TscYOv+FKuTWnNOSre3H7IObMMvH1czUcdwSg6owVG1KF/ZEg9Uvtn+4D3Jf3CAj2kQ4EPvjHacFBNQN2YfsOt5ZsABaeauKK+YpZ359LQqRnaFRXQEd33wnqp4cO+RsjT+0HPoST7WBMg1PJob/zYxgmH3FrFG31che3Fg3Rg/IuEdlfAewrPryp8EFX/QRMtYjghKP0Md1aoeD8bN71fakD+TYZwQGkPcUHpvDhbeAHD3LMmAhccTbbEb6O5dYO9PuEBAeBxsIHwSUPjpiFsvGg6UdxfrZFha91UYbKPrq1v6s3R58aAx9MHYILsNGXKHcbvu6lW9tbIjgE9Gl8gNQfCgfZeaooajsSdRGGTIELQuQdQODe/XFrf7ckP/Xm+PuPdZy9/OH2x994eOLiTb+d/LR6oXr0OxW+HqrNwaEmJYjPat9RAjrUr9D/P1zBFmoLDN4EAAAAAElFTkSuQmCC"  # generated — do not edit by hand

# ── RUSE Military Theme ───────────────────────────────────────────────────────
# Dark navy command-room steel, scratched metallic silver text, military gold
_R_BG        = "#08101c"   # deep navy black — window bg
_R_BG_PANEL  = "#0e1a2a"   # navy blue — frame / panel bg
_R_BG_WIDGET = "#060d18"   # near-black navy — listbox / entry / log bg
_R_BORDER    = "#243a5c"   # steel blue border
_R_GOLD      = "#c8a020"   # military gold — primary accent
_R_GOLD_BRT  = "#e0c030"   # bright gold — headings / selected text
_R_RED       = "#b03020"   # danger red
_R_GREEN     = "#3a8030"   # success / OK green (status only)
_R_TEXT      = "#ccd8e8"   # metallic scratched silver-white — body text
_R_TEXT_DIM  = "#3e5878"   # muted steel blue — hint / secondary text
_R_SEL_BG    = "#1a3060"   # selection background
_R_SEL_FG    = "#e0c030"   # selection foreground
_R_BTN       = "#122030"   # button face
_R_BTN_ACT   = "#1e3250"   # button active / hover

# Log tag colors
_DARK_BG  = _R_BG_WIDGET
_COL_INFO = "#ccd8e8"
_COL_WARN = _R_GOLD
_COL_ERR  = "#cc3030"
_COL_OK   = "#4a9a38"
_COL_HEAD = _R_GOLD_BRT

# Fonts
_F_MAIN = ("Courier New", 9)
_F_BOLD = ("Courier New", 9,  "bold")
_F_HEAD = ("Courier New", 10, "bold")
_F_LOG  = ("Courier New", 9)

_GUIDE_TEXT = """\
HOW TO CREATE AN RMOD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
R.U.S.E. Compat stores game data in .dat archives. Each archive contains NDF binary files
(.gladndfbin) that describe game objects — units, buildings, prices, behaviour.

An .rmod is a JSON file that records ONLY the changes you want to make. Instead
of distributing a full replacement .dat, you describe the exact properties to
patch. Multiple mods can coexist without overwriting each other.

WORKFLOW
  1. Load a .dat in the Explorer (left) to browse its contents.
       Most gameplay changes live in:  PC/99/ZZ_GladPatchableWin.dat

  2. Navigate:  NDF Files → Instances (by class) → Properties (name + value)

  3. Select a property you want to change, then click "Add to Patch →".
       Fill in the new value. The type is pre-filled from the current data.

  4. Repeat for every property you want to patch.

  5. Fill in the Mod Info fields (Name, ID, Version, Author, Description).

  6. Click "Save as .rmod". Drop the file into your mods/ folder, then deploy
     it from the Mod Manager tab.

TIPS
  • Load an existing .rmod with "Load .rmod to Edit" to modify it.
  • Instances are matched by ClassNameForDebug name or positional _index.
  • Use the Convert tab to turn old-style (full .dat replacement) mods into .rmod.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""

# Matches a numbered line of a shared load order:  1. Mod Name | v1.2.0
_LO_LINE = re.compile(r'^\d+\.\s+(.+?)(?:\s*\|\s*v?(.+))?$')

_TYPE_NAMES = {
    T.Bool:      "Bool",    T.Int8:    "Int8",    T.Int16:   "Int16",
    T.UInt16:    "UInt16",  T.Int32:   "Int32",   T.UInt32:  "UInt32",
    T.Long:      "Long",    T.Float32: "Float32", T.Float64: "Float64",
    T.StringRef: "StringRef", T.PathRef: "PathRef", T.WideStr: "WideStr",
    T.Vector3:   "Vector3", T.Color128:"Color128", T.Color32: "Color32",
}


# ── Shared helpers ────────────────────────────────────────────────────────────

class _TextHandler(logging.Handler):
    def __init__(self, widget):
        super().__init__()
        self._widget = widget

    def emit(self, record):
        msg = self.format(record) + "\n"
        level = record.levelname
        self._widget.after(0, self._append, msg, level)

    def _append(self, msg, level):
        tag = {"WARNING": "warn", "ERROR": "err"}.get(level, "info")
        self._widget.configure(state="normal")
        self._widget.insert(tk.END, msg, tag)
        self._widget.see(tk.END)
        self._widget.configure(state="disabled")


def _make_log(parent, height=12) -> scrolledtext.ScrolledText:
    w = scrolledtext.ScrolledText(parent, state="disabled", font=_F_LOG,
                                  wrap="none", height=height)
    w.tag_configure("info", foreground=_COL_INFO)
    w.tag_configure("warn", foreground=_COL_WARN)
    w.tag_configure("err",  foreground=_COL_ERR)
    w.tag_configure("ok",   foreground=_COL_OK)
    w.tag_configure("head", foreground=_COL_HEAD, font=_F_BOLD)
    w.configure(background=_DARK_BG, foreground=_COL_INFO,
                insertbackground=_R_GOLD)
    return w


def _log(widget, msg, tag="info"):
    widget.configure(state="normal")
    widget.insert(tk.END, msg + "\n", tag)
    widget.see(tk.END)
    widget.configure(state="disabled")


def _log_clear(widget):
    widget.configure(state="normal")
    widget.delete("1.0", tk.END)
    widget.configure(state="disabled")


def _fmt_val(val, ndf) -> str:
    OBJ = ndfbin_mod.OBJ_REF_MARKER
    TRF = ndfbin_mod.TRANS_REF_MARKER
    t, r = val.type_id, val.raw
    if t == T.Reference:
        marker, ref = r
        if marker == OBJ:
            obj_idx, cls_idx = ref
            cn = next((c.name for c in ndf.classes if c.index == cls_idx), str(cls_idx))
            return f"ObjRef(inst={obj_idx}, {cn})"
        if marker == TRF:
            return f"TransRef({ref})"
        return f"Ref(0x{marker:08X})"
    if t == T.List:
        if not r: return "[]"
        items = [_fmt_val(x, ndf) for x in r[:4]]
        suf = f" …+{len(r)-4}" if len(r) > 4 else ""
        return "[" + ", ".join(items) + suf + "]"
    if t == T.Map:
        return f"Map{{{len(r)} entries}}"
    if t in (T.StringRef, T.PathRef):
        return repr(ndf.resolve_value(val))
    return repr(r)[:150]


# ── Main application ──────────────────────────────────────────────────────────

class ModManagerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("R.U.S.E. COMPAT MOD MANAGER — Field Operations")
        self.minsize(960, 680)
        self.resizable(True, True)
        self.configure(background=_R_BG)

        self._set_window_icon()
        self._apply_titlebar_theme()
        self._settings = self._load_settings()
        self._bootstrap_folders()
        self._apply_theme()
        self._mgr_running  = False
        self._conv_running = False
        self._mgr_mod_vars: list = []     # [(BooleanVar, path), ...]
        self._explorer_arc  = None
        self._explorer_ndf  = None
        self._explorer_dat_path  = ""
        self._explorer_ndf_path  = ""
        self._explorer_instances: list = []
        self._create_patches: list = []

        self._build_ui()
        self._load_mgr_state()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── Bootstrap ─────────────────────────────────────────────────────────────

    def _bootstrap_folders(self):
        """Create required folders next to the exe on first run."""
        try:
            mods = Path(self._settings.get("mods_folder", str(_LAUNCH_DIR / "mods")))
            mods.mkdir(parents=True, exist_ok=True)
            if self._settings.get("working_dir"):
                self._backup_dir().mkdir(parents=True, exist_ok=True)
                self._mod_out_dir().mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    # ── Theme ─────────────────────────────────────────────────────────────────

    def _apply_theme(self):
        s = ttk.Style(self)
        s.theme_use("clam")

        # Base frames
        s.configure("TFrame",
                     background=_R_BG_PANEL)
        s.configure("TLabelFrame",
                     background=_R_BG_PANEL, bordercolor=_R_BORDER,
                     relief="groove")
        s.configure("TLabelFrame.Label",
                     background=_R_BG_PANEL, foreground=_R_GOLD,
                     font=_F_BOLD)

        # Labels
        s.configure("TLabel",
                     background=_R_BG_PANEL, foreground=_R_TEXT,
                     font=_F_MAIN)

        # Buttons
        s.configure("TButton",
                     background=_R_BTN, foreground=_R_TEXT,
                     font=_F_BOLD, bordercolor=_R_BORDER,
                     relief="flat", padding=(8, 3))
        s.map("TButton",
              background=[("active", _R_BTN_ACT), ("pressed", _R_SEL_BG),
                          ("disabled", _R_BG_PANEL)],
              foreground=[("active", _R_GOLD_BRT),
                          ("disabled", _R_TEXT_DIM)])

        # Entries
        s.configure("TEntry",
                     fieldbackground=_R_BG_WIDGET, foreground=_R_TEXT,
                     font=_F_MAIN, insertcolor=_R_GOLD,
                     bordercolor=_R_BORDER, selectbackground=_R_SEL_BG,
                     selectforeground=_R_SEL_FG)

        # Combobox
        s.configure("TCombobox",
                     fieldbackground=_R_BG_WIDGET, foreground=_R_TEXT,
                     font=_F_MAIN, background=_R_BTN,
                     arrowcolor=_R_GOLD, bordercolor=_R_BORDER,
                     selectbackground=_R_SEL_BG, selectforeground=_R_SEL_FG)
        s.map("TCombobox",
              fieldbackground=[("readonly", _R_BG_WIDGET)],
              selectbackground=[("readonly", _R_SEL_BG)])

        # Checkbutton
        s.configure("TCheckbutton",
                     background=_R_BG_PANEL, foreground=_R_TEXT,
                     font=_F_MAIN, focuscolor=_R_GOLD)
        s.map("TCheckbutton",
              background=[("active", _R_BG_PANEL)],
              foreground=[("active", _R_GOLD)])

        # Notebook
        s.configure("TNotebook",
                     background=_R_BG, bordercolor=_R_BORDER,
                     tabmargins=[2, 4, 0, 0])
        s.configure("TNotebook.Tab",
                     background=_R_BTN, foreground=_R_TEXT_DIM,
                     font=_F_BOLD, padding=(12, 5),
                     bordercolor=_R_BORDER)
        s.map("TNotebook.Tab",
              background=[("selected", _R_BG_PANEL)],
              foreground=[("selected", _R_GOLD)])

        # Scrollbars
        s.configure("TScrollbar",
                     background=_R_BG_PANEL, troughcolor=_R_BG_WIDGET,
                     arrowcolor=_R_GOLD, bordercolor=_R_BORDER,
                     relief="flat")
        s.map("TScrollbar",
              background=[("active", _R_BTN_ACT)])

        # Treeview
        s.configure("Treeview",
                     background=_R_BG_WIDGET, foreground=_R_TEXT,
                     fieldbackground=_R_BG_WIDGET, font=_F_MAIN,
                     bordercolor=_R_BORDER, rowheight=20)
        s.configure("Treeview.Heading",
                     background=_R_BTN, foreground=_R_GOLD,
                     font=_F_BOLD, bordercolor=_R_BORDER, relief="flat")
        s.map("Treeview",
              background=[("selected", _R_SEL_BG)],
              foreground=[("selected", _R_SEL_FG)])
        s.map("Treeview.Heading",
              background=[("active", _R_BTN_ACT)])

        # PanedWindow sash
        s.configure("TPanedwindow", background=_R_BG)
        s.configure("Sash", sashthickness=5, sashpad=2,
                     background=_R_BORDER)

        # Separators
        s.configure("TSeparator", background=_R_BORDER)

        # LabelFrame alternate casing (tkinter is inconsistent across platforms)
        s.configure("TLabelframe",       background=_R_BG_PANEL,
                    bordercolor=_R_BORDER, relief="groove")
        s.configure("TLabelframe.Label", background=_R_BG_PANEL,
                    foreground=_R_GOLD, font=_F_BOLD)

        # Catch-all: force all native tk widgets (Listbox, Text, Frame, etc.)
        # that aren't individually configured to use the RUSE palette.
        self.tk_setPalette(
            background=_R_BG_PANEL,
            foreground=_R_TEXT,
            activeBackground=_R_BTN_ACT,
            activeForeground=_R_GOLD_BRT,
            selectBackground=_R_SEL_BG,
            selectForeground=_R_SEL_FG,
            insertBackground=_R_GOLD,
            highlightBackground=_R_BORDER,
            highlightColor=_R_GOLD,
            disabledForeground=_R_TEXT_DIM,
        )

    # ── Window chrome ─────────────────────────────────────────────────────────

    def _set_window_icon(self):
        if _ICON_B64:
            try:
                photo = tk.PhotoImage(data=_ICON_B64)
                self.iconphoto(True, photo)
                self._icon_photo = photo   # keep reference so GC doesn't drop it
            except Exception:
                pass

    def _apply_titlebar_theme(self):
        """Colour the OS title bar via Windows DWM.

        Win11 21H2+: sets exact caption + border colours from the app palette.
        Win10:       falls back to system dark-mode (dark grey bar).
        Fails silently on non-Windows or old builds.
        """
        def _colorref(hex_str: str) -> int:
            h = hex_str.lstrip("#")
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return (b << 16) | (g << 8) | r   # COLORREF = 0x00BBGGRR

        try:
            dwm  = ctypes.windll.dwmapi
            hwnd = self.winfo_id()

            # Win11: custom caption background + text + border
            for attr, value in (
                (35, ctypes.c_uint32(_colorref(_R_BG))),        # DWMWA_CAPTION_COLOR
                (36, ctypes.c_uint32(_colorref(_R_GOLD_BRT))),  # DWMWA_TEXT_COLOR
                (34, ctypes.c_uint32(_colorref(_R_GOLD))),      # DWMWA_BORDER_COLOR
            ):
                try:
                    dwm.DwmSetWindowAttribute(hwnd, attr,
                                              ctypes.byref(value),
                                              ctypes.sizeof(value))
                except Exception:
                    pass

            # Win10 fallback: dark-mode title bar (dark grey)
            dark = ctypes.c_int(1)
            dwm.DwmSetWindowAttribute(hwnd, 20,
                                      ctypes.byref(dark),
                                      ctypes.sizeof(dark))
        except Exception:
            pass

    # ── Settings ──────────────────────────────────────────────────────────────

    def _load_settings(self) -> dict:
        d = {
            "game_root":   "",
            "working_dir": str(_LAUNCH_DIR),
            "mods_folder": str(_LAUNCH_DIR / "mods"),
        }
        if _SETTINGS_FILE.exists():
            try:
                with open(_SETTINGS_FILE, encoding="utf-8") as f:
                    d.update(json.load(f))
            except Exception:
                pass
        return d

    def _save_settings(self):
        try:
            with open(_SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(self._settings, f, indent=2)
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def _game_data(self) -> Path:
        return Path(self._settings["game_root"]) / "Data"

    def _backup_dir(self) -> Path:
        return Path(self._settings["working_dir"]) / "output" / "backups"

    def _mod_out_dir(self) -> Path:
        return Path(self._settings["working_dir"]) / "output" / "mod_output_files"

    def _conv_out_dir(self) -> Path:
        return Path(self._settings["working_dir"]) / "output" / "converter_output"

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        self._nb = ttk.Notebook(self)
        self._nb.pack(fill="both", expand=True, padx=6, pady=6)

        tabs = [
            ("  Mod Manager  ", self._build_manager_tab),
            ("  Convert  ",     self._build_convert_tab),
            ("  Create  ",      self._build_create_tab),
            ("  Settings  ",    self._build_settings_tab),
        ]
        for label, builder in tabs:
            frame = ttk.Frame(self._nb)
            self._nb.add(frame, text=label)
            builder(frame)

        self._nb.bind("<<NotebookTabChanged>>", self._on_tab_changed)

    def _on_tab_changed(self, _=None):
        idx = self._nb.index("current")
        if idx == 1:
            self._reset_convert_tab()
        elif idx == 2:
            self._reset_create_tab()

    # =========================================================================
    # MOD MANAGER TAB
    # =========================================================================

    def _build_manager_tab(self, p):
        pad = {"padx": 6, "pady": 3}

        # Setup checklist
        sf = ttk.LabelFrame(p, text="Setup Checklist  —  complete steps 1 and 2 before deploying mods")
        sf.pack(fill="x", **pad)
        sf.columnconfigure(1, weight=1)

        ttk.Label(sf, text="Step 1", font=_F_BOLD, foreground=_R_GOLD
                  ).grid(row=0, column=0, padx=(8, 4), pady=(6, 2), sticky="w")
        self._mgr_s1_lbl = tk.Label(sf, text="Checking…",
                                    font=_F_LOG, background=_R_BG_PANEL,
                                    foreground=_R_GOLD, anchor="w")
        self._mgr_s1_lbl.grid(row=0, column=1, sticky="ew", padx=4, pady=(6, 2))
        ttk.Button(sf, text="Open Settings",
                   command=lambda: self._nb.select(3)
                   ).grid(row=0, column=2, padx=6, pady=(6, 2))

        ttk.Label(sf, text="Step 2", font=_F_BOLD, foreground=_R_GOLD
                  ).grid(row=1, column=0, padx=(8, 4), pady=(2, 6), sticky="w")
        self._mgr_s2_lbl = tk.Label(sf, text="Checking…",
                                    font=_F_LOG, background=_R_BG_PANEL,
                                    foreground=_R_GOLD, anchor="w")
        self._mgr_s2_lbl.grid(row=1, column=1, sticky="ew", padx=4, pady=(2, 6))
        bbf = ttk.Frame(sf)
        bbf.grid(row=1, column=2, padx=6, pady=(2, 6))
        ttk.Button(bbf, text="Create Backup",
                   command=self._mgr_create_backup).pack(side="left", padx=2)
        ttk.Button(bbf, text="Restore Clean",
                   command=self._mgr_restore_clean).pack(side="left", padx=2)

        # Mod list
        mf = ttk.LabelFrame(p, text="Mods  (☑ = active)")
        mf.pack(fill="both", expand=False, **pad)

        bb = ttk.Frame(mf)
        bb.pack(fill="x", pady=(2, 0))
        ttk.Button(bb, text="Scan Mods Folder",
                   command=self._mgr_scan).pack(side="left", padx=4)
        ttk.Button(bb, text="Add .rmod…",
                   command=self._mgr_add).pack(side="left", padx=4)
        ttk.Button(bb, text="Remove Selected",
                   command=self._mgr_remove).pack(side="left", padx=4)
        ttk.Button(bb, text="Clear All",
                   command=self._mgr_clear).pack(side="left", padx=4)
        ttk.Button(bb, text="Import Order…",
                   command=self._mgr_import_order).pack(side="right", padx=4)
        ttk.Button(bb, text="Share Order",
                   command=self._mgr_share_order).pack(side="right", padx=4)

        ttk.Label(mf,
                  text="Load order: mods at the TOP load first."
                       "  Mods lower in the list apply LAST and will override those above them."
                       "  Use the arrows to reorder.",
                  font=_F_LOG, foreground=_R_GOLD,
                  wraplength=800, justify="left",
                  ).pack(fill="x", padx=6, pady=(3, 1))

        lf = ttk.Frame(mf)
        lf.pack(fill="both", expand=True)
        ob = ttk.Frame(lf)
        ob.pack(side="right", fill="y", padx=(2, 4), pady=4)
        ttk.Label(ob, text="earlier", font=_F_LOG,
                  foreground=_R_TEXT_DIM).pack()
        ttk.Button(ob, text="▲", width=3, command=self._mgr_up).pack(fill="x")
        ttk.Button(ob, text="▼", width=3, command=self._mgr_down).pack(
            fill="x", pady=(2, 0))
        ttk.Label(ob, text="later", font=_F_LOG,
                  foreground=_R_TEXT_DIM).pack()

        self._mgr_lb = tk.Listbox(lf, height=6, selectmode="extended",
                                  activestyle="none",
                                  background=_R_BG_WIDGET, foreground=_R_TEXT,
                                  selectbackground=_R_SEL_BG, selectforeground=_R_SEL_FG,
                                  font=_F_MAIN, relief="flat",
                                  highlightthickness=1, highlightcolor=_R_BORDER,
                                  highlightbackground=_R_BORDER)
        sb = ttk.Scrollbar(lf, orient="vertical", command=self._mgr_lb.yview)
        self._mgr_lb.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", pady=4)
        self._mgr_lb.pack(side="left", fill="both", expand=True,
                          padx=(4, 0), pady=4)
        self._mgr_lb.bind("<ButtonRelease-1>", self._mgr_lb_click)
        self._mgr_lb.bind("<space>", self._mgr_toggle)
        self._mgr_lb.bind("<<ListboxSelect>>", self._mgr_on_select)

        # Detail panel
        df = ttk.LabelFrame(p, text="Selected Mod")
        df.pack(fill="x", **pad)
        self._mgr_detail_meta = tk.StringVar(value="Select a mod to see details.")
        ttk.Label(df, textvariable=self._mgr_detail_meta,
                  justify="left").pack(padx=6, pady=(4, 0), anchor="w")
        self._mgr_detail_desc = scrolledtext.ScrolledText(
            df, height=9, state="disabled", font=_F_MAIN,
            wrap="word", relief="flat",
            background=_R_BG_WIDGET, foreground=_R_TEXT,
            insertbackground=_R_GOLD)
        self._mgr_detail_desc.pack(fill="x", padx=6, pady=(2, 4))

        # Actions
        af = ttk.Frame(p)
        af.pack(fill="x", **pad)
        self._mgr_dry = tk.BooleanVar(value=False)
        ttk.Checkbutton(af, text="Dry run (no files written)",
                        variable=self._mgr_dry).pack(side="left", padx=4)
        ttk.Button(af, text="Clear Log",
                   command=lambda: _log_clear(self._mgr_log)).pack(
            side="right", padx=4)
        self._mgr_deploy_btn = ttk.Button(af, text="▶  Deploy Mods",
                                          command=self._mgr_deploy)
        self._mgr_deploy_btn.pack(side="right", padx=4)

        # Log
        lf2 = ttk.LabelFrame(p, text="Log")
        lf2.pack(fill="both", expand=True, **pad)
        self._mgr_log = _make_log(lf2)
        self._mgr_log.pack(fill="both", expand=True, padx=4, pady=4)

        handler = _TextHandler(self._mgr_log)
        handler.setFormatter(logging.Formatter("%(levelname)s  %(message)s"))
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(logging.DEBUG)

        self._mgr_foot = tk.StringVar(value="Ready.")
        ttk.Label(p, textvariable=self._mgr_foot, anchor="w").pack(
            fill="x", padx=6, pady=(0, 4))

        self.after(150, self._mgr_refresh_status)

    def _mgr_refresh_status(self):
        game_root = self._settings.get("game_root", "").strip()
        if game_root:
            s1_text     = f"Done  —  Game Root set: {game_root}"
            s1_text_set = s1_text
            s1_color    = _COL_OK
        else:
            s1_text     = ("Incomplete  —  Click 'Open Settings', set the Game Root Directory"
                           " to your R.U.S.E. Compat install folder, then come back.")
            s1_text_set = ("Incomplete  —  Browse to your R.U.S.E. Compat install folder"
                           " using the Game Root Directory field above.")
            s1_color    = _COL_ERR
        self._mgr_s1_lbl.configure(text=s1_text, foreground=s1_color)
        if hasattr(self, "_set_s1_lbl"):
            self._set_s1_lbl.configure(text=s1_text_set, foreground=s1_color)

        bd = self._backup_dir()
        if bd.exists():
            n = sum(1 for _ in bd.rglob("*.dat"))
            if n > 0:
                s2_text  = f"Done  —  Backup ready ({n} .dat files).  You can now deploy mods."
                s2_color = _COL_OK
            else:
                s2_text  = ("Incomplete  —  Backup folder is empty."
                            "  Click 'Create Backup' to back up your game files.")
                s2_color = _COL_ERR
        else:
            s2_text  = ("Incomplete  —  Click 'Create Backup' to back up your original"
                        " game files before deploying.")
            s2_color = _COL_ERR
        self._mgr_s2_lbl.configure(text=s2_text, foreground=s2_color)
        if hasattr(self, "_set_s2_lbl"):
            self._set_s2_lbl.configure(text=s2_text, foreground=s2_color)

    def _mgr_label(self, var, path) -> str:
        chk = "☑" if var.get() else "☐"
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
            name = d.get("name", Path(path).name)
            ver  = d.get("version", "")
            return f"{chk}  {name}" + (f"  v{ver}" if ver else "")
        except Exception:
            return f"{chk}  {Path(path).name}"

    def _mgr_add_path(self, path: str):
        for _, ex in self._mgr_mod_vars:
            if ex == path:
                return
        var = tk.BooleanVar(value=False)
        self._mgr_mod_vars.append((var, path))
        self._mgr_lb.insert(tk.END, self._mgr_label(var, path))

    def _mgr_refresh_item(self, idx: int):
        var, path = self._mgr_mod_vars[idx]
        self._mgr_lb.delete(idx)
        self._mgr_lb.insert(idx, self._mgr_label(var, path))
        self._mgr_lb.selection_set(idx)

    def _mgr_lb_click(self, event):
        idx = self._mgr_lb.nearest(event.y)
        if not (0 <= idx < len(self._mgr_mod_vars)):
            return
        bb = self._mgr_lb.bbox(idx)
        if bb and event.x <= bb[0] + font.Font(
                font=self._mgr_lb.cget("font")).measure("☑  "):
            var, _ = self._mgr_mod_vars[idx]
            var.set(not var.get())
            self._mgr_refresh_item(idx)

    def _mgr_toggle(self, _=None):
        for idx in self._mgr_lb.curselection():
            var, _ = self._mgr_mod_vars[idx]
            var.set(not var.get())
            self._mgr_refresh_item(idx)

    def _mgr_on_select(self, _=None):
        sel = self._mgr_lb.curselection()
        if not sel:
            self._mgr_detail_meta.set("Select a mod to see details.")
            self._mgr_set_desc("")
            return
        _, path = self._mgr_mod_vars[sel[0]]
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
            meta = []
            for k, label in [("name","Name"),("author","Author"),("version","Version")]:
                if k in d:
                    meta.append(f"{label}: {d[k]}")
            n = sum(len(pg.get("changes",[])) for pg in d.get("patches",[]))
            meta.append(f"NDF changes: {n}")
            self._mgr_detail_meta.set("   |   ".join(meta))
            self._mgr_set_desc(d.get("description", ""))
        except Exception:
            self._mgr_detail_meta.set(f"File: {path}")
            self._mgr_set_desc("")

    def _mgr_set_desc(self, text: str):
        self._mgr_detail_desc.configure(state="normal")
        self._mgr_detail_desc.delete("1.0", tk.END)
        if text:
            self._mgr_detail_desc.insert("1.0", text)
        self._mgr_detail_desc.configure(state="disabled")

    def _mgr_rebuild(self, sel=-1):
        self._mgr_lb.delete(0, tk.END)
        for var, path in self._mgr_mod_vars:
            self._mgr_lb.insert(tk.END, self._mgr_label(var, path))
        if 0 <= sel < len(self._mgr_mod_vars):
            self._mgr_lb.selection_set(sel)
            self._mgr_lb.see(sel)

    # ── Share / Import load order ─────────────────────────────────────────────

    def _mgr_share_order(self):
        active = [(var, path) for var, path in self._mgr_mod_vars if var.get()]
        if not active:
            messagebox.showinfo("Nothing to Share",
                                "No mods are currently enabled.\n"
                                "Enable at least one mod before sharing.")
            return
        lines = ["=== R.U.S.E. Compat Load Order ==="]
        for i, (_, path) in enumerate(active, 1):
            try:
                with open(path, encoding="utf-8") as f:
                    d = json.load(f)
                name = d.get("name", Path(path).stem)
                ver  = d.get("version", "")
            except Exception:
                name = Path(path).stem
                ver  = ""
            lines.append(f"{i}. {name}" + (f" | v{ver}" if ver else ""))
        lines.append("=== End Load Order ===")
        text = "\n".join(lines)
        self.clipboard_clear()
        self.clipboard_append(text)
        self._mgr_foot.set(
            f"Load order ({len(active)} active mod(s)) copied to clipboard — paste it to your friends!")
        self.after(5000, lambda: self._mgr_foot.set("Ready."))

    def _mgr_import_order(self):
        dlg = tk.Toplevel(self)
        dlg.title("Import Load Order from Friend")
        dlg.configure(background=_R_BG_PANEL)
        dlg.transient(self)
        dlg.grab_set()
        dlg.resizable(True, True)
        dlg.minsize(540, 500)

        ttk.Label(dlg,
                  text="Paste a friend's shared load order below, then click 'Check & Apply'.\n"
                       "The mod manager will verify you have all mods at the correct versions\n"
                       "and rearrange your list to match.",
                  foreground=_R_TEXT, justify="left", font=_F_LOG,
                  ).pack(padx=10, pady=(10, 4), anchor="w")

        txt_frame = ttk.LabelFrame(dlg, text="Paste Load Order Here")
        txt_frame.pack(fill="both", expand=True, padx=10, pady=4)
        txt = scrolledtext.ScrolledText(
            txt_frame, height=7, font=_F_LOG,
            background=_R_BG_WIDGET, foreground=_R_TEXT,
            insertbackground=_R_GOLD, relief="flat")
        txt.pack(fill="both", expand=True, padx=4, pady=4)

        # Pre-fill from clipboard if it looks like a load order
        try:
            clip = self.clipboard_get()
            if "Load Order" in clip:
                txt.insert("1.0", clip)
        except Exception:
            pass

        bf = ttk.Frame(dlg)
        bf.pack(fill="x", padx=10, pady=4)

        res_frame = ttk.LabelFrame(dlg, text="Results")
        res_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        res_log = _make_log(res_frame, height=7)
        res_log.pack(fill="both", expand=True, padx=4, pady=4)

        def do_paste():
            try:
                txt.delete("1.0", tk.END)
                txt.insert("1.0", self.clipboard_get())
            except Exception:
                pass

        ttk.Button(bf, text="Paste from Clipboard",
                   command=do_paste).pack(side="left", padx=4)
        ttk.Button(bf, text="Check & Apply",
                   command=lambda: self._mgr_do_import(
                       txt.get("1.0", tk.END).strip(), res_log)
                   ).pack(side="left", padx=4)
        ttk.Button(bf, text="Close",
                   command=dlg.destroy).pack(side="right", padx=4)

    def _mgr_parse_load_order(self, text: str) -> list:
        """Parse shared load order text. Returns [(name, version), ...] for enabled mods only."""
        in_block = False
        entries = []
        for line in text.splitlines():
            stripped = line.strip()
            if "R.U.S.E. Compat Load Order" in stripped:
                in_block = True
                continue
            if "End Load Order" in stripped:
                break
            if not in_block or not stripped:
                continue
            m = _LO_LINE.match(stripped)
            if m:
                entries.append((m.group(1).strip(), (m.group(2) or "").strip()))
        return entries

    def _mgr_scan_mods_meta(self) -> list:
        """Scan the mods folder. Returns [(name, version, path), ...]."""
        mods_dir = Path(self._settings.get("mods_folder", str(_LAUNCH_DIR / "mods")))
        results = []
        if not mods_dir.exists():
            return results
        for f in sorted(mods_dir.glob("*.rmod")):
            try:
                with open(f, encoding="utf-8") as fh:
                    d = json.load(fh)
                results.append((d.get("name", f.stem), d.get("version", ""), str(f)))
            except Exception:
                results.append((f.stem, "", str(f)))
        return results

    def _mgr_do_import(self, text: str, log_widget):
        """Parse, verify, and apply a shared load order."""
        _log_clear(log_widget)
        entries = self._mgr_parse_load_order(text)
        if not entries:
            _log(log_widget, "No valid load order entries found in the pasted text.", "err")
            return

        available = self._mgr_scan_mods_meta()
        by_name: dict = {}
        for name, ver, path in available:
            by_name.setdefault(name.strip().lower(), []).append((ver, path))

        matched_paths = []   # paths of mods that appear in the shared order (will be ON)
        all_ok = True

        for name, req_ver in entries:
            candidates = by_name.get(name.strip().lower(), [])
            if not candidates:
                _log(log_widget,
                     f"MISSING  {name}" + (f"  (need v{req_ver})" if req_ver else ""),
                     "err")
                all_ok = False
                continue

            exact = [(v, p) for v, p in candidates if v == req_ver] if req_ver else candidates
            if exact:
                ver, path = exact[0]
                _log(log_widget,
                     f"OK       {name}" + (f"  v{ver}" if ver else ""), "ok")
                matched_paths.append(path)
            else:
                ver, path = candidates[0]
                _log(log_widget,
                     f"VERSION  {name}  — you have v{ver}, need v{req_ver}", "warn")
                all_ok = False
                matched_paths.append(path)

        if not matched_paths:
            _log(log_widget, "\nNone of the mods in the order were found.", "err")
            return

        # Mods not in the shared order go at the end and are set OFF
        matched_set = set(matched_paths)
        extra = [(var, path) for var, path in self._mgr_mod_vars
                 if path not in matched_set]

        self._mgr_lb.delete(0, tk.END)
        self._mgr_mod_vars.clear()

        for path in matched_paths:
            var = tk.BooleanVar(value=True)   # shared order = enabled
            self._mgr_mod_vars.append((var, path))
            self._mgr_lb.insert(tk.END, self._mgr_label(var, path))

        for _, path in extra:
            var = tk.BooleanVar(value=False)  # not in shared order = off
            self._mgr_mod_vars.append((var, path))
            self._mgr_lb.insert(tk.END, self._mgr_label(var, path))
            _log(log_widget,
                 f"OFF      {Path(path).stem}  (not in shared order)", "info")

        status = "All mods matched." if all_ok else "Some mods missing or version mismatched — see above."
        _log(log_widget,
             f"\nApplied: {len(matched_paths)} mod(s) enabled in order.  {status}", "head")

    def _mgr_scan(self):
        mods_dir = Path(self._settings["mods_folder"])
        if not mods_dir.exists():
            messagebox.showinfo("Mods Folder",
                                f"Mods folder not found:\n{mods_dir}\n\n"
                                "Create it or change the path in Settings.")
            return
        found = 0
        for f in sorted(mods_dir.glob("*.rmod")):
            self._mgr_add_path(str(f))
            found += 1
        _log(self._mgr_log,
             f"Scanned mods folder: {found} .rmod file(s) found.", "head")

    def _mgr_add(self):
        mods_dir = Path(self._settings.get("mods_folder", str(_LAUNCH_DIR / "mods")))
        for p in filedialog.askopenfilenames(
                title="Select .rmod files",
                filetypes=[("R.U.S.E. Compat Mod files","*.rmod"),("All files","*.*")]):
            src = Path(p)
            dest = mods_dir / src.name
            if src.resolve() != dest.resolve():
                try:
                    mods_dir.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(str(src), str(dest))
                except Exception as e:
                    messagebox.showerror("Copy Failed",
                        f"Could not copy {src.name} to mods folder:\n{e}")
                    continue
            self._mgr_add_path(str(dest))

    def _mgr_remove(self):
        for i in reversed(self._mgr_lb.curselection()):
            self._mgr_lb.delete(i)
            self._mgr_mod_vars.pop(i)

    def _mgr_clear(self):
        self._mgr_lb.delete(0, tk.END)
        self._mgr_mod_vars.clear()

    def _mgr_up(self):
        sel = self._mgr_lb.curselection()
        if len(sel) != 1 or sel[0] == 0: return
        i = sel[0]
        self._mgr_mod_vars[i-1], self._mgr_mod_vars[i] = \
            self._mgr_mod_vars[i], self._mgr_mod_vars[i-1]
        self._mgr_rebuild(i-1)

    def _mgr_down(self):
        sel = self._mgr_lb.curselection()
        if len(sel) != 1 or sel[0] >= len(self._mgr_mod_vars)-1: return
        i = sel[0]
        self._mgr_mod_vars[i], self._mgr_mod_vars[i+1] = \
            self._mgr_mod_vars[i+1], self._mgr_mod_vars[i]
        self._mgr_rebuild(i+1)

    # ── Backup / Restore ──────────────────────────────────────────────────────

    def _mgr_create_backup(self):
        if not self._settings["game_root"]:
            messagebox.showerror("No Game Root", "Set Game Root in Settings first.")
            return
        data_pc = self._game_data() / "PC"
        if not data_pc.exists():
            messagebox.showerror("Not Found", f"Data/PC not found:\n{data_pc}")
            return
        bd = self._backup_dir()
        has_files = bd.exists() and any(bd.rglob("*.dat"))
        if has_files:
            if not messagebox.askyesno("Overwrite?",
                                       f"Backup already exists:\n{bd}\n\nOverwrite?"):
                return
            shutil.rmtree(bd)
        self._mgr_set_busy(True)
        threading.Thread(target=self._do_backup,
                         args=(data_pc, bd), daemon=True).start()

    def _do_backup(self, data_pc: Path, bd: Path):
        try:
            _log(self._mgr_log, f"Creating backup: {data_pc} → {bd}", "head")
            bd.mkdir(parents=True, exist_ok=True)
            count = 0
            for src in data_pc.rglob("*"):
                if src.is_file():
                    rel  = src.relative_to(data_pc)
                    dest = bd / "PC" / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dest)
                    count += 1
                    _log(self._mgr_log, f"  {rel}", "info")
            _log(self._mgr_log, f"Backup complete: {count} files.", "ok")
            self.after(0, self._mgr_refresh_status)
        except Exception as e:
            _log(self._mgr_log, f"Backup error: {e}", "err")
        finally:
            self.after(0, lambda: self._mgr_set_busy(False))

    def _mgr_restore_clean(self):
        bd = self._backup_dir()
        if not bd.exists():
            messagebox.showerror("No Backup", "No backup found. Create one first.")
            return
        if not self._settings["game_root"]:
            messagebox.showerror("No Game Root", "Set Game Root in Settings first.")
            return
        if not messagebox.askyesno("Restore Clean",
                                   "Copy original backup files back to Data/PC,\n"
                                   "removing any deployed mods.\n\nProceed?"):
            return
        self._mgr_set_busy(True)
        threading.Thread(target=self._do_restore,
                         args=(bd, self._game_data()), daemon=True).start()

    def _do_restore(self, bd: Path, data_dir: Path):
        try:
            _log(self._mgr_log, "Restoring clean game files…", "head")
            count = 0
            for src in bd.rglob("*"):
                if src.is_file():
                    rel  = src.relative_to(bd)
                    dest = data_dir / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dest)
                    count += 1
            mod_out = self._mod_out_dir()
            if mod_out.exists():
                shutil.rmtree(mod_out)
            _log(self._mgr_log, f"Restored {count} files — game is clean.", "ok")
            self.after(0, lambda: self._mgr_foot.set("Game restored to clean state."))
        except Exception as e:
            _log(self._mgr_log, f"Restore error: {e}", "err")
        finally:
            self.after(0, lambda: self._mgr_set_busy(False))

    # ── Deploy ────────────────────────────────────────────────────────────────

    def _mgr_deploy(self):
        if self._mgr_running:
            return
        if not self._settings["game_root"]:
            messagebox.showerror("No Game Root", "Set Game Root in Settings first.")
            return
        bd = self._backup_dir()
        if not bd.exists() or not any(bd.rglob("*.dat")):
            messagebox.showerror("No Backup",
                                 "No game file backup found.\n\n"
                                 "Click 'Create Backup' (Step 2 in the setup checklist)\n"
                                 "before deploying mods.")
            return
        active = [p for v, p in self._mgr_mod_vars if v.get()]
        if not active:
            messagebox.showinfo("No Active Mods",
                                "Check at least one mod to deploy.")
            return
        dry = self._mgr_dry.get()
        self._mgr_set_busy(True)
        self._mgr_foot.set("Deploying mods…")
        threading.Thread(target=self._do_deploy,
                         args=(bd, active, dry), daemon=True).start()

    def _do_deploy(self, bd: Path, active: list, dry: bool):
        try:
            data_dir = self._game_data()
            mod_out  = self._mod_out_dir()
            prefix   = "[DRY RUN] " if dry else ""
            _log(self._mgr_log,
                 f"{prefix}Deploying {len(active)} mod(s)  "
                 f"source={bd}  output={mod_out}", "head")

            if not dry:
                if mod_out.exists():
                    shutil.rmtree(mod_out)
                mod_out.mkdir(parents=True, exist_ok=True)

            all_results = []
            for mod_path in active:
                _log(self._mgr_log, f"\n── {Path(mod_path).name} ──", "head")
                try:
                    result = applier_mod.apply_mod(
                        mod_path      = mod_path,
                        game_data_dir = str(bd),
                        backup        = False,
                        dry_run       = dry,
                        output_dir    = str(mod_out) if not dry else None,
                    )
                    all_results.append(result)
                    for rec in result.change_log:
                        _log(self._mgr_log,
                             f"  {rec.table}[{rec.instance_id}].{rec.prop}: "
                             f"{rec.old_val} → {rec.new_val}", "ok")
                    for w in result.warnings:
                        _log(self._mgr_log, f"  WARN  {w}", "warn")
                    for e in result.errors:
                        _log(self._mgr_log, f"  ERROR {e}", "err")
                    _log(self._mgr_log, f"  {result.summary()}", "info")
                except Exception as ex:
                    _log(self._mgr_log, f"  ERROR: {ex}", "err")

            if not dry and all_results:
                # Collect only the dat files that were actually modified
                touched: set = set()
                for mod_path in active:
                    try:
                        with open(mod_path, encoding="utf-8") as f:
                            rmod = json.load(f)
                        for pg in rmod.get("patches", []):
                            touched.add(pg["dat"].replace("/", os.sep))
                        for fg in rmod.get("file_patches", []):
                            touched.add(fg["dat"].replace("/", os.sep))
                    except Exception:
                        pass

                _log(self._mgr_log,
                     f"\nRestoring {len(touched)} touched file(s) to clean state…",
                     "head")
                restored = 0
                for dat_rel in sorted(touched):
                    src = bd / dat_rel
                    dest = data_dir / dat_rel
                    if src.exists():
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src, dest)
                        restored += 1
                        _log(self._mgr_log, f"  restored: {dat_rel}", "info")
                    else:
                        _log(self._mgr_log,
                             f"  WARN backup missing: {dat_rel}", "warn")
                _log(self._mgr_log, f"Restored {restored} file(s).", "ok")

                _log(self._mgr_log, "Overlaying modded files…", "head")
                overlay = 0
                for src in mod_out.rglob("*"):
                    if src.is_file():
                        rel  = src.relative_to(mod_out)
                        dest = data_dir / rel
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src, dest)
                        overlay += 1
                _log(self._mgr_log, f"Deployed {overlay} modded file(s) to game.", "ok")

            total_ch = sum(r.changes_applied for r in all_results)
            total_w  = sum(len(r.warnings)   for r in all_results)
            total_e  = sum(len(r.errors)     for r in all_results)
            summary  = (f"Done — {total_ch} change(s), {total_w} warning(s), "
                        f"{total_e} error(s)")
            _log(self._mgr_log, f"\n{summary}", "head")
            self.after(0, lambda: self._mgr_foot.set(summary))
        except Exception as ex:
            _log(self._mgr_log, f"\nDeploy error: {ex}", "err")
            self.after(0, lambda: self._mgr_foot.set("Deploy failed — see log."))
        finally:
            self.after(0, lambda: self._mgr_set_busy(False))

    def _mgr_set_busy(self, busy: bool):
        self._mgr_running = busy
        self._mgr_deploy_btn.configure(state="disabled" if busy else "normal")

    # ── Manager state persistence ─────────────────────────────────────────────

    def _load_mgr_state(self):
        if not _MGR_STATE_FILE.exists():
            self.after(200, self._mgr_scan)
            return
        try:
            with open(_MGR_STATE_FILE, encoding="utf-8") as f:
                state = json.load(f)
            for entry in state.get("mods", []):
                p = entry.get("path", "")
                if Path(p).exists():
                    var = tk.BooleanVar(value=bool(entry.get("enabled", False)))
                    self._mgr_mod_vars.append((var, p))
                    self._mgr_lb.insert(tk.END, self._mgr_label(var, p))
        except Exception:
            pass

    def _save_mgr_state(self):
        state = {"mods": [{"path": p, "enabled": v.get()}
                          for v, p in self._mgr_mod_vars]}
        try:
            with open(_MGR_STATE_FILE, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception:
            pass

    # =========================================================================
    # CONVERT TAB
    # =========================================================================

    def _build_convert_tab(self, p):
        pad = {"padx": 6, "pady": 3}

        # Dirs
        df = ttk.LabelFrame(p, text="Directories")
        df.pack(fill="x", **pad)
        df.columnconfigure(1, weight=1)

        ttk.Label(df, text="Mod Folder:").grid(row=0, column=0, sticky="e", **pad)
        self._cv_mod = tk.StringVar()
        ttk.Entry(df, textvariable=self._cv_mod).grid(
            row=0, column=1, sticky="ew", **pad)
        ttk.Button(df, text="Browse…",
                   command=self._cv_browse_mod).grid(row=0, column=2, **pad)

        ttk.Label(df,
                  text="  The mod folder must mirror the game's Data\\PC\\ structure.\n"
                       "  Place modded .dat files inside matching subfolders — e.g. your mod folder\\99\\ZZ_GladPatchableWin.dat",
                  foreground=_R_TEXT_DIM, justify="left").grid(
            row=1, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 4))

        ttk.Label(df, text="Output Folder:").grid(row=2, column=0, sticky="e", **pad)
        self._cv_out = tk.StringVar()
        ttk.Entry(df, textvariable=self._cv_out).grid(
            row=2, column=1, sticky="ew", **pad)
        ttk.Button(df, text="Browse…",
                   command=self._cv_browse_out).grid(row=2, column=2, **pad)

        ttk.Label(df, text="Output defaults to your Mods Folder (Settings). "
                  "Game data directory is also taken from Settings.",
                  foreground=_R_TEXT_DIM).grid(
            row=3, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 3))
        self._cv_preview = tk.StringVar()
        ttk.Label(df, textvariable=self._cv_preview,
                  foreground=_R_TEXT_DIM).grid(row=4, column=1, sticky="w", padx=6)

        # Mod info
        mf = ttk.LabelFrame(p, text="Mod Info")
        mf.pack(fill="x", **pad)
        mf.columnconfigure(1, weight=2)
        mf.columnconfigure(3, weight=1)

        ttk.Label(mf, text="Name:").grid(row=0, column=0, sticky="e", **pad)
        self._cv_name = tk.StringVar()
        self._cv_name.trace_add("write", lambda *_: self._cv_update_preview())
        ne = ttk.Entry(mf, textvariable=self._cv_name)
        ne.grid(row=0, column=1, sticky="ew", **pad)
        ne.bind("<FocusOut>", self._cv_auto_id)

        ttk.Label(mf, text="ID:").grid(row=0, column=2, sticky="e", **pad)
        self._cv_id = tk.StringVar()
        ttk.Entry(mf, textvariable=self._cv_id).grid(
            row=0, column=3, sticky="ew", **pad)

        ttk.Label(mf, text="Version:").grid(row=0, column=4, sticky="e", **pad)
        self._cv_ver = tk.StringVar(value="1.0.0")
        ttk.Entry(mf, textvariable=self._cv_ver, width=8).grid(
            row=0, column=5, sticky="ew", **pad)

        ttk.Label(mf, text="Author:").grid(row=1, column=0, sticky="e", **pad)
        self._cv_author = tk.StringVar()
        ttk.Entry(mf, textvariable=self._cv_author).grid(
            row=1, column=1, sticky="ew", **pad)

        ttk.Label(mf, text="Description:").grid(row=1, column=2, sticky="e", **pad)
        self._cv_desc = tk.StringVar()
        ttk.Entry(mf, textvariable=self._cv_desc).grid(
            row=1, column=3, columnspan=3, sticky="ew", **pad)

        # Detected files
        det = ttk.LabelFrame(p, text="Detected .dat Files")
        det.pack(fill="both", expand=False, **pad)

        sb2 = ttk.Frame(det)
        sb2.pack(fill="x", pady=(2, 0))
        ttk.Button(sb2, text="Scan for Changes",
                   command=self._cv_scan).pack(side="left", padx=4)
        self._cv_scan_status = tk.StringVar()
        ttk.Label(sb2, textvariable=self._cv_scan_status,
                  foreground=_R_TEXT_DIM).pack(side="left", padx=8)

        lf = ttk.Frame(det)
        lf.pack(fill="both", expand=True)
        self._cv_lb = tk.Listbox(lf, height=4, selectmode="browse",
                                 activestyle="none",
                                 background=_R_BG_WIDGET, foreground=_R_TEXT,
                                 selectbackground=_R_SEL_BG, selectforeground=_R_SEL_FG,
                                 font=_F_MAIN, relief="flat",
                                 highlightthickness=1, highlightcolor=_R_BORDER,
                                 highlightbackground=_R_BORDER)
        cvs = ttk.Scrollbar(lf, orient="vertical", command=self._cv_lb.yview)
        self._cv_lb.configure(yscrollcommand=cvs.set)
        cvs.pack(side="right", fill="y", pady=4)
        self._cv_lb.pack(side="left", fill="both", expand=True, padx=(4, 0), pady=4)

        # Actions
        af = ttk.Frame(p)
        af.pack(fill="x", **pad)
        ttk.Button(af, text="Clear Log",
                   command=lambda: _log_clear(self._cv_log)).pack(
            side="right", padx=4)
        self._cv_btn = ttk.Button(af, text="▶  Convert to .rmod",
                                  command=self._cv_convert)
        self._cv_btn.pack(side="right", padx=4)

        lf2 = ttk.LabelFrame(p, text="Log")
        lf2.pack(fill="both", expand=True, **pad)
        self._cv_log = _make_log(lf2)
        self._cv_log.pack(fill="both", expand=True, padx=4, pady=4)

        self._cv_foot = tk.StringVar(value="Ready.")
        ttk.Label(p, textvariable=self._cv_foot, anchor="w").pack(
            fill="x", padx=6, pady=(0, 4))

    def _reset_convert_tab(self):
        self._cv_mod.set("")
        self._cv_out.set(self._settings.get("mods_folder", str(_LAUNCH_DIR / "mods")))
        self._cv_name.set("")
        self._cv_id.set("")
        self._cv_ver.set("1.0.0")
        self._cv_author.set("")
        self._cv_desc.set("")
        self._cv_preview.set("")
        self._cv_lb.delete(0, tk.END)
        self._cv_scan_status.set("")
        _log_clear(self._cv_log)
        self._cv_foot.set("Ready.")

    def _cv_browse_mod(self):
        d = filedialog.askdirectory(
            title="Select mod folder (contains 99/ or 1360/ sub-folders)")
        if not d:
            return
        self._cv_mod.set(d)
        name = Path(d).name
        if not self._cv_name.get():
            self._cv_name.set(name)
        if not self._cv_id.get():
            self._cv_id.set(_name_to_id(name))
        if not self._cv_out.get():
            self._cv_out.set(self._settings.get("mods_folder", str(_LAUNCH_DIR / "mods")))

    def _cv_browse_out(self):
        d = filedialog.askdirectory(title="Select output folder for .rmod file (defaults to Mods Folder)")
        if d:
            self._cv_out.set(d)

    def _cv_update_preview(self):
        name = self._cv_name.get().strip()
        self._cv_preview.set(
            f"→ {_sanitize_filename(name)}.rmod" if name else "")

    def _cv_auto_id(self, _=None):
        name = self._cv_name.get().strip()
        if name and not self._cv_id.get():
            self._cv_id.set(_name_to_id(name))

    def _cv_scan(self):
        mod_folder = self._cv_mod.get().strip()
        if not mod_folder:
            messagebox.showerror("Missing", "Set the Mod Folder first."); return
        if not self._settings["game_root"]:
            messagebox.showerror("Missing", "Set Game Root in Settings."); return
        self._cv_lb.delete(0, tk.END)
        pairs = scan_mod_folder(mod_folder, str(self._game_data()))
        if not pairs:
            self._cv_scan_status.set("No matching .dat files found.")
            return
        for mod_dat, _, rmod_rel in pairs:
            self._cv_lb.insert(
                tk.END, f"{rmod_rel}  ({mod_dat.stat().st_size // 1024} KB)")
        self._cv_scan_status.set(f"{len(pairs)} .dat file(s) found")

    def _cv_convert(self):
        if self._conv_running:
            return
        mod_folder  = self._cv_mod.get().strip()
        output_dir  = self._cv_out.get().strip()
        name        = self._cv_name.get().strip()
        mod_id      = self._cv_id.get().strip()
        version     = self._cv_ver.get().strip() or "1.0.0"
        author      = self._cv_author.get().strip()
        description = self._cv_desc.get().strip()

        if not mod_folder:
            messagebox.showerror("Missing", "Set the Mod Folder."); return
        if not self._settings["game_root"]:
            messagebox.showerror("Missing", "Set Game Root in Settings."); return
        if not output_dir:
            messagebox.showerror("Missing", "Set the Output Folder."); return
        if not name:
            messagebox.showerror("Missing", "Enter a mod Name."); return
        if not mod_id:
            mod_id = _name_to_id(name)
            self._cv_id.set(mod_id)

        out_rmod = str(Path(output_dir) / (_sanitize_filename(name) + ".rmod"))
        self._conv_running = True
        self._cv_btn.configure(state="disabled")
        self._cv_foot.set("Converting…")
        threading.Thread(
            target=self._cv_run,
            args=(mod_folder, str(self._game_data()), out_rmod,
                  name, mod_id, version, author, description),
            daemon=True).start()

    def _cv_run(self, mod_folder, game_data, out_rmod,
                name, mod_id, version, author, description):
        def lf(msg): _log(self._cv_log, msg, "info")
        def wf(msg): _log(self._cv_log, "WARN  " + msg, "warn")
        try:
            _log(self._cv_log, f"Converting: {name}", "head")
            ok = run_conversion(
                mod_folder=mod_folder, game_data_dir=game_data,
                output_rmod=out_rmod,
                name=name, mod_id=mod_id, version=version,
                author=author, description=description,
                log_fn=lf, warn_fn=wf)
            if ok:
                _log(self._cv_log, f"\nDone — {out_rmod}", "ok")
                self.after(0, lambda: self._cv_foot.set(
                    f"Written: {Path(out_rmod).name}"))
            else:
                _log(self._cv_log, "\nConversion failed — see warnings.", "err")
                self.after(0, lambda: self._cv_foot.set("Conversion failed."))
        except Exception as e:
            _log(self._cv_log, f"\nError: {e}", "err")
            self.after(0, lambda: self._cv_foot.set("Error — see log."))
        finally:
            self.after(0, lambda: (
                setattr(self, "_conv_running", False),
                self._cv_btn.configure(state="normal")))

    # =========================================================================
    # CREATE TAB
    # =========================================================================

    def _build_create_tab(self, p):
        pad = {"padx": 6, "pady": 3}

        # Guide (collapsed by default)
        gf = ttk.LabelFrame(p, text="Guide  ▶ click to expand")
        gf.pack(fill="x", **pad)
        self._guide_open = False
        self._guide_body = tk.Frame(gf, background=_R_BG_PANEL)
        gt = tk.Text(self._guide_body, height=14, font=_F_LOG, state="disabled",
                     wrap="word", background=_R_BG_WIDGET, foreground=_R_TEXT,
                     relief="flat", cursor="arrow",
                     insertbackground=_R_GOLD)
        gt.configure(state="normal")
        gt.insert("1.0", _GUIDE_TEXT)
        gt.configure(state="disabled")
        gt.pack(fill="x", padx=4, pady=4)
        gf.bind("<Button-1>", self._toggle_guide)
        for w in (gf,):
            w.bind("<Button-1>", self._toggle_guide)

        # Mod metadata
        mf = ttk.LabelFrame(p, text="Mod Info")
        mf.pack(fill="x", **pad)
        mf.columnconfigure(1, weight=2)
        mf.columnconfigure(3, weight=1)

        ttk.Label(mf, text="Name:").grid(row=0, column=0, sticky="e", **pad)
        self._cr_name = tk.StringVar()
        ttk.Entry(mf, textvariable=self._cr_name).grid(
            row=0, column=1, sticky="ew", **pad)
        ttk.Label(mf, text="ID:").grid(row=0, column=2, sticky="e", **pad)
        self._cr_id = tk.StringVar()
        ttk.Entry(mf, textvariable=self._cr_id).grid(
            row=0, column=3, sticky="ew", **pad)
        ttk.Label(mf, text="Version:").grid(row=0, column=4, sticky="e", **pad)
        self._cr_ver = tk.StringVar(value="1.0.0")
        ttk.Entry(mf, textvariable=self._cr_ver, width=8).grid(
            row=0, column=5, sticky="ew", **pad)
        ttk.Label(mf, text="Author:").grid(row=1, column=0, sticky="e", **pad)
        self._cr_author = tk.StringVar()
        ttk.Entry(mf, textvariable=self._cr_author).grid(
            row=1, column=1, sticky="ew", **pad)
        ttk.Label(mf, text="Description:").grid(row=1, column=2, sticky="e", **pad)
        self._cr_desc = tk.StringVar()
        ttk.Entry(mf, textvariable=self._cr_desc).grid(
            row=1, column=3, columnspan=3, sticky="ew", **pad)

        # PanedWindow: explorer | builder
        pw = ttk.PanedWindow(p, orient="horizontal")
        pw.pack(fill="both", expand=True, **pad)

        explorer = ttk.LabelFrame(pw, text="Dat Explorer")
        pw.add(explorer, weight=2)
        self._build_explorer(explorer)

        builder = ttk.LabelFrame(pw, text="Patch Builder")
        pw.add(builder, weight=3)
        self._build_builder(builder)

    def _toggle_guide(self, _=None):
        if self._guide_open:
            self._guide_body.pack_forget()
            self._guide_open = False
        else:
            self._guide_body.pack(fill="x")
            self._guide_open = True

    def _build_explorer(self, p):
        pad = {"padx": 4, "pady": 2}

        bb = ttk.Frame(p)
        bb.pack(fill="x", pady=(4, 0))
        ttk.Button(bb, text="Load .dat…",
                   command=self._cr_load_dat).pack(side="left", padx=4)
        self._cr_dat_lbl = ttk.Label(bb, text="No .dat loaded", foreground=_R_TEXT_DIM)
        self._cr_dat_lbl.pack(side="left", padx=4)

        ttk.Label(p, text="NDF Files:").pack(anchor="w", **pad)
        nf = ttk.Frame(p)
        nf.pack(fill="x", **pad)
        self._cr_ndf_lb = tk.Listbox(nf, height=5, selectmode="browse",
                                     activestyle="none", exportselection=False,
                                     background=_R_BG_WIDGET, foreground=_R_TEXT,
                                     selectbackground=_R_SEL_BG, selectforeground=_R_SEL_FG,
                                     font=_F_MAIN, relief="flat",
                                     highlightthickness=1, highlightcolor=_R_BORDER,
                                     highlightbackground=_R_BORDER)
        ns = ttk.Scrollbar(nf, orient="vertical", command=self._cr_ndf_lb.yview)
        self._cr_ndf_lb.configure(yscrollcommand=ns.set)
        ns.pack(side="right", fill="y")
        self._cr_ndf_lb.pack(side="left", fill="x", expand=True)
        self._cr_ndf_lb.bind("<<ListboxSelect>>", self._cr_on_ndf)

        ttk.Label(p, text="Instances:").pack(anchor="w", **pad)
        inf = ttk.Frame(p)
        inf.pack(fill="x", **pad)
        self._cr_inst_lb = tk.Listbox(inf, height=5, selectmode="browse",
                                      activestyle="none", exportselection=False,
                                      background=_R_BG_WIDGET, foreground=_R_TEXT,
                                      selectbackground=_R_SEL_BG, selectforeground=_R_SEL_FG,
                                      font=_F_MAIN, relief="flat",
                                      highlightthickness=1, highlightcolor=_R_BORDER,
                                      highlightbackground=_R_BORDER)
        ins = ttk.Scrollbar(inf, orient="vertical", command=self._cr_inst_lb.yview)
        self._cr_inst_lb.configure(yscrollcommand=ins.set)
        ins.pack(side="right", fill="y")
        self._cr_inst_lb.pack(side="left", fill="x", expand=True)
        self._cr_inst_lb.bind("<<ListboxSelect>>", self._cr_on_inst)

        ttk.Label(p, text="Properties:").pack(anchor="w", **pad)
        pf = ttk.Frame(p)
        pf.pack(fill="both", expand=True, **pad)
        cols = ("property", "type", "value")
        self._cr_prop_tv = ttk.Treeview(pf, columns=cols, show="headings",
                                        height=8, selectmode="browse")
        for col, text, w in [("property","Property",140),
                              ("type","Type",80),("value","Current Value",200)]:
            self._cr_prop_tv.heading(col, text=text)
            self._cr_prop_tv.column(col, width=w, minwidth=60)
        ps = ttk.Scrollbar(pf, orient="vertical", command=self._cr_prop_tv.yview)
        self._cr_prop_tv.configure(yscrollcommand=ps.set)
        ps.pack(side="right", fill="y")
        self._cr_prop_tv.pack(side="left", fill="both", expand=True)

        ttk.Button(p, text="Add to Patch →",
                   command=self._cr_add_to_patch).pack(pady=4)

    def _build_builder(self, p):
        pad = {"padx": 4, "pady": 2}

        bb = ttk.Frame(p)
        bb.pack(fill="x", pady=(4, 2))
        ttk.Button(bb, text="Load .rmod to Edit",
                   command=self._cr_load_rmod).pack(side="left", padx=4)
        ttk.Button(bb, text="Clear Patches",
                   command=self._cr_clear_patches).pack(side="left", padx=4)
        ttk.Button(bb, text="Save as .rmod",
                   command=self._cr_save_rmod).pack(side="right", padx=4)
        ttk.Button(bb, text="Remove Selected",
                   command=self._cr_remove_patch).pack(side="right", padx=4)

        ttk.Label(p, text="Current Patches:").pack(anchor="w", **pad)
        pf = ttk.Frame(p)
        pf.pack(fill="both", expand=True, **pad)

        cols = ("dat", "ndf", "match", "property", "new_value")
        self._cr_patch_tv = ttk.Treeview(pf, columns=cols, show="headings",
                                         height=16, selectmode="browse")
        for col, text, w in [("dat","DAT",100),("ndf","NDF File",160),
                              ("match","Instance",160),("property","Property",120),
                              ("new_value","New Value",120)]:
            self._cr_patch_tv.heading(col, text=text)
            self._cr_patch_tv.column(col, width=w, minwidth=60)
        ps = ttk.Scrollbar(pf, orient="vertical", command=self._cr_patch_tv.yview)
        self._cr_patch_tv.configure(yscrollcommand=ps.set)
        ps.pack(side="right", fill="y")
        self._cr_patch_tv.pack(side="left", fill="both", expand=True)

        self._cr_status = tk.StringVar(value="0 patches.")
        ttk.Label(p, textvariable=self._cr_status,
                  foreground=_R_TEXT_DIM).pack(anchor="w", padx=4, pady=2)

    def _reset_create_tab(self):
        self._cr_name.set("")
        self._cr_id.set("")
        self._cr_ver.set("1.0.0")
        self._cr_author.set("")
        self._cr_desc.set("")
        self._explorer_arc  = None
        self._explorer_ndf  = None
        self._explorer_dat_path  = ""
        self._explorer_ndf_path  = ""
        self._explorer_instances = []
        self._cr_dat_lbl.configure(text="No .dat loaded", foreground=_R_TEXT_DIM)
        self._cr_ndf_lb.delete(0, tk.END)
        self._cr_inst_lb.delete(0, tk.END)
        for item in self._cr_prop_tv.get_children():
            self._cr_prop_tv.delete(item)
        self._cr_clear_patches()

    def _cr_load_dat(self):
        init = str(self._game_data() / "PC") \
            if self._settings["game_root"] else str(_LAUNCH_DIR)
        path = filedialog.askopenfilename(
            title="Select a .dat file to explore",
            initialdir=init,
            filetypes=[("DAT archives","*.dat"),("All files","*.*")])
        if not path:
            return
        try:
            arc = edata_mod.open_dat(path)
        except Exception as e:
            messagebox.showerror("Load Error", f"Could not open .dat:\n{e}")
            return
        self._explorer_arc = arc
        self._explorer_dat_path = path
        self._cr_dat_lbl.configure(text=Path(path).name, foreground=_R_GOLD)
        self._cr_ndf_lb.delete(0, tk.END)
        self._cr_inst_lb.delete(0, tk.END)
        for item in self._cr_prop_tv.get_children():
            self._cr_prop_tv.delete(item)
        entries = sorted(
            e.path for e in arc._entries
            if e.path.lower().endswith(".gladndfbin") or
               e.path.lower().endswith(".ndfbin"))
        for ep in entries:
            self._cr_ndf_lb.insert(tk.END, ep.replace("\\", "/"))

    def _cr_on_ndf(self, _=None):
        sel = self._cr_ndf_lb.curselection()
        if not sel or self._explorer_arc is None:
            return
        ndf_path = self._cr_ndf_lb.get(sel[0])
        self._explorer_ndf_path = ndf_path
        try:
            raw = self._explorer_arc.get(ndf_path)
            if raw is None:
                raw = self._explorer_arc.get(ndf_path.replace("/","\\"))
            ndf = ndfbin_mod.read(raw)
        except Exception as e:
            messagebox.showerror("Parse Error", f"Could not parse NDF:\n{e}")
            return
        self._explorer_ndf = ndf
        cls_by_idx = {c.index: c.name for c in ndf.classes}
        self._cr_inst_lb.delete(0, tk.END)
        self._explorer_instances = []
        for i, inst in enumerate(ndf.instances):
            cls = cls_by_idx.get(inst.class_index, "?")
            dbg = ""
            for pv in inst.props:
                prop = next((p for p in ndf.properties
                             if p.index == pv.prop_index), None)
                if prop and prop.name == "ClassNameForDebug":
                    dbg = str(ndf.resolve_value(pv.value))
                    break
            label = f"[{i}] {cls}"
            if dbg:
                label += f"  ({dbg})"
            self._explorer_instances.append((i, cls, dbg, inst))
            self._cr_inst_lb.insert(tk.END, label)
        for item in self._cr_prop_tv.get_children():
            self._cr_prop_tv.delete(item)

    def _cr_on_inst(self, _=None):
        sel = self._cr_inst_lb.curselection()
        if not sel or self._explorer_ndf is None:
            return
        _, cls, dbg, inst = self._explorer_instances[sel[0]]
        ndf = self._explorer_ndf
        prop_by_idx = {p.index: p for p in ndf.properties}
        for item in self._cr_prop_tv.get_children():
            self._cr_prop_tv.delete(item)
        for pv in inst.props:
            prop = prop_by_idx.get(pv.prop_index)
            if prop is None:
                continue
            type_name = _TYPE_NAMES.get(pv.value.type_id,
                                        f"0x{pv.value.type_id:02X}")
            val_str = _fmt_val(pv.value, ndf)
            self._cr_prop_tv.insert("", tk.END,
                                    values=(prop.name, type_name, val_str))

    def _cr_add_to_patch(self):
        if self._explorer_ndf is None:
            messagebox.showinfo("No Data",
                                "Load a .dat and select an instance first.")
            return
        sel_prop = self._cr_prop_tv.selection()
        sel_inst = self._cr_inst_lb.curselection()
        if not sel_prop:
            messagebox.showinfo("No Property",
                                "Select a property in the explorer."); return
        if not sel_inst:
            messagebox.showinfo("No Instance",
                                "Select an instance first."); return

        pv = self._cr_prop_tv.item(sel_prop[0])["values"]
        prop_name, prop_type, cur_val = pv[0], pv[1], pv[2]

        inst_idx, cls_name, dbg, _ = self._explorer_instances[sel_inst[0]]
        match_str = dbg if dbg else f"_index:{inst_idx}"

        dat_path = self._explorer_dat_path
        try:
            rmod_dat = Path(dat_path).relative_to(
                self._game_data()).as_posix()
        except ValueError:
            rmod_dat = Path(dat_path).name

        self._cr_patch_dialog(rmod_dat,
                              self._explorer_ndf_path.replace("\\", "/"),
                              cls_name, match_str, prop_name, str(prop_type),
                              str(cur_val))

    def _cr_patch_dialog(self, dat, ndf_path, table, match_str,
                         prop_name, prop_type, cur_val):
        dlg = tk.Toplevel(self)
        dlg.title("Add Patch")
        dlg.resizable(False, False)
        dlg.transient(self)
        dlg.grab_set()
        dlg.configure(background=_R_BG_PANEL)

        pad = {"padx": 8, "pady": 4}
        ttk.Label(dlg, text="Property:").grid(row=0, column=0, sticky="e", **pad)
        ttk.Label(dlg, text=prop_name,
                  foreground=_COL_HEAD).grid(row=0, column=1, sticky="w", **pad)

        ttk.Label(dlg, text="Type:").grid(row=1, column=0, sticky="e", **pad)
        type_var = tk.StringVar(value=prop_type)
        types = ["Bool","Int8","Int16","UInt16","Int32","UInt32","Long",
                 "Float32","Float64","StringRef","PathRef","WideStr",
                 "Vector3","Color128","Color32","TripleInt","Int2","Float2"]
        ttk.Combobox(dlg, textvariable=type_var, values=types,
                     width=14).grid(row=1, column=1, sticky="w", **pad)

        ttk.Label(dlg, text="Current:").grid(row=2, column=0, sticky="e", **pad)
        ttk.Label(dlg, text=str(cur_val)[:80],
                  foreground=_R_TEXT_DIM).grid(row=2, column=1, sticky="w", **pad)

        ttk.Label(dlg, text="New Value:").grid(row=3, column=0, sticky="e", **pad)
        new_var = tk.StringVar()
        ttk.Entry(dlg, textvariable=new_var, width=36).grid(
            row=3, column=1, sticky="ew", **pad)

        ttk.Label(dlg, text="Match:").grid(row=4, column=0, sticky="e", **pad)
        match_var = tk.StringVar(value=match_str)
        ttk.Entry(dlg, textvariable=match_var, width=36).grid(
            row=4, column=1, sticky="ew", **pad)
        ttk.Label(dlg, text="Use ClassNameForDebug value, or _index:N for positional.",
                  foreground=_R_TEXT_DIM).grid(row=5, column=1, sticky="w",
                                          padx=8, pady=(0, 4))

        def on_ok():
            nv = new_var.get().strip()
            if not nv:
                messagebox.showerror("Missing", "Enter a new value.", parent=dlg)
                return
            mr = match_var.get().strip()
            if mr.startswith("_index:"):
                match = {"_index": mr[7:]}
            elif mr:
                match = {"ClassNameForDebug": mr}
            else:
                messagebox.showerror("Missing", "Enter an instance match.", parent=dlg)
                return
            parsed = self._cr_parse_val(nv, type_var.get())
            if parsed is None:
                messagebox.showerror("Parse Error",
                                     f"Could not parse '{nv}' as {type_var.get()}.",
                                     parent=dlg)
                return
            patch = {"dat": dat, "ndf": ndf_path, "table": table,
                     "match": match, "prop": prop_name,
                     "type": type_var.get(), "value": parsed}
            self._create_patches.append(patch)
            md = next(iter(match.values()))
            self._cr_patch_tv.insert("", tk.END,
                values=(Path(dat).name, ndf_path.split("/")[-1],
                        md, prop_name, str(nv)[:30]))
            self._cr_status.set(f"{len(self._create_patches)} patch(es).")
            dlg.destroy()

        bf = ttk.Frame(dlg)
        bf.grid(row=6, column=0, columnspan=2, pady=8)
        ttk.Button(bf, text="Add Patch", command=on_ok).pack(side="left", padx=8)
        ttk.Button(bf, text="Cancel", command=dlg.destroy).pack(side="left", padx=8)
        dlg.wait_window()

    def _cr_parse_val(self, raw: str, type_name: str):
        try:
            if type_name == "Bool":
                return 1 if raw.lower() in ("1","true","yes") else 0
            if type_name in ("Int8","Int16","UInt16","Int32","UInt32","Long"):
                return int(raw)
            if type_name in ("Float32","Float64"):
                return float(raw)
            if type_name in ("StringRef","PathRef","WideStr"):
                return raw
            if type_name in ("Vector3","Color128","Color32","TripleInt","Int2","Float2"):
                return [float(x.strip()) for x in raw.strip("[]()").split(",")]
        except Exception:
            pass
        return None

    def _cr_remove_patch(self):
        sel = self._cr_patch_tv.selection()
        if not sel: return
        idx = self._cr_patch_tv.index(sel[0])
        self._cr_patch_tv.delete(sel[0])
        if idx < len(self._create_patches):
            self._create_patches.pop(idx)
        self._cr_status.set(f"{len(self._create_patches)} patch(es).")

    def _cr_clear_patches(self):
        self._create_patches.clear()
        for item in self._cr_patch_tv.get_children():
            self._cr_patch_tv.delete(item)
        self._cr_status.set("0 patches.")

    def _cr_load_rmod(self):
        path = filedialog.askopenfilename(
            title="Load .rmod to Edit",
            filetypes=[("R.U.S.E. Compat Mod files","*.rmod"),("All files","*.*")])
        if not path: return
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            messagebox.showerror("Load Error", str(e)); return

        self._cr_name.set(data.get("name",""))
        self._cr_id.set(data.get("id",""))
        self._cr_ver.set(data.get("version","1.0.0"))
        self._cr_author.set(data.get("author",""))
        self._cr_desc.set(data.get("description",""))
        self._cr_clear_patches()

        for pg in data.get("patches", []):
            dat_path = pg.get("dat","")
            ndf_path = pg.get("ndf","")
            for ch in pg.get("changes",[]):
                if ch.get("action","patch") != "patch":
                    continue
                table = ch.get("table","")
                match = ch.get("match",{})
                for pname, pval in ch.get("set",{}).items():
                    patch = {"dat": dat_path, "ndf": ndf_path, "table": table,
                             "match": match, "prop": pname,
                             "type": pval.get("type",""),
                             "value": pval.get("value")}
                    self._create_patches.append(patch)
                    md = next(iter(match.values()), "?")
                    self._cr_patch_tv.insert("", tk.END,
                        values=(Path(dat_path).name, ndf_path.split("/")[-1],
                                md, pname, str(pval.get("value",""))[:30]))
        self._cr_status.set(
            f"{len(self._create_patches)} patch(es) loaded from {Path(path).name}.")

    def _cr_save_rmod(self):
        name = self._cr_name.get().strip()
        if not name:
            messagebox.showerror("Missing", "Enter a mod Name."); return
        if not self._create_patches:
            messagebox.showinfo("No Patches", "No patches to save."); return

        mod_id  = self._cr_id.get().strip() or _name_to_id(name)
        version = self._cr_ver.get().strip() or "1.0.0"
        author  = self._cr_author.get().strip()
        desc    = self._cr_desc.get().strip()

        # Group patches by (dat, ndf) then merge same table+match
        groups: dict = {}
        for px in self._create_patches:
            key = (px["dat"], px["ndf"])
            if key not in groups:
                groups[key] = []
            found = next(
                (ch for ch in groups[key]
                 if ch["table"] == px["table"] and ch["match"] == px["match"]),
                None)
            if found is None:
                found = {"action":"patch","table":px["table"],
                         "match":px["match"],"set":{}}
                groups[key].append(found)
            found["set"][px["prop"]] = {"type": px["type"], "value": px["value"]}

        patches = [{"dat": dat, "ndf": ndf, "changes": changes}
                   for (dat, ndf), changes in groups.items()]

        rmod_obj = {"$schema":"ruse-mod/v1","id":mod_id,"name":name,
                    "version":version,"patches":patches}
        if author: rmod_obj["author"] = author
        if desc:   rmod_obj["description"] = desc

        mods_dir = self._settings.get("mods_folder", str(_LAUNCH_DIR / "mods"))
        out = filedialog.asksaveasfilename(
            title="Save .rmod",
            defaultextension=".rmod",
            initialfile=_sanitize_filename(name) + ".rmod",
            initialdir=mods_dir,
            filetypes=[("R.U.S.E. Compat Mod files","*.rmod"),("All files","*.*")])
        if not out: return
        try:
            Path(out).parent.mkdir(parents=True, exist_ok=True)
            with open(out, "w", encoding="utf-8") as f:
                json.dump(rmod_obj, f, indent=2, ensure_ascii=False)
            messagebox.showinfo("Saved", f"Saved: {Path(out).name}")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    # =========================================================================
    # SETTINGS TAB
    # =========================================================================

    def _build_settings_tab(self, p):
        pad = {"padx": 8, "pady": 6}

        ttk.Label(p, text="Configure paths for the R.U.S.E. Compat Mod Manager.",
                  foreground=_R_TEXT_DIM).pack(anchor="w", padx=10, pady=(10, 4))

        pf = ttk.LabelFrame(p, text="Paths")
        pf.pack(fill="x", **pad)
        pf.columnconfigure(1, weight=1)

        defs = [
            ("Game Root Directory:", "game_root",
             "Root folder of your R.U.S.E. Compat installation (contains Ruse.exe and Data/)."),
            ("Working Directory:",   "working_dir",
             "Folder where the exe lives. Output folders and state files are stored here."),
            ("Mods Folder:",         "mods_folder",
             "Where your .rmod files live. Auto-set to <working dir>/mods."),
        ]
        # Row layout: game_root at 0-1, status at 2, working_dir at 3-4, mods_folder at 5-6
        _entry_rows = [0, 3, 5]
        self._set_vars: dict = {}
        self._set_save_job = None
        for ri, (label, key, hint) in enumerate(defs):
            er = _entry_rows[ri]
            ttk.Label(pf, text=label).grid(
                row=er, column=0, sticky="ne", **pad)
            var = tk.StringVar(value=self._settings.get(key, ""))
            self._set_vars[key] = var
            var.trace_add("write", lambda *_: self._set_schedule_save())
            ttk.Entry(pf, textvariable=var).grid(
                row=er, column=1, sticky="ew", **pad)
            cmd = [self._set_browse_game_root,
                   self._set_browse_working,
                   self._set_browse_mods][ri]
            ttk.Button(pf, text="Browse…", command=cmd).grid(
                row=er, column=2, padx=4, pady=6)
            ttk.Label(pf, text=hint, foreground=_R_TEXT_DIM, wraplength=580,
                      justify="left").grid(
                row=er+1, column=1, sticky="w", padx=8, pady=(0, 4))

        self._set_s1_lbl = tk.Label(pf, text="", font=_F_LOG,
                                    background=_R_BG_PANEL, anchor="w")
        self._set_s1_lbl.grid(row=2, column=1, columnspan=2,
                               sticky="ew", padx=8, pady=(0, 6))

        sf = ttk.Frame(p)
        sf.pack(fill="x", **pad)
        self._set_status = tk.StringVar()
        ttk.Label(sf, textvariable=self._set_status,
                  foreground=_COL_OK, font=_F_LOG).pack(side="left", padx=2)

        bf = ttk.LabelFrame(p, text="Game File Backup")
        bf.pack(fill="x", **pad)
        ttk.Label(bf,
                  text="Back up your original game files before deploying any mods.\n"
                       "Set Game Root Directory above first, then click the button below.",
                  foreground=_R_TEXT_DIM, font=_F_LOG, justify="left",
                  ).pack(anchor="w", padx=8, pady=(6, 2))
        ttk.Button(bf, text="Create Backup",
                   command=self._mgr_create_backup).pack(anchor="w", padx=8, pady=(2, 4))
        self._set_s2_lbl = tk.Label(bf, text="", font=_F_LOG,
                                    background=_R_BG_PANEL, anchor="w")
        self._set_s2_lbl.pack(fill="x", padx=8, pady=(0, 8))

        info = ttk.LabelFrame(p, text="Output Folder Structure")
        info.pack(fill="x", **pad)
        ttk.Label(info,
                  text=("output/backups/          ← original game files "
                        "(created by 'Create Backup')\n"
                        "output/mod_output_files/ ← patched .dat files "
                        "(generated on Deploy)\n"
                        "mods/                    ← converted .rmod files "
                        "(output of the Convert tab)"),
                  justify="left",
                  font=_F_LOG).pack(padx=8, pady=6, anchor="w")

    def _set_browse_game_root(self):
        d = filedialog.askdirectory(
            title="Select R.U.S.E. Compat game root (contains Ruse.exe)")
        if d: self._set_vars["game_root"].set(d)

    def _set_browse_working(self):
        d = filedialog.askdirectory(title="Select working directory")
        if d: self._set_vars["working_dir"].set(d)

    def _set_browse_mods(self):
        d = filedialog.askdirectory(title="Select mods folder")
        if d: self._set_vars["mods_folder"].set(d)

    def _set_schedule_save(self):
        if self._set_save_job:
            self.after_cancel(self._set_save_job)
        self._set_save_job = self.after(600, self._set_do_save)

    def _set_do_save(self):
        self._set_save_job = None
        old_game_root = self._settings.get("game_root", "")
        for key, var in self._set_vars.items():
            self._settings[key] = var.get().strip()
        self._save_settings()
        self._set_status.set("Settings saved.")
        self.after(2000, lambda: self._set_status.set(""))
        self._mgr_refresh_status()
        new_game_root = self._settings.get("game_root", "")
        if new_game_root and new_game_root != old_game_root:
            self._set_auto_backup()

    def _set_auto_backup(self):
        """Start a backup automatically when game root is newly set, if none exists yet."""
        data_pc = self._game_data() / "PC"
        if not data_pc.exists():
            return
        bd = self._backup_dir()
        if bd.exists():
            return  # existing backup — don't overwrite silently
        _log(self._mgr_log,
             "Game root configured — automatically backing up game files...", "head")
        self._mgr_set_busy(True)
        threading.Thread(target=self._do_backup,
                         args=(data_pc, bd), daemon=True).start()

    # =========================================================================
    # Close
    # =========================================================================

    def _on_close(self):
        # Flush any pending debounced settings save before exit
        if getattr(self, "_set_save_job", None):
            self.after_cancel(self._set_save_job)
            self._set_save_job = None
            for key, var in self._set_vars.items():
                self._settings[key] = var.get().strip()
        self._save_settings()
        self._save_mgr_state()
        self.destroy()


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = ModManagerApp()
    app.mainloop()
